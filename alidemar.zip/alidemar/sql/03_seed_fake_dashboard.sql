-- 03_seed_fake_dashboard.sql
-- Objetivo: popular o banco com dados ficticios para testes de dashboard
-- Pode rodar varias vezes (remove apenas seeds anteriores marcados com seed_fake_v1)

USE dashboard_visitas;

START TRANSACTION;

-- =========================================================
-- 0) LIMPEZA DE SEEDS ANTERIORES
-- =========================================================
DELETE FROM f_compromissos
WHERE titulo LIKE 'Seed Fake %';

DELETE FROM f_interacoes
WHERE tags LIKE '%seed_fake_v1%';

DELETE FROM f_visitas
WHERE tags LIKE '%seed_fake_v1%';

-- =========================================================
-- 1) GARANTIR DIMENSOES BASICAS
-- =========================================================
INSERT IGNORE INTO d_usuarios (nome, slug) VALUES
  ('Ademar', 'ademar'),
  ('Aline', 'aline');

INSERT IGNORE INTO d_status_demanda (nome, ordem) VALUES
  ('Em Andamento', 1),
  ('Nao Iniciado', 2),
  ('Concluido', 3),
  ('Sem Solucao', 4);

INSERT IGNORE INTO d_tipos_interacao (nome) VALUES
  ('Teams'),
  ('Telefone'),
  ('WhatsApp'),
  ('Presencial'),
  ('Email');

INSERT IGNORE INTO d_tipos_compromisso (nome, cor_padrao) VALUES
  ('Reuniao', '#2563eb'),
  ('Visita', '#10b981'),
  ('Ligacao', '#f59e0b'),
  ('Tarefa', '#7c3aed'),
  ('Outro', '#64748b');

INSERT IGNORE INTO d_temas_visita (nome) VALUES
  ('Estrategia Comercial'),
  ('Carteira de Clientes'),
  ('Credito e Vencidos'),
  ('Produtos PJ'),
  ('Planejamento Mensal'),
  ('Relacionamento com Time');

INSERT IGNORE INTO d_areas_responsaveis (nome) VALUES
  ('Comercial'),
  ('Credito'),
  ('Operacoes'),
  ('Produtos'),
  ('Atendimento');

INSERT IGNORE INTO d_agencias (nome, codigo, cidade, uf) VALUES
  ('Agencia Paulista Centro', 'SP001', 'Sao Paulo', 'SP'),
  ('Agencia Vila Mariana', 'SP014', 'Sao Paulo', 'SP'),
  ('Agencia Copacabana', 'RJ003', 'Rio de Janeiro', 'RJ'),
  ('Agencia Savassi', 'MG011', 'Belo Horizonte', 'MG'),
  ('Agencia Boa Viagem', 'PE007', 'Recife', 'PE'),
  ('Agencia Barra da Tijuca', 'RJ021', 'Rio de Janeiro', 'RJ'),
  ('Agencia Campinas Centro', 'SP035', 'Campinas', 'SP'),
  ('Agencia Londrina Norte', 'PR009', 'Londrina', 'PR'),
  ('Agencia Goiania Sul', 'GO005', 'Goiania', 'GO'),
  ('Agencia Brasilia Asa Norte', 'DF004', 'Brasilia', 'DF'),
  ('Agencia Salvador Iguatemi', 'BA018', 'Salvador', 'BA'),
  ('Agencia Porto Alegre Moinhos', 'RS012', 'Porto Alegre', 'RS');

-- =========================================================
-- 2) IDS DE REFERENCIA
-- =========================================================
SET @u_ademar := (SELECT id FROM d_usuarios WHERE slug = 'ademar' LIMIT 1);
SET @u_aline  := (SELECT id FROM d_usuarios WHERE slug = 'aline' LIMIT 1);

SET @tema_estrategia     := (SELECT id FROM d_temas_visita WHERE nome = 'Estrategia Comercial' LIMIT 1);
SET @tema_carteira       := (SELECT id FROM d_temas_visita WHERE nome = 'Carteira de Clientes' LIMIT 1);
SET @tema_credito        := (SELECT id FROM d_temas_visita WHERE nome = 'Credito e Vencidos' LIMIT 1);
SET @tema_produtos       := (SELECT id FROM d_temas_visita WHERE nome = 'Produtos PJ' LIMIT 1);
SET @tema_planejamento   := (SELECT id FROM d_temas_visita WHERE nome = 'Planejamento Mensal' LIMIT 1);
SET @tema_relacionamento := (SELECT id FROM d_temas_visita WHERE nome = 'Relacionamento com Time' LIMIT 1);

SET @tipo_teams      := (SELECT id FROM d_tipos_interacao WHERE nome = 'Teams' LIMIT 1);
SET @tipo_telefone   := (SELECT id FROM d_tipos_interacao WHERE nome = 'Telefone' LIMIT 1);
SET @tipo_whatsapp   := (SELECT id FROM d_tipos_interacao WHERE nome = 'WhatsApp' LIMIT 1);
SET @tipo_presencial := (SELECT id FROM d_tipos_interacao WHERE nome = 'Presencial' LIMIT 1);
SET @tipo_email      := (SELECT id FROM d_tipos_interacao WHERE nome = 'Email' LIMIT 1);

SET @area_comercial  := (SELECT id FROM d_areas_responsaveis WHERE nome = 'Comercial' LIMIT 1);
SET @area_credito    := (SELECT id FROM d_areas_responsaveis WHERE nome = 'Credito' LIMIT 1);
SET @area_operacoes  := (SELECT id FROM d_areas_responsaveis WHERE nome = 'Operacoes' LIMIT 1);
SET @area_produtos   := (SELECT id FROM d_areas_responsaveis WHERE nome = 'Produtos' LIMIT 1);
SET @area_atendimento:= (SELECT id FROM d_areas_responsaveis WHERE nome = 'Atendimento' LIMIT 1);

SET @status_andamento   := (SELECT id FROM d_status_demanda WHERE nome = 'Em Andamento' LIMIT 1);
SET @status_nao_ini     := (SELECT id FROM d_status_demanda WHERE nome = 'Nao Iniciado' LIMIT 1);
SET @status_concluido   := (SELECT id FROM d_status_demanda WHERE nome = 'Concluido' LIMIT 1);
SET @status_sem_solucao := (SELECT id FROM d_status_demanda WHERE nome = 'Sem Solucao' LIMIT 1);

SET @comp_reuniao := (SELECT id FROM d_tipos_compromisso WHERE nome = 'Reuniao' LIMIT 1);
SET @comp_visita  := (SELECT id FROM d_tipos_compromisso WHERE nome = 'Visita' LIMIT 1);
SET @comp_ligacao := (SELECT id FROM d_tipos_compromisso WHERE nome = 'Ligacao' LIMIT 1);
SET @comp_tarefa  := (SELECT id FROM d_tipos_compromisso WHERE nome = 'Tarefa' LIMIT 1);
SET @comp_outro   := (SELECT id FROM d_tipos_compromisso WHERE nome = 'Outro' LIMIT 1);

-- =========================================================
-- 3) TABELAS TEMPORARIAS AUXILIARES
-- =========================================================
DROP TEMPORARY TABLE IF EXISTS tmp_n;
CREATE TEMPORARY TABLE tmp_n (
  n INT NOT NULL PRIMARY KEY
);

INSERT INTO tmp_n (n) VALUES
  (0),(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11);

DROP TEMPORARY TABLE IF EXISTS tmp_months;
CREATE TEMPORARY TABLE tmp_months AS
SELECT
  n,
  DATE_SUB(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL n MONTH) AS mes_inicio
FROM tmp_n;

DROP TEMPORARY TABLE IF EXISTS tmp_agencias_seed;
CREATE TEMPORARY TABLE tmp_agencias_seed AS
SELECT id, nome, uf
FROM d_agencias
WHERE ativo = 1
ORDER BY id
LIMIT 10;

-- =========================================================
-- 4) VISITAS (ultimos 12 meses)
-- =========================================================
INSERT INTO f_visitas (
  usuario_id,
  agencia_id,
  tema_visita_id,
  descricao,
  demandas,
  area_responsavel_id,
  status_demanda_id,
  tags,
  data_contato
)
SELECT
  IF((ag.id + ms.n) % 2 = 0, @u_ademar, @u_aline) AS usuario_id,
  ag.id AS agencia_id,
  ELT(
    (ms.n % 6) + 1,
    @tema_estrategia, @tema_carteira, @tema_credito, @tema_produtos, @tema_planejamento, @tema_relacionamento
  ) AS tema_visita_id,
  CONCAT('Seed Fake visita ', DATE_FORMAT(ms.mes_inicio, '%m/%Y'), ' - ', ag.nome) AS descricao,
  CONCAT('Seed Fake demandas ', DATE_FORMAT(ms.mes_inicio, '%m/%Y'), ' / ', ag.nome) AS demandas,
  ELT(
    (ag.id % 5) + 1,
    @area_comercial, @area_credito, @area_operacoes, @area_produtos, @area_atendimento
  ) AS area_responsavel_id,
  ELT(
    ((ag.id + ms.n) % 4) + 1,
    @status_andamento, @status_nao_ini, @status_concluido, @status_sem_solucao
  ) AS status_demanda_id,
  CONCAT('seed_fake_v1,visita,', DATE_FORMAT(ms.mes_inicio, '%Y-%m')) AS tags,
  DATE_ADD(ms.mes_inicio, INTERVAL (3 + ((ag.id + ms.n * 2) % 23)) DAY) AS data_contato
FROM tmp_months ms
JOIN tmp_agencias_seed ag ON 1 = 1
WHERE ((ag.id + ms.n) % 2 = 0);

INSERT INTO f_visitas_participantes (visita_id, nome, subsecao)
SELECT
  v.id,
  ELT(
    (v.id % 15) + 1,
    'Mariana Freitas', 'Pedro Nogueira', 'Renata Souza', 'Carlos Lima', 'Ana Costa',
    'Joao Silva', 'Felipe Gomes', 'Patricia Mello', 'Bruno Dias', 'Larissa Rocha',
    'Rita Campos', 'Thiago Prado', 'Clara Ribeiro', 'Davi Moreira', 'Sonia Araujo'
  ) AS nome,
  ELT(
    (v.id % 5) + 1,
    'Gerente Agencia', 'Relacionamento', 'Comercial', 'Atendimento', 'Credito'
  ) AS subsecao
FROM f_visitas v
WHERE v.tags LIKE '%seed_fake_v1%';

INSERT INTO f_visitas_participantes (visita_id, nome, subsecao)
SELECT
  v.id,
  ELT(
    ((v.id + 7) % 15) + 1,
    'Mariana Freitas', 'Pedro Nogueira', 'Renata Souza', 'Carlos Lima', 'Ana Costa',
    'Joao Silva', 'Felipe Gomes', 'Patricia Mello', 'Bruno Dias', 'Larissa Rocha',
    'Rita Campos', 'Thiago Prado', 'Clara Ribeiro', 'Davi Moreira', 'Sonia Araujo'
  ) AS nome,
  ELT(
    ((v.id + 2) % 5) + 1,
    'Gerente Agencia', 'Relacionamento', 'Comercial', 'Atendimento', 'Credito'
  ) AS subsecao
FROM f_visitas v
WHERE v.tags LIKE '%seed_fake_v1%'
  AND (v.id % 3 <> 0);

-- =========================================================
-- 5) INTERACOES (ultimos 12 meses)
-- =========================================================
INSERT INTO f_interacoes (
  usuario_id,
  tipo_interacao_id,
  agencia_id,
  diretoria,
  regional,
  nome_contato,
  subsecao_contato,
  assunto,
  descricao,
  demandas,
  area_responsavel_id,
  status_demanda_id,
  tags,
  data_contato
)
SELECT
  IF((ag.id + ms.n + 1) % 2 = 0, @u_ademar, @u_aline) AS usuario_id,
  ELT(
    (ms.n % 5) + 1,
    @tipo_teams, @tipo_telefone, @tipo_whatsapp, @tipo_presencial, @tipo_email
  ) AS tipo_interacao_id,
  ag.id AS agencia_id,
  CONCAT('Diretoria ', ag.uf) AS diretoria,
  CONCAT('Regional ', ag.uf) AS regional,
  ELT(
    ((ag.id + ms.n) % 15) + 1,
    'Mariana Freitas', 'Pedro Nogueira', 'Renata Souza', 'Carlos Lima', 'Ana Costa',
    'Joao Silva', 'Felipe Gomes', 'Patricia Mello', 'Bruno Dias', 'Larissa Rocha',
    'Rita Campos', 'Thiago Prado', 'Clara Ribeiro', 'Davi Moreira', 'Sonia Araujo'
  ) AS nome_contato,
  ELT(
    ((ag.id + ms.n) % 6) + 1,
    'Gerente', 'Supervisor', 'Diretor', 'Coordenador', 'Especialista', 'Analista'
  ) AS subsecao_contato,
  CONCAT('Seed Fake interacao ', DATE_FORMAT(ms.mes_inicio, '%m/%Y'), ' - ', ag.nome) AS assunto,
  CONCAT('Follow-up comercial do mes ', DATE_FORMAT(ms.mes_inicio, '%m/%Y'), '.') AS descricao,
  CONCAT('Pendencia seed ', DATE_FORMAT(ms.mes_inicio, '%Y-%m')) AS demandas,
  ELT(
    (ms.n % 5) + 1,
    @area_comercial, @area_credito, @area_operacoes, @area_produtos, @area_atendimento
  ) AS area_responsavel_id,
  ELT(
    ((ms.n + ag.id) % 4) + 1,
    @status_andamento, @status_nao_ini, @status_concluido, @status_sem_solucao
  ) AS status_demanda_id,
  CONCAT('seed_fake_v1,interacao,', DATE_FORMAT(ms.mes_inicio, '%Y-%m')) AS tags,
  DATE_ADD(ms.mes_inicio, INTERVAL (6 + ((ag.id + ms.n * 3) % 20)) DAY) AS data_contato
FROM tmp_months ms
JOIN tmp_agencias_seed ag ON 1 = 1
WHERE ((ag.id + ms.n) % 2 = 1);

INSERT INTO f_interacoes_contatos (interacao_id, nome, subsecao)
SELECT
  i.id,
  ELT(
    (i.id % 15) + 1,
    'Mariana Freitas', 'Pedro Nogueira', 'Renata Souza', 'Carlos Lima', 'Ana Costa',
    'Joao Silva', 'Felipe Gomes', 'Patricia Mello', 'Bruno Dias', 'Larissa Rocha',
    'Rita Campos', 'Thiago Prado', 'Clara Ribeiro', 'Davi Moreira', 'Sonia Araujo'
  ) AS nome,
  ELT((i.id % 5) + 1, 'Comercial', 'Credito', 'Atendimento', 'Produtos', 'Operacoes') AS subsecao
FROM f_interacoes i
WHERE i.tags LIKE '%seed_fake_v1%';

INSERT INTO f_interacoes_contatos (interacao_id, nome, subsecao)
SELECT
  i.id,
  ELT(
    ((i.id + 5) % 15) + 1,
    'Mariana Freitas', 'Pedro Nogueira', 'Renata Souza', 'Carlos Lima', 'Ana Costa',
    'Joao Silva', 'Felipe Gomes', 'Patricia Mello', 'Bruno Dias', 'Larissa Rocha',
    'Rita Campos', 'Thiago Prado', 'Clara Ribeiro', 'Davi Moreira', 'Sonia Araujo'
  ) AS nome,
  ELT(((i.id + 1) % 5) + 1, 'Comercial', 'Credito', 'Atendimento', 'Produtos', 'Operacoes') AS subsecao
FROM f_interacoes i
WHERE i.tags LIKE '%seed_fake_v1%'
  AND (i.id % 2 = 0);

-- =========================================================
-- 6) COMPROMISSOS (janela -15 ate +14 dias)
-- =========================================================
INSERT INTO f_compromissos (
  usuario_id,
  tipo_compromisso_id,
  titulo,
  descricao,
  data_inicio,
  data_fim,
  cor
)
SELECT
  IF((d.n % 2) = 0, @u_ademar, @u_aline) AS usuario_id,
  ELT((d.n % 5) + 1, @comp_reuniao, @comp_visita, @comp_ligacao, @comp_tarefa, @comp_outro) AS tipo_compromisso_id,
  CONCAT('Seed Fake Compromisso ', LPAD(d.n + 1, 2, '0')) AS titulo,
  CONCAT('Atividade ficticia para testes do dashboard. Item ', d.n + 1) AS descricao,
  DATE_ADD(DATE_ADD(CURDATE(), INTERVAL (d.n - 15) DAY), INTERVAL (8 + (d.n % 8)) HOUR) AS data_inicio,
  DATE_ADD(DATE_ADD(CURDATE(), INTERVAL (d.n - 15) DAY), INTERVAL (9 + (d.n % 8)) HOUR) AS data_fim,
  ELT((d.n % 4) + 1, '#cc092f', '#1b2563', '#10b981', '#f59e0b') AS cor
FROM (
  SELECT (a.n + b.n * 12) AS n
  FROM tmp_n a
  JOIN (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2) b ON 1 = 1
  WHERE (a.n + b.n * 12) < 30
) d;

-- =========================================================
-- 7) LIMPEZA DE TEMP + COMMIT
-- =========================================================
DROP TEMPORARY TABLE IF EXISTS tmp_agencias_seed;
DROP TEMPORARY TABLE IF EXISTS tmp_months;
DROP TEMPORARY TABLE IF EXISTS tmp_n;

COMMIT;

-- Fim
