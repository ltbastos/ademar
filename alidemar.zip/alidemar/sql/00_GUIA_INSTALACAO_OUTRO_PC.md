# Guia de Instalacao do Banco (Outro Computador)

Este guia recria os bancos no mesmo formato usado neste projeto.

## Pre-requisitos
- XAMPP com `Apache` e `MySQL` ligados.
- Acesso ao MySQL local (`root` sem senha, padrao XAMPP), ou ajuste conforme seu ambiente.
- DBeaver, phpMyAdmin ou cliente SQL de sua preferencia.

## Ordem de execucao (exata)
1. `01_schema_dashboard_visitas.sql`
2. `02_seed_dashboard_visitas.sql`
3. `03_seed_fake_dashboard.sql` (recomendado para testar dashboard com volume)
4. `04_schema_estrutura_mesu.sql`
5. `05_seed_estrutura_mesu_base.sql`

## O que cada arquivo faz
- `01_schema_dashboard_visitas.sql`: cria todo schema da aplicacao (dimensoes e fatos).
- `02_seed_dashboard_visitas.sql`: insere base inicial (Ademar, Aline e dados minimos).
- `03_seed_fake_dashboard.sql`: adiciona massa de dados ficticia para graficos.
- `04_schema_estrutura_mesu.sql`: cria banco `estrutura` e tabela `mesu` com indices.
- `05_seed_estrutura_mesu_base.sql`: cadastra os dois usuarios de acesso (Ademar e Aline).

## Observacoes importantes
- O script `01_schema_dashboard_visitas.sql` faz `DROP DATABASE IF EXISTS dashboard_visitas`.
- O script `04_schema_estrutura_mesu.sql` faz `DROP DATABASE IF EXISTS estrutura`.
- Ou seja: se houver dados locais nesses bancos, eles serao apagados.
- A tabela `mesu` foi configurada com:
  - `id` como chave primaria (facilita edicao no DBeaver),
  - `Email` unico,
  - `Juncao` e `JuncaoSup` com indice normal (nao unico),
  - indice em `FuncionalLetra` para validacao de acesso.

## Validacao rapida apos execucao
Rode:

```sql
SELECT COUNT(*) AS total_usuarios FROM dashboard_visitas.d_usuarios;
SELECT COUNT(*) AS total_visitas FROM dashboard_visitas.f_visitas;
SELECT COUNT(*) AS total_interacoes FROM dashboard_visitas.f_interacoes;
SELECT COUNT(*) AS total_compromissos FROM dashboard_visitas.f_compromissos;

SELECT id, FuncionalLetra, Email, Nome
FROM estrutura.mesu
ORDER BY id;
```

Se os scripts foram executados corretamente, o ambiente fica pronto para a aplicacao subir no outro PC.
