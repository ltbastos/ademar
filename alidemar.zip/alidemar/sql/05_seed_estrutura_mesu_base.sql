-- 05_seed_estrutura_mesu_base.sql
-- Carga base de usuarios com acesso.

USE estrutura;

INSERT INTO mesu (
  id,
  Juncao,
  JuncaoSup,
  Posto,
  FuncionalLetra,
  CodFuncional,
  Email,
  Nome,
  Funcao,
  Nivel,
  Cargo,
  Departamento,
  Area,
  Modificado,
  Aprovador,
  Juncoes_Extras
) VALUES
(
  1,
  4000,
  4000,
  NULL,
  'F750931',
  '6750931',
  'ademar.liberato@bradesco.com.br',
  'ADEMAR OZORIO LIBERATO',
  'DP',
  'DP',
  'CONSULTOR SEGMENTO I',
  '8497-I DIRETORIA EMPRESAS E NEGOCIOS',
  '071 - METODOLOGIA COMERCIAL EMPRESAS',
  '2026-02-02 16:39:00',
  NULL,
  NULL
),
(
  2,
  4000,
  4000,
  NULL,
  'E963052',
  '5963052',
  'aline.rosa@bradesco.com.br',
  'ALINE ROSA DA SILVA',
  'DP',
  'DP',
  'CONSULTOR SEGMENTO I',
  '8497-I DIRETORIA EMPRESAS E NEGOCIOS',
  '071 - METODOLOGIA COMERCIAL EMPRESAS',
  '2026-02-02 16:39:00',
  NULL,
  NULL
)
ON DUPLICATE KEY UPDATE
  Juncao = VALUES(Juncao),
  JuncaoSup = VALUES(JuncaoSup),
  Posto = VALUES(Posto),
  FuncionalLetra = VALUES(FuncionalLetra),
  CodFuncional = VALUES(CodFuncional),
  Nome = VALUES(Nome),
  Funcao = VALUES(Funcao),
  Nivel = VALUES(Nivel),
  Cargo = VALUES(Cargo),
  Departamento = VALUES(Departamento),
  Area = VALUES(Area),
  Modificado = VALUES(Modificado),
  Aprovador = VALUES(Aprovador),
  Juncoes_Extras = VALUES(Juncoes_Extras);

ALTER TABLE mesu AUTO_INCREMENT = 3;
