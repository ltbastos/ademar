-- 04_schema_estrutura_mesu.sql
-- Estrutura organizacional para controle de acesso por FuncionalLetra.
-- Compatível com MySQL antigo (XAMPP).

DROP DATABASE IF EXISTS estrutura;
CREATE DATABASE estrutura CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE estrutura;

CREATE TABLE mesu (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  Juncao INT NULL,
  JuncaoSup INT NULL,
  Posto INT NULL,
  FuncionalLetra VARCHAR(16) NULL,
  CodFuncional VARCHAR(16) NULL,
  Email VARCHAR(191) NOT NULL,
  Nome VARCHAR(200) NULL,
  Funcao VARCHAR(120) NULL,
  Nivel VARCHAR(20) NULL,
  Cargo VARCHAR(200) NULL,
  Departamento VARCHAR(200) NULL,
  Area VARCHAR(200) NULL,
  Modificado DATETIME NULL,
  Aprovador VARCHAR(120) NULL,
  Juncoes_Extras TEXT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_mesu_email (Email),
  KEY idx_mesu_funcional_letra (FuncionalLetra),
  KEY idx_mesu_codfuncional (CodFuncional),
  KEY idx_mesu_juncao (Juncao),
  KEY idx_mesu_juncaosup (JuncaoSup),
  KEY idx_mesu_nome_191 (Nome(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
