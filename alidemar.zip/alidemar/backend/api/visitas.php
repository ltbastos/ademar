<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/db.php';

init_api();

try {
    $db = db_connect();
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        handle_get($db);
    }
    if ($method === 'POST') {
        handle_post($db);
    }
    if ($method === 'PUT') {
        handle_put($db);
    }
    if ($method === 'DELETE') {
        handle_delete($db);
    }

    json_error('Metodo nao permitido.', 405);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}

function handle_get(mysqli $db): void
{
    $id = to_int_or_null($_GET['id'] ?? null);

    if ($id !== null && $id > 0) {
        $visita = get_visita($db, $id);
        if (!$visita) {
            json_error('Visita nao encontrada.', 404);
        }

        $visita['participantes'] = get_visita_participantes($db, $id);
        json_response(['visita' => $visita]);
    }

    $filters = build_list_filters($_GET);
    $whereSql = $filters['where_sql'];
    $types = $filters['types'];
    $params = $filters['params'];

    $limit = to_int_or_null($_GET['limit'] ?? 50) ?? 50;
    $limit = max(1, min(200, $limit));

    $offset = to_int_or_null($_GET['offset'] ?? 0) ?? 0;
    $offset = max(0, $offset);

    $sql = '
        SELECT
            v.id,
            v.usuario_id,
            u.nome AS usuario_nome,
            v.agencia_id,
            a.nome AS agencia_nome,
            a.cidade AS agencia_cidade,
            a.uf AS agencia_uf,
            v.tema_visita_id,
            tv.nome AS tema_visita,
            v.descricao,
            v.demandas,
            v.area_responsavel_id,
            ar.nome AS area_responsavel,
            v.status_demanda_id,
            sd.nome AS status_demanda,
            v.tags,
            v.data_contato,
            v.criado_em,
            v.atualizado_em,
            (SELECT COUNT(*) FROM f_visitas_participantes p WHERE p.visita_id = v.id) AS total_participantes
        FROM f_visitas v
        JOIN d_usuarios u ON u.id = v.usuario_id
        JOIN d_agencias a ON a.id = v.agencia_id
        JOIN d_temas_visita tv ON tv.id = v.tema_visita_id
        LEFT JOIN d_areas_responsaveis ar ON ar.id = v.area_responsavel_id
        LEFT JOIN d_status_demanda sd ON sd.id = v.status_demanda_id
        WHERE 1=1 ' . $whereSql . '
        ORDER BY COALESCE(v.data_contato, v.criado_em) DESC, v.id DESC
        LIMIT ? OFFSET ?
    ';

    $listTypes = $types . 'ii';
    $listParams = array_merge($params, [$limit, $offset]);

    $visitas = db_query_all($db, $sql, $listTypes, $listParams);

    $countSql = 'SELECT COUNT(*) AS total FROM f_visitas v WHERE 1=1 ' . $whereSql;
    $countRow = db_query_one($db, $countSql, $types, $params);

    json_response([
        'visitas' => $visitas,
        'total' => (int) ($countRow['total'] ?? 0),
        'limit' => $limit,
        'offset' => $offset,
    ]);
}

function build_list_filters(array $source): array
{
    $where = [];
    $types = '';
    $params = [];

    $usuarioId = to_int_or_null($source['usuario_id'] ?? null);
    if ($usuarioId !== null && $usuarioId > 0) {
        $where[] = ' AND v.usuario_id = ?';
        $types .= 'i';
        $params[] = $usuarioId;
    }

    $agenciaId = to_int_or_null($source['agencia_id'] ?? null);
    if ($agenciaId !== null && $agenciaId > 0) {
        $where[] = ' AND v.agencia_id = ?';
        $types .= 'i';
        $params[] = $agenciaId;
    }

    $temaId = to_int_or_null($source['tema_visita_id'] ?? null);
    if ($temaId !== null && $temaId > 0) {
        $where[] = ' AND v.tema_visita_id = ?';
        $types .= 'i';
        $params[] = $temaId;
    }

    $statusId = to_int_or_null($source['status_demanda_id'] ?? null);
    if ($statusId !== null && $statusId > 0) {
        $where[] = ' AND v.status_demanda_id = ?';
        $types .= 'i';
        $params[] = $statusId;
    }

    $inicio = to_string_or_null($source['data_inicio'] ?? null);
    if ($inicio !== null) {
        $where[] = ' AND DATE(v.data_contato) >= ?';
        $types .= 's';
        $params[] = $inicio;
    }

    $fim = to_string_or_null($source['data_fim'] ?? null);
    if ($fim !== null) {
        $where[] = ' AND DATE(v.data_contato) <= ?';
        $types .= 's';
        $params[] = $fim;
    }

    $meses = parse_month_refs($source['meses'] ?? null);
    if (count($meses) > 0) {
        $placeholders = implode(', ', array_fill(0, count($meses), '?'));
        $where[] = ' AND DATE_FORMAT(COALESCE(v.data_contato, v.criado_em), "%Y-%m") IN (' . $placeholders . ')';
        $types .= str_repeat('s', count($meses));
        $params = array_merge($params, $meses);
    }

    $busca = to_string_or_null($source['q'] ?? null);
    if ($busca !== null) {
        $like = '%' . $busca . '%';
        $where[] = ' AND (a.nome LIKE ? OR tv.nome LIKE ? OR v.descricao LIKE ? OR v.tags LIKE ?)';
        $types .= 'ssss';
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }

    return [
        'where_sql' => implode('', $where),
        'types' => $types,
        'params' => $params,
    ];
}

function parse_month_refs($raw): array
{
    $text = to_string_or_null($raw);
    if ($text === null) {
        return [];
    }

    $parts = preg_split('/\s*,\s*/', $text) ?: [];
    $valid = [];

    foreach ($parts as $part) {
        if (preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $part) === 1) {
            $valid[$part] = true;
        }
    }

    return array_keys($valid);
}

function handle_post(mysqli $db): void
{
    $payload = json_input();
    require_fields($payload, ['usuario_id', 'agencia_id', 'tema_visita_id', 'descricao']);

    $usuarioId = to_int_or_null($payload['usuario_id']);
    $agenciaId = to_int_or_null($payload['agencia_id']);
    $temaId = to_int_or_null($payload['tema_visita_id']);
    $descricao = to_string_or_null($payload['descricao']);

    if ($usuarioId === null || $agenciaId === null || $temaId === null || $descricao === null) {
        json_error('Campos obrigatorios invalidos para criar visita.', 422);
    }

    $demandas = to_string_or_null($payload['demandas'] ?? null);
    $areaId = to_int_or_null($payload['area_responsavel_id'] ?? null);
    $statusId = to_int_or_null($payload['status_demanda_id'] ?? null);
    $tags = to_string_or_null($payload['tags'] ?? null);
    $dataContato = parse_datetime_or_null($payload['data_contato'] ?? null);

    $participantes = [];
    if (array_key_exists('participantes', $payload)) {
        if (!is_array($payload['participantes'])) {
            json_error('participantes deve ser um array.', 422);
        }
        $participantes = $payload['participantes'];
    }

    $db->begin_transaction();
    try {
        $res = db_execute(
            $db,
            'INSERT INTO f_visitas (usuario_id, agencia_id, tema_visita_id, descricao, demandas, area_responsavel_id, status_demanda_id, tags, data_contato) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            'iiissiiss',
            [$usuarioId, $agenciaId, $temaId, $descricao, $demandas, $areaId, $statusId, $tags, $dataContato]
        );

        $visitaId = (int) $res['insert_id'];

        replace_participantes($db, $visitaId, $participantes);

        $db->commit();

        $visita = get_visita($db, $visitaId);
        $visita['participantes'] = get_visita_participantes($db, $visitaId);

        json_response(['sucesso' => true, 'visita' => $visita], 201);
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }
}

function handle_put(mysqli $db): void
{
    $payload = json_input();
    require_fields($payload, ['id']);

    $id = to_int_or_null($payload['id']);
    if ($id === null || $id <= 0) {
        json_error('ID de visita invalido.', 422);
    }

    if (!get_visita($db, $id)) {
        json_error('Visita nao encontrada.', 404);
    }

    $fields = [];
    $types = '';
    $params = [];

    $map = [
        'usuario_id' => ['usuario_id', 'i'],
        'agencia_id' => ['agencia_id', 'i'],
        'tema_visita_id' => ['tema_visita_id', 'i'],
        'descricao' => ['descricao', 's'],
        'demandas' => ['demandas', 's'],
        'area_responsavel_id' => ['area_responsavel_id', 'i'],
        'status_demanda_id' => ['status_demanda_id', 'i'],
        'tags' => ['tags', 's'],
        'data_contato' => ['data_contato', 's'],
    ];

    foreach ($map as $inputKey => [$column, $type]) {
        if (!array_key_exists($inputKey, $payload)) {
            continue;
        }

        $value = $payload[$inputKey];

        if ($inputKey === 'descricao') {
            $value = to_string_or_null($value);
            if ($value === null) {
                json_error('descricao nao pode ser vazia.', 422);
            }
        } elseif ($inputKey === 'demandas' || $inputKey === 'tags') {
            $value = to_string_or_null($value);
        } elseif ($inputKey === 'data_contato') {
            $value = parse_datetime_or_null($value);
        } else {
            $value = to_int_or_null($value);
            if (in_array($inputKey, ['usuario_id', 'agencia_id', 'tema_visita_id'], true) && ($value === null || $value <= 0)) {
                json_error('Campo invalido para ' . $inputKey, 422);
            }
        }

        $fields[] = $column . ' = ?';
        $types .= $type;
        $params[] = $value;
    }

    $hasParticipantes = array_key_exists('participantes', $payload);
    if (count($fields) === 0 && !$hasParticipantes) {
        json_error('Nenhum campo para atualizar.', 422);
    }

    $db->begin_transaction();
    try {
        if (count($fields) > 0) {
            $params[] = $id;
            $types .= 'i';
            $sql = 'UPDATE f_visitas SET ' . implode(', ', $fields) . ' WHERE id = ?';
            db_execute($db, $sql, $types, $params);
        }

        if ($hasParticipantes) {
            if (!is_array($payload['participantes'])) {
                json_error('participantes deve ser um array.', 422);
            }
            replace_participantes($db, $id, $payload['participantes']);
        }

        $db->commit();

        $visita = get_visita($db, $id);
        $visita['participantes'] = get_visita_participantes($db, $id);

        json_response(['sucesso' => true, 'visita' => $visita]);
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }
}

function handle_delete(mysqli $db): void
{
    $payload = json_input();
    $id = to_int_or_null($payload['id'] ?? ($_GET['id'] ?? null));

    if ($id === null || $id <= 0) {
        json_error('ID de visita invalido para exclusao.', 422);
    }

    $res = db_execute($db, 'DELETE FROM f_visitas WHERE id = ?', 'i', [$id]);
    if ($res['affected_rows'] < 1) {
        json_error('Visita nao encontrada para exclusao.', 404);
    }

    json_response(['sucesso' => true, 'id' => $id]);
}

function replace_participantes(mysqli $db, int $visitaId, array $participantes): void
{
    db_execute($db, 'DELETE FROM f_visitas_participantes WHERE visita_id = ?', 'i', [$visitaId]);

    foreach ($participantes as $p) {
        if (!is_array($p)) {
            continue;
        }

        $nome = to_string_or_null($p['nome'] ?? null);
        if ($nome === null) {
            continue;
        }

        $subsecao = to_string_or_null($p['subsecao'] ?? null);

        db_execute(
            $db,
            'INSERT INTO f_visitas_participantes (visita_id, nome, subsecao) VALUES (?, ?, ?)',
            'iss',
            [$visitaId, $nome, $subsecao]
        );
    }
}

function get_visita(mysqli $db, int $id): ?array
{
    return db_query_one(
        $db,
        '
        SELECT
            v.id,
            v.usuario_id,
            u.nome AS usuario_nome,
            v.agencia_id,
            a.nome AS agencia_nome,
            a.cidade AS agencia_cidade,
            a.uf AS agencia_uf,
            v.tema_visita_id,
            tv.nome AS tema_visita,
            v.descricao,
            v.demandas,
            v.area_responsavel_id,
            ar.nome AS area_responsavel,
            v.status_demanda_id,
            sd.nome AS status_demanda,
            v.tags,
            v.data_contato,
            v.criado_em,
            v.atualizado_em
        FROM f_visitas v
        JOIN d_usuarios u ON u.id = v.usuario_id
        JOIN d_agencias a ON a.id = v.agencia_id
        JOIN d_temas_visita tv ON tv.id = v.tema_visita_id
        LEFT JOIN d_areas_responsaveis ar ON ar.id = v.area_responsavel_id
        LEFT JOIN d_status_demanda sd ON sd.id = v.status_demanda_id
        WHERE v.id = ?
        LIMIT 1
    ',
        'i',
        [$id]
    );
}

function get_visita_participantes(mysqli $db, int $visitaId): array
{
    return db_query_all(
        $db,
        'SELECT id, visita_id, nome, subsecao, criado_em, atualizado_em FROM f_visitas_participantes WHERE visita_id = ? ORDER BY id ASC',
        'i',
        [$visitaId]
    );
}
