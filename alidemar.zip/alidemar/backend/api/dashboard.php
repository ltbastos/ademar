<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/db.php';

init_api();

try {
    $db = db_connect();

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
        json_error('Metodo nao permitido.', 405);
    }

    $usuarioId = to_int_or_null($_GET['usuario_id'] ?? null);
    $agenciaId = to_int_or_null($_GET['agencia_id'] ?? null);
    $funcionarioNome = to_string_or_null($_GET['funcionario_nome'] ?? null);
    $tipoTratativa = resolve_tipo_tratativa($_GET['tipo_tratativa'] ?? 'all');
    $periodo = resolve_periodo($_GET);

    $usarVisitas = $tipoTratativa !== 'interacoes';
    $usarInteracoes = $tipoTratativa !== 'visitas';

    $visitasFiltro = build_fact_filter('v', 'COALESCE(v.data_contato, v.criado_em)', $periodo, $usuarioId, $agenciaId, $funcionarioNome);
    $interacoesFiltro = build_fact_filter('i', 'COALESCE(i.data_contato, i.criado_em)', $periodo, $usuarioId, $agenciaId, $funcionarioNome);
    $compromissosFiltro = build_fact_filter('c', 'c.data_inicio', $periodo, $usuarioId, null, null);

    $kpis = fetch_kpis($db, $visitasFiltro, $interacoesFiltro, $compromissosFiltro, $usarVisitas, $usarInteracoes);
    $visitasTimeline = $usarVisitas ? fetch_timeline_visitas($db, $visitasFiltro) : [];
    $interacoesTimeline = $usarInteracoes ? fetch_timeline_interacoes($db, $interacoesFiltro) : [];
    $interacoesPorTipo = $usarInteracoes ? fetch_interacoes_por_tipo($db, $interacoesFiltro) : [];
    $demandasPorStatus = fetch_demandas_por_status($db, $visitasFiltro, $interacoesFiltro, $usarVisitas, $usarInteracoes);
    $topAgencias = fetch_top_agencias($db, $visitasFiltro, $interacoesFiltro, $usarVisitas, $usarInteracoes);
    $topFuncionarios = fetch_top_funcionarios($db, $visitasFiltro, $interacoesFiltro, $usarVisitas, $usarInteracoes);
    $compromissosHoje = fetch_compromissos_hoje($db, $usuarioId);
    $mesesDisponiveis = fetch_meses_disponiveis($db, $usuarioId, $agenciaId, $funcionarioNome, $usarVisitas, $usarInteracoes);
    $funcionariosDisponiveis = fetch_funcionarios_disponiveis($db, $periodo, $usuarioId, $agenciaId, $usarVisitas, $usarInteracoes);

    json_response([
        'periodo' => $periodo,
        'usuario_id' => $usuarioId,
        'agencia_id' => $agenciaId,
        'funcionario_nome' => $funcionarioNome,
        'tipo_tratativa' => $tipoTratativa,
        'meses_disponiveis' => $mesesDisponiveis,
        'funcionarios_disponiveis' => $funcionariosDisponiveis,
        'kpis' => $kpis,
        'visitas_timeline' => $visitasTimeline,
        'interacoes_timeline' => $interacoesTimeline,
        'interacoes_por_tipo' => $interacoesPorTipo,
        'demandas_por_status' => $demandasPorStatus,
        'top_agencias' => $topAgencias,
        'top_funcionarios' => $topFuncionarios,
        'compromissos_hoje' => $compromissosHoje,
    ]);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}

function resolve_tipo_tratativa(string $input): string
{
    $value = strtolower(trim($input));
    if (!in_array($value, ['all', 'visitas', 'interacoes'], true)) {
        return 'all';
    }

    return $value;
}

function resolve_periodo(array $source): array
{
    $modo = strtolower(trim((string) ($source['periodo_modo'] ?? 'acumulado')));
    if (!in_array($modo, ['acumulado', 'meses'], true)) {
        $modo = 'acumulado';
    }

    $meses = parse_month_refs($source['meses'] ?? null);
    if ($modo === 'meses' && count($meses) > 0) {
        sort($meses);

        $inicio = $meses[0] . '-01';
        $ultimoMes = $meses[count($meses) - 1];
        $fimTs = strtotime($ultimoMes . '-01 +1 month -1 day');

        return [
            'modo' => 'meses',
            'meses' => $meses,
            'data_inicio' => $inicio,
            'data_fim' => date('Y-m-d', $fimTs),
        ];
    }

    return [
        'modo' => 'acumulado',
        'meses' => [],
        'data_inicio' => null,
        'data_fim' => null,
    ];
}

function parse_month_refs($raw): array
{
    $text = to_string_or_null($raw);
    if ($text === null) {
        return [];
    }

    $parts = preg_split('/\s*,\s*/', $text) ?: [];
    $valid = [];

    foreach ($parts as $part) {
        if (preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $part) === 1) {
            $valid[$part] = true;
        }
    }

    return array_keys($valid);
}

function build_fact_filter(string $alias, string $datetimeExpr, array $periodo, ?int $usuarioId, ?int $agenciaId = null, ?string $funcionarioNome = null): array
{
    $clauses = ['1=1'];
    $types = '';
    $params = [];

    if ($periodo['modo'] === 'meses' && count($periodo['meses']) > 0) {
        $placeholders = implode(', ', array_fill(0, count($periodo['meses']), '?'));
        $clauses[] = 'DATE_FORMAT(' . $datetimeExpr . ', "%Y-%m") IN (' . $placeholders . ')';
        $types .= str_repeat('s', count($periodo['meses']));
        $params = array_merge($params, $periodo['meses']);
    }

    if ($usuarioId !== null && $usuarioId > 0) {
        $clauses[] = $alias . '.usuario_id = ?';
        $types .= 'i';
        $params[] = $usuarioId;
    }

    if ($agenciaId !== null && $agenciaId > 0 && in_array($alias, ['v', 'i'], true)) {
        $clauses[] = $alias . '.agencia_id = ?';
        $types .= 'i';
        $params[] = $agenciaId;
    }

    if ($funcionarioNome !== null && $funcionarioNome !== '') {
        if ($alias === 'v') {
            $clauses[] = 'EXISTS (
                SELECT 1
                FROM f_visitas_participantes p
                WHERE p.visita_id = v.id AND LOWER(TRIM(p.nome)) = LOWER(?)
            )';
            $types .= 's';
            $params[] = $funcionarioNome;
        }

        if ($alias === 'i') {
            $clauses[] = '(
                LOWER(TRIM(COALESCE(i.nome_contato, ""))) = LOWER(?)
                OR EXISTS (
                    SELECT 1
                    FROM f_interacoes_contatos c
                    WHERE c.interacao_id = i.id AND LOWER(TRIM(c.nome)) = LOWER(?)
                )
            )';
            $types .= 'ss';
            $params[] = $funcionarioNome;
            $params[] = $funcionarioNome;
        }
    }

    return [
        'where_sql' => implode(' AND ', $clauses),
        'types' => $types,
        'params' => $params,
    ];
}

function fetch_kpis(mysqli $db, array $visitasFiltro, array $interacoesFiltro, array $compromissosFiltro, bool $usarVisitas, bool $usarInteracoes): array
{
    $totalVisitas = 0;
    $totalInteracoes = 0;

    if ($usarVisitas) {
        $row = db_query_one(
            $db,
            'SELECT COUNT(*) AS total FROM f_visitas v WHERE ' . $visitasFiltro['where_sql'],
            $visitasFiltro['types'],
            $visitasFiltro['params']
        );
        $totalVisitas = (int) ($row['total'] ?? 0);
    }

    if ($usarInteracoes) {
        $row = db_query_one(
            $db,
            'SELECT COUNT(*) AS total FROM f_interacoes i WHERE ' . $interacoesFiltro['where_sql'],
            $interacoesFiltro['types'],
            $interacoesFiltro['params']
        );
        $totalInteracoes = (int) ($row['total'] ?? 0);
    }

    $compRow = db_query_one(
        $db,
        'SELECT COUNT(*) AS total FROM f_compromissos c WHERE ' . $compromissosFiltro['where_sql'],
        $compromissosFiltro['types'],
        $compromissosFiltro['params']
    );

    $demandaParts = [];
    $demandaTypes = '';
    $demandaParams = [];

    if ($usarVisitas) {
        $demandaParts[] = '
            SELECT COUNT(*) AS qtd
            FROM f_visitas v
            JOIN d_status_demanda sd ON sd.id = v.status_demanda_id
            WHERE ' . $visitasFiltro['where_sql'] . ' AND sd.nome IN ("Em Andamento", "Nao Iniciado")
        ';
        $demandaTypes .= $visitasFiltro['types'];
        $demandaParams = array_merge($demandaParams, $visitasFiltro['params']);
    }

    if ($usarInteracoes) {
        $demandaParts[] = '
            SELECT COUNT(*) AS qtd
            FROM f_interacoes i
            JOIN d_status_demanda sd ON sd.id = i.status_demanda_id
            WHERE ' . $interacoesFiltro['where_sql'] . ' AND sd.nome IN ("Em Andamento", "Nao Iniciado")
        ';
        $demandaTypes .= $interacoesFiltro['types'];
        $demandaParams = array_merge($demandaParams, $interacoesFiltro['params']);
    }

    $demandasAbertas = 0;
    if (count($demandaParts) > 0) {
        $demandaSql = 'SELECT SUM(qtd) AS total_abertas FROM (' . implode(' UNION ALL ', $demandaParts) . ') t';
        $row = db_query_one($db, $demandaSql, $demandaTypes, $demandaParams);
        $demandasAbertas = (int) ($row['total_abertas'] ?? 0);
    }

    return [
        'total_visitas' => $totalVisitas,
        'total_interacoes' => $totalInteracoes,
        'total_registros' => $totalVisitas + $totalInteracoes,
        'total_compromissos_periodo' => (int) ($compRow['total'] ?? 0),
        'demandas_abertas' => $demandasAbertas,
    ];
}

function fetch_timeline_visitas(mysqli $db, array $filtro): array
{
    return db_query_all(
        $db,
        '
        SELECT DATE(COALESCE(v.data_contato, v.criado_em)) AS data, COUNT(*) AS quantidade
        FROM f_visitas v
        WHERE ' . $filtro['where_sql'] . '
        GROUP BY DATE(COALESCE(v.data_contato, v.criado_em))
        ORDER BY data ASC
    ',
        $filtro['types'],
        $filtro['params']
    );
}

function fetch_timeline_interacoes(mysqli $db, array $filtro): array
{
    return db_query_all(
        $db,
        '
        SELECT DATE(COALESCE(i.data_contato, i.criado_em)) AS data, COUNT(*) AS quantidade
        FROM f_interacoes i
        WHERE ' . $filtro['where_sql'] . '
        GROUP BY DATE(COALESCE(i.data_contato, i.criado_em))
        ORDER BY data ASC
    ',
        $filtro['types'],
        $filtro['params']
    );
}

function fetch_interacoes_por_tipo(mysqli $db, array $filtro): array
{
    return db_query_all(
        $db,
        '
        SELECT ti.nome AS tipo, COUNT(*) AS quantidade
        FROM f_interacoes i
        JOIN d_tipos_interacao ti ON ti.id = i.tipo_interacao_id
        WHERE ' . $filtro['where_sql'] . '
        GROUP BY ti.nome
        ORDER BY quantidade DESC, ti.nome ASC
    ',
        $filtro['types'],
        $filtro['params']
    );
}

function fetch_demandas_por_status(mysqli $db, array $visitasFiltro, array $interacoesFiltro, bool $usarVisitas, bool $usarInteracoes): array
{
    if ($usarVisitas && !$usarInteracoes) {
        return db_query_all(
            $db,
            '
            SELECT COALESCE(sd.nome, "Sem Status") AS status, COUNT(*) AS quantidade
            FROM f_visitas v
            LEFT JOIN d_status_demanda sd ON sd.id = v.status_demanda_id
            WHERE ' . $visitasFiltro['where_sql'] . '
            GROUP BY COALESCE(sd.nome, "Sem Status")
            ORDER BY quantidade DESC, status ASC
        ',
            $visitasFiltro['types'],
            $visitasFiltro['params']
        );
    }

    if (!$usarVisitas && $usarInteracoes) {
        return db_query_all(
            $db,
            '
            SELECT COALESCE(sd.nome, "Sem Status") AS status, COUNT(*) AS quantidade
            FROM f_interacoes i
            LEFT JOIN d_status_demanda sd ON sd.id = i.status_demanda_id
            WHERE ' . $interacoesFiltro['where_sql'] . '
            GROUP BY COALESCE(sd.nome, "Sem Status")
            ORDER BY quantidade DESC, status ASC
        ',
            $interacoesFiltro['types'],
            $interacoesFiltro['params']
        );
    }

    return db_query_all(
        $db,
        '
        SELECT status, SUM(quantidade) AS quantidade
        FROM (
            SELECT COALESCE(sd.nome, "Sem Status") AS status, COUNT(*) AS quantidade
            FROM f_visitas v
            LEFT JOIN d_status_demanda sd ON sd.id = v.status_demanda_id
            WHERE ' . $visitasFiltro['where_sql'] . '
            GROUP BY COALESCE(sd.nome, "Sem Status")

            UNION ALL

            SELECT COALESCE(sd.nome, "Sem Status") AS status, COUNT(*) AS quantidade
            FROM f_interacoes i
            LEFT JOIN d_status_demanda sd ON sd.id = i.status_demanda_id
            WHERE ' . $interacoesFiltro['where_sql'] . '
            GROUP BY COALESCE(sd.nome, "Sem Status")
        ) t
        GROUP BY status
        ORDER BY quantidade DESC, status ASC
    ',
        $visitasFiltro['types'] . $interacoesFiltro['types'],
        array_merge($visitasFiltro['params'], $interacoesFiltro['params'])
    );
}

function fetch_top_agencias(mysqli $db, array $visitasFiltro, array $interacoesFiltro, bool $usarVisitas, bool $usarInteracoes): array
{
    if ($usarVisitas && !$usarInteracoes) {
        return db_query_all(
            $db,
            '
            SELECT ag.id AS agencia_id, ag.nome AS agencia_nome, v.total_visitas, 0 AS total_interacoes, v.total_visitas AS total
            FROM d_agencias ag
            JOIN (
                SELECT v.agencia_id, COUNT(*) AS total_visitas
                FROM f_visitas v
                WHERE ' . $visitasFiltro['where_sql'] . '
                GROUP BY v.agencia_id
            ) v ON v.agencia_id = ag.id
            ORDER BY total DESC, ag.nome ASC
            LIMIT 20
        ',
            $visitasFiltro['types'],
            $visitasFiltro['params']
        );
    }

    if (!$usarVisitas && $usarInteracoes) {
        return db_query_all(
            $db,
            '
            SELECT ag.id AS agencia_id, ag.nome AS agencia_nome, 0 AS total_visitas, i.total_interacoes, i.total_interacoes AS total
            FROM d_agencias ag
            JOIN (
                SELECT i.agencia_id, COUNT(*) AS total_interacoes
                FROM f_interacoes i
                WHERE ' . $interacoesFiltro['where_sql'] . ' AND i.agencia_id IS NOT NULL
                GROUP BY i.agencia_id
            ) i ON i.agencia_id = ag.id
            ORDER BY total DESC, ag.nome ASC
            LIMIT 20
        ',
            $interacoesFiltro['types'],
            $interacoesFiltro['params']
        );
    }

    return db_query_all(
        $db,
        '
        SELECT
            ag.id AS agencia_id,
            ag.nome AS agencia_nome,
            COALESCE(v.total_visitas, 0) AS total_visitas,
            COALESCE(i.total_interacoes, 0) AS total_interacoes,
            (COALESCE(v.total_visitas, 0) + COALESCE(i.total_interacoes, 0)) AS total
        FROM d_agencias ag
        LEFT JOIN (
            SELECT v.agencia_id, COUNT(*) AS total_visitas
            FROM f_visitas v
            WHERE ' . $visitasFiltro['where_sql'] . '
            GROUP BY v.agencia_id
        ) v ON v.agencia_id = ag.id
        LEFT JOIN (
            SELECT i.agencia_id, COUNT(*) AS total_interacoes
            FROM f_interacoes i
            WHERE ' . $interacoesFiltro['where_sql'] . ' AND i.agencia_id IS NOT NULL
            GROUP BY i.agencia_id
        ) i ON i.agencia_id = ag.id
        WHERE (COALESCE(v.total_visitas, 0) + COALESCE(i.total_interacoes, 0)) > 0
        ORDER BY total DESC, ag.nome ASC
        LIMIT 20
    ',
        $visitasFiltro['types'] . $interacoesFiltro['types'],
        array_merge($visitasFiltro['params'], $interacoesFiltro['params'])
    );
}

function fetch_top_funcionarios(mysqli $db, array $visitasFiltro, array $interacoesFiltro, bool $usarVisitas, bool $usarInteracoes): array
{
    $agregado = [];

    if ($usarVisitas) {
        $rows = db_query_all(
            $db,
            '
            SELECT TRIM(p.nome) AS funcionario_nome, COUNT(*) AS total_visitas
            FROM f_visitas_participantes p
            JOIN f_visitas v ON v.id = p.visita_id
            WHERE ' . $visitasFiltro['where_sql'] . ' AND p.nome IS NOT NULL AND TRIM(p.nome) <> ""
            GROUP BY TRIM(p.nome)
        ',
            $visitasFiltro['types'],
            $visitasFiltro['params']
        );

        foreach ($rows as $row) {
            $nome = trim((string) ($row['funcionario_nome'] ?? ''));
            if ($nome === '') {
                continue;
            }

            if (!isset($agregado[$nome])) {
                $agregado[$nome] = [
                    'funcionario_nome' => $nome,
                    'total_visitas' => 0,
                    'total_interacoes' => 0,
                    'total' => 0,
                ];
            }

            $agregado[$nome]['total_visitas'] += (int) ($row['total_visitas'] ?? 0);
        }
    }

    if ($usarInteracoes) {
        $rows = db_query_all(
            $db,
            '
            SELECT nome, COUNT(*) AS total_interacoes
            FROM (
                SELECT DISTINCT i.id AS registro_id, TRIM(i.nome_contato) AS nome
                FROM f_interacoes i
                WHERE ' . $interacoesFiltro['where_sql'] . ' AND i.nome_contato IS NOT NULL AND TRIM(i.nome_contato) <> ""

                UNION

                SELECT DISTINCT i.id AS registro_id, TRIM(c.nome) AS nome
                FROM f_interacoes i
                JOIN f_interacoes_contatos c ON c.interacao_id = i.id
                WHERE ' . $interacoesFiltro['where_sql'] . ' AND c.nome IS NOT NULL AND TRIM(c.nome) <> ""
            ) nomes
            GROUP BY nome
        ',
            $interacoesFiltro['types'] . $interacoesFiltro['types'],
            array_merge($interacoesFiltro['params'], $interacoesFiltro['params'])
        );

        foreach ($rows as $row) {
            $nome = trim((string) ($row['nome'] ?? ''));
            if ($nome === '') {
                continue;
            }

            if (!isset($agregado[$nome])) {
                $agregado[$nome] = [
                    'funcionario_nome' => $nome,
                    'total_visitas' => 0,
                    'total_interacoes' => 0,
                    'total' => 0,
                ];
            }

            $agregado[$nome]['total_interacoes'] += (int) ($row['total_interacoes'] ?? 0);
        }
    }

    $saida = [];
    foreach ($agregado as $nome => $item) {
        $item['total'] = (int) $item['total_visitas'] + (int) $item['total_interacoes'];
        if ($item['total'] > 0) {
            $saida[] = $item;
        }
    }

    usort($saida, static function (array $a, array $b): int {
        $delta = ((int) $b['total']) <=> ((int) $a['total']);
        if ($delta !== 0) {
            return $delta;
        }

        return strcmp((string) $a['funcionario_nome'], (string) $b['funcionario_nome']);
    });

    return array_slice($saida, 0, 20);
}

function fetch_meses_disponiveis(mysqli $db, ?int $usuarioId, ?int $agenciaId, ?string $funcionarioNome, bool $usarVisitas, bool $usarInteracoes): array
{
    $parts = [];
    $types = '';
    $params = [];

    if ($usarVisitas) {
        $sql = 'SELECT DISTINCT DATE_FORMAT(COALESCE(v.data_contato, v.criado_em), "%Y-%m") AS mes_ref FROM f_visitas v WHERE 1=1';
        if ($usuarioId !== null && $usuarioId > 0) {
            $sql .= ' AND v.usuario_id = ?';
            $types .= 'i';
            $params[] = $usuarioId;
        }
        if ($agenciaId !== null && $agenciaId > 0) {
            $sql .= ' AND v.agencia_id = ?';
            $types .= 'i';
            $params[] = $agenciaId;
        }
        if ($funcionarioNome !== null && $funcionarioNome !== '') {
            $sql .= ' AND EXISTS (
                SELECT 1 FROM f_visitas_participantes p
                WHERE p.visita_id = v.id AND LOWER(TRIM(p.nome)) = LOWER(?)
            )';
            $types .= 's';
            $params[] = $funcionarioNome;
        }
        $parts[] = $sql;
    }

    if ($usarInteracoes) {
        $sql = 'SELECT DISTINCT DATE_FORMAT(COALESCE(i.data_contato, i.criado_em), "%Y-%m") AS mes_ref FROM f_interacoes i WHERE 1=1';
        if ($usuarioId !== null && $usuarioId > 0) {
            $sql .= ' AND i.usuario_id = ?';
            $types .= 'i';
            $params[] = $usuarioId;
        }
        if ($agenciaId !== null && $agenciaId > 0) {
            $sql .= ' AND i.agencia_id = ?';
            $types .= 'i';
            $params[] = $agenciaId;
        }
        if ($funcionarioNome !== null && $funcionarioNome !== '') {
            $sql .= ' AND (
                LOWER(TRIM(COALESCE(i.nome_contato, ""))) = LOWER(?)
                OR EXISTS (
                    SELECT 1 FROM f_interacoes_contatos c
                    WHERE c.interacao_id = i.id AND LOWER(TRIM(c.nome)) = LOWER(?)
                )
            )';
            $types .= 'ss';
            $params[] = $funcionarioNome;
            $params[] = $funcionarioNome;
        }
        $parts[] = $sql;
    }

    if (count($parts) === 0) {
        return [];
    }

    $sql = 'SELECT mes_ref FROM (' . implode(' UNION ', $parts) . ') t WHERE mes_ref IS NOT NULL GROUP BY mes_ref ORDER BY mes_ref DESC';
    $rows = db_query_all($db, $sql, $types, $params);

    $out = [];
    foreach ($rows as $row) {
        $mesRef = $row['mes_ref'] ?? null;
        if (!$mesRef) {
            continue;
        }

        $out[] = [
            'mes_ref' => $mesRef,
            'label' => month_label_pt($mesRef),
        ];
    }

    return $out;
}

function fetch_funcionarios_disponiveis(mysqli $db, array $periodo, ?int $usuarioId, ?int $agenciaId, bool $usarVisitas, bool $usarInteracoes): array
{
    $visitasFiltro = build_fact_filter('v', 'COALESCE(v.data_contato, v.criado_em)', $periodo, $usuarioId, $agenciaId, null);
    $interacoesFiltro = build_fact_filter('i', 'COALESCE(i.data_contato, i.criado_em)', $periodo, $usuarioId, $agenciaId, null);

    $nomes = [];

    if ($usarVisitas) {
        $rows = db_query_all(
            $db,
            '
            SELECT DISTINCT TRIM(p.nome) AS nome
            FROM f_visitas_participantes p
            JOIN f_visitas v ON v.id = p.visita_id
            WHERE ' . $visitasFiltro['where_sql'] . ' AND p.nome IS NOT NULL AND TRIM(p.nome) <> ""
        ',
            $visitasFiltro['types'],
            $visitasFiltro['params']
        );

        foreach ($rows as $row) {
            $nome = trim((string) ($row['nome'] ?? ''));
            if ($nome !== '') {
                $nomes[$nome] = true;
            }
        }
    }

    if ($usarInteracoes) {
        $rows = db_query_all(
            $db,
            '
            SELECT DISTINCT nome
            FROM (
                SELECT TRIM(i.nome_contato) AS nome
                FROM f_interacoes i
                WHERE ' . $interacoesFiltro['where_sql'] . ' AND i.nome_contato IS NOT NULL AND TRIM(i.nome_contato) <> ""

                UNION

                SELECT TRIM(c.nome) AS nome
                FROM f_interacoes i
                JOIN f_interacoes_contatos c ON c.interacao_id = i.id
                WHERE ' . $interacoesFiltro['where_sql'] . ' AND c.nome IS NOT NULL AND TRIM(c.nome) <> ""
            ) x
        ',
            $interacoesFiltro['types'] . $interacoesFiltro['types'],
            array_merge($interacoesFiltro['params'], $interacoesFiltro['params'])
        );

        foreach ($rows as $row) {
            $nome = trim((string) ($row['nome'] ?? ''));
            if ($nome !== '') {
                $nomes[$nome] = true;
            }
        }
    }

    $lista = array_keys($nomes);
    sort($lista, SORT_NATURAL | SORT_FLAG_CASE);

    return array_map(static function (string $nome): array {
        return ['nome' => $nome];
    }, $lista);
}

function month_label_pt(string $mesRef): string
{
    $meses = [
        '01' => 'Jan',
        '02' => 'Fev',
        '03' => 'Mar',
        '04' => 'Abr',
        '05' => 'Mai',
        '06' => 'Jun',
        '07' => 'Jul',
        '08' => 'Ago',
        '09' => 'Set',
        '10' => 'Out',
        '11' => 'Nov',
        '12' => 'Dez',
    ];

    $year = substr($mesRef, 0, 4);
    $month = substr($mesRef, 5, 2);

    return ($meses[$month] ?? $month) . ' - ' . $year;
}

function fetch_compromissos_hoje(mysqli $db, ?int $usuarioId): array
{
    $where = ['c.data_inicio >= NOW()'];
    $types = '';
    $params = [];

    if ($usuarioId !== null && $usuarioId > 0) {
        $where[] = 'c.usuario_id = ?';
        $types .= 'i';
        $params[] = $usuarioId;
    }

    return db_query_all(
        $db,
        '
        SELECT
            c.id,
            c.titulo,
            c.data_inicio,
            c.data_fim,
            u.nome AS usuario_nome,
            tc.nome AS tipo_compromisso,
            COALESCE(c.cor, tc.cor_padrao) AS cor
        FROM f_compromissos c
        JOIN d_usuarios u ON u.id = c.usuario_id
        JOIN d_tipos_compromisso tc ON tc.id = c.tipo_compromisso_id
        WHERE ' . implode(' AND ', $where) . '
        ORDER BY c.data_inicio ASC
        LIMIT 50
    ',
        $types,
        $params
    );
}
