(() => {
  const API_ROOT = "backend/api";
  const MONTHS_PT = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
  const ENABLE_ACCESS_VALIDATION = false;

  const state = {
    dimensoes: {
      usuarios: [],
      agencias: [],
      temas_visita: [],
      tipos_interacao: [],
      areas_responsaveis: [],
      status_demanda: [],
      tipos_compromisso: [],
    },
    filtros: {
      periodoModo: "meses",
      meses: [currentMonthRef()],
      usuarioId: null,
      tipoTratativa: "all",
      agenciaId: null,
      funcionarioNome: null,
    },
    volumeAgrupamento: "agencia",
    dashboard: null,
    charts: {},
    view: "dashboard",
    acesso: {
      autorizado: false,
      carregado: false,
      funcionalLogin: null,
      identidade: null,
      registro: null,
    },
  };

  const dom = {};
  let feedbackTimer = null;
  let dashboardSyncTimer = null;
  let resizeSyncTimer = null;

  document.addEventListener("DOMContentLoaded", init);

  async function init() {
    cacheDom();
    bindEvents();
    applyTheme(loadTheme());
    syncFilterInputs();
    setPeriodoUiState();

    try {
      // Validacao de acesso pronta para uso.
      // Para reativar, altere ENABLE_ACCESS_VALIDATION para true.
      if (ENABLE_ACCESS_VALIDATION) {
        const access = await loadAccessContext();
        if (!access.autorizado) {
          lockApplication(access);
          return;
        }
      } else {
        await loadWindowsIdentityOnly();
      }

      unlockApplication();
      await loadDimensions();
      await applyFiltersAndRefresh("Filtros carregados.");
      scheduleDashboardChartSync(160);
      if (document.fonts && document.fonts.ready) {
        document.fonts.ready
          .then(() => {
            scheduleDashboardChartSync(30);
          })
          .catch(() => {});
      }
    } catch (error) {
      if (ENABLE_ACCESS_VALIDATION) {
        lockApplication({
          autorizado: false,
          funcional_login: null,
          mensagem: "Nao foi possivel validar o acesso no momento.",
        });
      }
      showFeedback(error.message, "error");
    }
  }

  function cacheDom() {
    dom.navButtons = Array.from(document.querySelectorAll(".nav-btn"));
    dom.views = Array.from(document.querySelectorAll(".view"));
    dom.viewTitle = document.getElementById("view-title");
    dom.windowsUserEmail = document.getElementById("windows-user-email");
    dom.feedback = document.getElementById("global-feedback");
    dom.accessOverlay = document.getElementById("access-overlay");
    dom.accessOverlayTitle = document.getElementById("access-overlay-title");
    dom.accessOverlayMessage = document.getElementById("access-overlay-message");

    dom.filtroPeriodoDropdown = document.getElementById("filtro-periodo-dropdown");
    dom.btnPeriodoDropdown = document.getElementById("btn-periodo-dropdown");
    dom.periodoDropdownPanel = document.getElementById("periodo-dropdown-panel");
    dom.periodoAcumulado = document.getElementById("periodo-acumulado");
    dom.periodoMesesOptions = document.getElementById("periodo-meses-options");
    dom.filtroUsuarioGlobal = document.getElementById("filtro-usuario-global");
    dom.filtroTratativaGlobal = document.getElementById("filtro-tratativa-global");
    dom.filtroAgenciaGlobal = document.getElementById("filtro-agencia-global");
    dom.filtroFuncionarioGlobal = document.getElementById("filtro-funcionario-global");
    dom.btnAplicarFiltros = document.getElementById("btn-aplicar-filtros");
    dom.btnLimparFiltros = document.getElementById("btn-limpar-filtros");
    dom.sidebarSelectedUser = document.getElementById("sidebar-selected-user");
    dom.themeSwitchInput = document.getElementById("theme-switch-input");
    dom.btnOpenQuickAdd = document.getElementById("btn-open-quick-add");
    dom.quickAddModal = document.getElementById("quick-add-modal");
    dom.btnCloseQuickAdd = document.getElementById("btn-close-quick-add");
    dom.formQuickAdd = document.getElementById("form-quick-add");
    dom.quickAddTipo = document.getElementById("quick-add-tipo");
    dom.quickFieldsInteracao = document.getElementById("quick-fields-interacao");
    dom.quickFieldsVisita = document.getElementById("quick-fields-visita");
    dom.quickFieldsCompromisso = document.getElementById("quick-fields-compromisso");
    dom.toggleVolumeGroup = document.getElementById("toggle-volume-group");
    dom.chartVolumeTitle = document.getElementById("chart-volume-title");

    dom.kpiTotalVisitas = document.getElementById("kpi-total-visitas");
    dom.kpiTotalInteracoes = document.getElementById("kpi-total-interacoes");
    dom.kpiTotalRegistros = document.getElementById("kpi-total-registros");
    dom.kpiDemandasAbertas = document.getElementById("kpi-demandas-abertas");
    dom.kpiTotalCompromissos = document.getElementById("kpi-total-compromissos");
    dom.kpiCardVisitas = document.getElementById("kpi-card-visitas");
    dom.kpiCardInteracoes = document.getElementById("kpi-card-interacoes");

    dom.listaCompromissosHoje = document.getElementById("lista-compromissos-hoje");
    dom.listaVisitas = document.getElementById("lista-visitas");
    dom.listaInteracoes = document.getElementById("lista-interacoes");
    dom.listaCompromissos = document.getElementById("lista-compromissos");

    dom.formVisita = document.getElementById("form-visita");
    dom.formInteracao = document.getElementById("form-interacao");
    dom.formCompromisso = document.getElementById("form-compromisso");
  }

  function bindEvents() {
    dom.navButtons.forEach((btn) => {
      btn.addEventListener("click", () => switchView(btn.dataset.view));
    });

    dom.btnPeriodoDropdown.addEventListener("click", (event) => {
      event.stopPropagation();
      const isOpen = !dom.periodoDropdownPanel.classList.contains("is-hidden");
      togglePeriodoDropdown(!isOpen);
    });

    dom.periodoAcumulado.addEventListener("change", () => {
      state.filtros.periodoModo = dom.periodoAcumulado.checked ? "acumulado" : "meses";
      if (!dom.periodoAcumulado.checked && state.filtros.meses.length === 0) {
        const firstRef = dom.periodoMesesOptions.querySelector('input[type="checkbox"]')?.value;
        if (firstRef) {
          state.filtros.meses = [firstRef];
        }
      }
      setPeriodoUiState();
    });

    dom.periodoMesesOptions.addEventListener("change", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLInputElement) || target.type !== "checkbox") {
        return;
      }
      state.filtros.meses = getCheckedMonthsFromDropdown();
      if (state.filtros.meses.length > 0) {
        state.filtros.periodoModo = "meses";
        dom.periodoAcumulado.checked = false;
      }
      setPeriodoUiState();
    });

    dom.btnAplicarFiltros.addEventListener("click", async () => {
      await applyFiltersAndRefresh("Filtros aplicados.");
    });

    dom.btnLimparFiltros.addEventListener("click", async () => {
      clearAllFilters();
      await applyFiltersAndRefresh("Filtros limpos.");
    });

    dom.filtroUsuarioGlobal.addEventListener("change", () => {
      const userValue = dom.filtroUsuarioGlobal.value;
      const userId = userValue && userValue !== "all" ? toInt(userValue) : null;
      updateSidebarSelectedUser(userId);
    });

    dom.themeSwitchInput.addEventListener("change", () => {
      applyTheme(dom.themeSwitchInput.checked ? "dark" : "light");
      if (state.dashboard) {
        renderDashboard();
      }
    });

    dom.btnOpenQuickAdd.addEventListener("click", () => {
      openQuickAddModal();
    });

    dom.btnCloseQuickAdd.addEventListener("click", () => {
      closeQuickAddModal();
    });

    dom.quickAddModal.addEventListener("click", (event) => {
      if (event.target === dom.quickAddModal) {
        closeQuickAddModal();
      }
    });

    dom.quickAddTipo.addEventListener("change", () => {
      updateQuickAddTypeUi();
    });

    dom.formQuickAdd.addEventListener("submit", onSubmitQuickAdd);

    dom.toggleVolumeGroup.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) {
        return;
      }

      const btn = target.closest(".toggle-btn");
      if (!btn) {
        return;
      }

      const agrupamento = btn.dataset.agrupamento === "funcionario" ? "funcionario" : "agencia";
      state.volumeAgrupamento = agrupamento;
      updateVolumeToggleButtons();
      renderVolumeChart();
    });

    dom.formVisita.addEventListener("submit", onSubmitVisita);
    dom.formInteracao.addEventListener("submit", onSubmitInteracao);
    dom.formCompromisso.addEventListener("submit", onSubmitCompromisso);

    document.addEventListener("click", (event) => {
      if (!(event.target instanceof Node)) {
        return;
      }
      if (!dom.filtroPeriodoDropdown.contains(event.target)) {
        togglePeriodoDropdown(false);
      }
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        togglePeriodoDropdown(false);
        closeQuickAddModal();
      }
    });

    window.addEventListener("load", () => {
      scheduleDashboardChartSync(40);
    });

    window.addEventListener("resize", () => {
      if (resizeSyncTimer) {
        clearTimeout(resizeSyncTimer);
      }
      resizeSyncTimer = setTimeout(() => {
        scheduleDashboardChartSync(0);
      }, 140);
    });
  }

  function switchView(viewId) {
    state.view = viewId;
    dom.navButtons.forEach((btn) => btn.classList.toggle("is-active", btn.dataset.view === viewId));
    dom.views.forEach((section) => section.classList.toggle("is-active", section.id === `view-${viewId}`));

    const meta = {
      dashboard: {
        title: "Painel de GestÃ£o dos Gerentes de Segmento",
      },
      visitas: {
        title: "Visitas",
      },
      interacoes: {
        title: "InteraÃ§Ãµes",
      },
      compromissos: {
        title: "Compromissos",
      },
    }[viewId];

    dom.viewTitle.textContent = meta.title;

    if (viewId === "dashboard") {
      scheduleDashboardChartSync(40);
    }
  }

  async function loadDimensions() {
    const payload = await apiGet("dimensoes.php?tipo=all");
    state.dimensoes = payload.dados || state.dimensoes;
    populateAllSelects();
    populateQuickAddSelects();
    syncFilterInputs();
    updateSidebarSelectedUser();
  }

  function populateAllSelects() {
    fillSelect(dom.filtroUsuarioGlobal, state.dimensoes.usuarios, {
      includeAll: true,
      allLabel: "Todos",
    });
    fillSelect(dom.filtroAgenciaGlobal, state.dimensoes.agencias, {
      includeAll: true,
      allLabel: "Todas",
    });
    fillSelect(dom.filtroFuncionarioGlobal, [], {
      includeAll: true,
      allLabel: "Todos",
      valueKey: "nome",
      labelKey: "nome",
    });

    fillSelect(document.getElementById("visita-usuario"), state.dimensoes.usuarios);
    fillSelect(document.getElementById("interacao-usuario"), state.dimensoes.usuarios);
    fillSelect(document.getElementById("compromisso-usuario"), state.dimensoes.usuarios);

    fillSelect(document.getElementById("visita-agencia"), state.dimensoes.agencias);
    fillSelect(document.getElementById("interacao-agencia"), state.dimensoes.agencias, { optional: true });

    fillSelect(document.getElementById("visita-tema"), state.dimensoes.temas_visita);
    fillSelect(document.getElementById("interacao-tipo"), state.dimensoes.tipos_interacao);

    fillSelect(document.getElementById("visita-area"), state.dimensoes.areas_responsaveis, { optional: true });
    fillSelect(document.getElementById("interacao-area"), state.dimensoes.areas_responsaveis, { optional: true });

    fillSelect(document.getElementById("visita-status"), state.dimensoes.status_demanda, { optional: true });
    fillSelect(document.getElementById("interacao-status"), state.dimensoes.status_demanda, { optional: true });

    fillSelect(document.getElementById("compromisso-tipo"), state.dimensoes.tipos_compromisso);

    applyGlobalUserToForms();
  }

  function populateQuickAddSelects() {
    fillSelect(document.getElementById("quick-interacao-usuario"), state.dimensoes.usuarios);
    fillSelect(document.getElementById("quick-visita-usuario"), state.dimensoes.usuarios);
    fillSelect(document.getElementById("quick-compromisso-usuario"), state.dimensoes.usuarios);

    fillSelect(document.getElementById("quick-interacao-tipo"), state.dimensoes.tipos_interacao);
    fillSelect(document.getElementById("quick-interacao-agencia"), state.dimensoes.agencias, { optional: true });
    fillSelect(document.getElementById("quick-interacao-status"), state.dimensoes.status_demanda, { optional: true });

    fillSelect(document.getElementById("quick-visita-agencia"), state.dimensoes.agencias);
    fillSelect(document.getElementById("quick-visita-tema"), state.dimensoes.temas_visita);
    fillSelect(document.getElementById("quick-visita-status"), state.dimensoes.status_demanda, { optional: true });

    fillSelect(document.getElementById("quick-compromisso-tipo"), state.dimensoes.tipos_compromisso);
    updateQuickAddTypeUi();
  }

  function fillSelect(select, rows, options = {}) {
    if (!select) {
      return;
    }

    const includeAll = options.includeAll === true;
    const optional = options.optional === true;
    const allLabel = options.allLabel || "Todos";
    const valueKey = options.valueKey || "id";
    const labelKey = options.labelKey || "nome";

    const currentValue = select.value;
    const fragment = document.createDocumentFragment();

    if (includeAll) {
      fragment.appendChild(new Option(allLabel, "all"));
    }
    if (optional) {
      fragment.appendChild(new Option("NÃ£o informado", ""));
    }

    rows.forEach((row) => {
      fragment.appendChild(new Option(String(row[labelKey] ?? ""), String(row[valueKey] ?? "")));
    });

    select.innerHTML = "";
    select.appendChild(fragment);

    if (currentValue !== "" && Array.from(select.options).some((opt) => opt.value === currentValue)) {
      select.value = currentValue;
    }
  }

  async function applyFiltersAndRefresh(message) {
    readFiltersFromInputs();
    togglePeriodoDropdown(false);
    if (state.filtros.periodoModo === "meses" && state.filtros.meses.length === 0) {
      const first = dom.periodoMesesOptions.querySelector('input[type="checkbox"]')?.value;
      if (first) {
        state.filtros.meses = [first];
      }
    }

    await refreshAllData(message);
  }

  async function refreshAllData(message = "") {
    try {
      await loadDashboard();
      await Promise.all([loadVisitasList(), loadInteracoesList(), loadCompromissosList()]);
      scheduleDashboardChartSync(80);
      if (message) {
        showFeedback(message, "success");
      }
    } catch (error) {
      showFeedback(error.message, "error");
    }
  }

  async function loadDashboard(retryWithAdjustedMonths = true) {
    const query = buildDashboardQuery();
    const response = await apiGet(`dashboard.php?${query.toString()}`);
    state.dashboard = response;

    const funcionariosChanged = populateFuncionariosSelect(response.funcionarios_disponiveis || []);
    const monthsChanged = populateMonthsSelect(response.meses_disponiveis || []);
    renderDashboard();

    if (retryWithAdjustedMonths && state.filtros.periodoModo === "meses" && (monthsChanged || funcionariosChanged)) {
      await loadDashboard(false);
    }
  }

  function populateFuncionariosSelect(rows) {
    const before = state.filtros.funcionarioNome || "all";
    const options = Array.isArray(rows) ? rows : [];
    const available = new Set(options.map((item) => String(item.nome || "")));

    if (state.filtros.funcionarioNome && !available.has(state.filtros.funcionarioNome)) {
      state.filtros.funcionarioNome = null;
    }

    fillSelect(dom.filtroFuncionarioGlobal, options, {
      includeAll: true,
      allLabel: "Todos",
      valueKey: "nome",
      labelKey: "nome",
    });

    dom.filtroFuncionarioGlobal.value = state.filtros.funcionarioNome || "all";
    const after = state.filtros.funcionarioNome || "all";
    return before !== after;
  }

  function populateMonthsSelect(months) {
    const before = state.filtros.meses.slice().sort().join(",");
    const options = months.length > 0 ? months : [{ mes_ref: currentMonthRef(), label: monthLabel(currentMonthRef()) }];
    const availableRefs = new Set(options.map((item) => String(item.mes_ref)));

    state.filtros.meses = state.filtros.meses.filter((ref) => availableRefs.has(ref));
    if (state.filtros.meses.length === 0) {
      const currentRef = currentMonthRef();
      if (availableRefs.has(currentRef)) {
        state.filtros.meses = [currentRef];
      } else {
        state.filtros.meses = [options[0].mes_ref];
      }
    }

    dom.periodoMesesOptions.innerHTML = options
      .map((item) => {
        const mesRef = String(item.mes_ref);
        const checked = state.filtros.meses.includes(mesRef) ? "checked" : "";
        const label = escapeHtml(item.label || monthLabel(mesRef));
        return `
          <label class="multi-option">
            <input type="checkbox" value="${mesRef}" ${checked} />
            <span>${label}</span>
          </label>
        `;
      })
      .join("");

    const after = state.filtros.meses.slice().sort().join(",");
    setPeriodoUiState();
    return before !== after;
  }

  function renderDashboard() {
    if (!state.dashboard) {
      return;
    }

    const kpis = state.dashboard.kpis || {};
    dom.kpiTotalVisitas.textContent = formatInt(kpis.total_visitas);
    dom.kpiTotalInteracoes.textContent = formatInt(kpis.total_interacoes);
    dom.kpiTotalRegistros.textContent = formatInt(kpis.total_registros);
    dom.kpiDemandasAbertas.textContent = formatInt(kpis.demandas_abertas);
    dom.kpiTotalCompromissos.textContent = formatInt(kpis.total_compromissos_periodo);
    updateSidebarSelectedUser();

    renderDashboardCharts();
    renderCompromissosHoje();
    scheduleDashboardChartSync(120);
  }

  function renderDashboardCharts() {
    if (!state.dashboard || state.view !== "dashboard") {
      return;
    }

    renderEvolucaoChart();
    renderVolumeChart();
    renderRoscaChart();
    renderStatusChart();
  }

  function scheduleDashboardChartSync(delay = 80) {
    if (dashboardSyncTimer) {
      clearTimeout(dashboardSyncTimer);
    }

    dashboardSyncTimer = setTimeout(() => {
      dashboardSyncTimer = null;
      if (!state.dashboard || state.view !== "dashboard") {
        return;
      }

      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          renderDashboardCharts();
        });
      });
    }, delay);
  }

  function renderEvolucaoChart() {
    const data = state.dashboard || {};
    const visitasMap = toMonthCountMap(data.visitas_timeline || []);
    const interacoesMap = toMonthCountMap(data.interacoes_timeline || []);
    const monthRefs = Array.from(new Set([...Object.keys(visitasMap), ...Object.keys(interacoesMap)])).sort();

    const series = [];
    const chartColors = getChartCssColors();

    if (state.filtros.tipoTratativa !== "interacoes") {
      series.push({
        name: "Visitas",
        data: monthRefs.map((mes) => visitasMap[mes] || 0),
      });
    }

    if (state.filtros.tipoTratativa !== "visitas") {
      series.push({
        name: "InteraÃ§Ãµes",
        data: monthRefs.map((mes) => interacoesMap[mes] || 0),
      });
    }

    const maxValue = Math.max(1, ...series.flatMap((item) => item.data));
    const scale = buildIntegerScale(maxValue);
    const colors = series.map((item) => (item.name === "Visitas" ? chartColors.visitas : chartColors.interacoes));

    mountChart("evolucao", "chart-evolucao", {
      chart: {
        type: "line",
        toolbar: { show: false },
        fontFamily: "Sora, sans-serif",
        height: "100%",
        parentHeightOffset: 0,
        animations: { enabled: true, speed: 480, easing: "easeinout" },
      },
      noData: { text: "Sem dados no perÃ­odo." },
      series,
      colors,
      stroke: { curve: "smooth", width: 2.6 },
      markers: { size: 4, hover: { size: 6 } },
      dataLabels: {
        enabled: true,
        offsetY: -8,
        formatter: (value) => String(Math.round(value)),
        style: {
          fontSize: "11px",
          fontWeight: 700,
          colors,
        },
        background: {
          enabled: false,
        },
      },
      grid: {
        borderColor: chartColors.grid,
        strokeDashArray: 4,
        padding: { top: 2, right: 10, bottom: 18, left: 10 },
      },
      xaxis: {
        categories: monthRefs.map((mes) => monthLabel(mes)),
        labels: { style: { colors: chartColors.label }, offsetY: 2, offsetX: 2, trim: false },
        axisBorder: { show: false },
        axisTicks: { show: false },
      },
      yaxis: {
        min: scale.min,
        max: scale.max,
        tickAmount: scale.tickAmount,
        labels: { show: false },
      },
      legend: {
        show: series.length > 1,
        position: "top",
        horizontalAlign: "left",
        labels: { colors: chartColors.label },
      },
      tooltip: {
        shared: true,
        intersect: false,
        y: { formatter: (value) => formatInt(value) },
      },
    });
  }

  function renderVolumeChart() {
    const data = state.dashboard || {};
    const chartColors = getChartCssColors();
    const isByAgencia = state.volumeAgrupamento === "agencia";
    const rows = isByAgencia ? data.top_agencias || [] : data.top_funcionarios || [];
    const chartRows = rows;

    const labels = chartRows.map((row) => (isByAgencia ? row.agencia_nome : row.funcionario_nome));
    const visitas = chartRows.map((row) => toInt(row.total_visitas));
    const interacoes = chartRows.map((row) => toInt(row.total_interacoes));

    let series = [];
    let colors = [];

    if (state.filtros.tipoTratativa === "visitas") {
      series = [{ name: "Visitas", data: visitas }];
      colors = [chartColors.visitas];
    } else if (state.filtros.tipoTratativa === "interacoes") {
      series = [{ name: "InteraÃ§Ãµes", data: interacoes }];
      colors = [chartColors.interacoes];
    } else {
      series = [
        { name: "Visitas", data: visitas },
        { name: "InteraÃ§Ãµes", data: interacoes },
      ];
      colors = [chartColors.visitas, chartColors.interacoes];
    }

    const isStacked = series.length > 1;
    const maxValue = isStacked
      ? Math.max(
          1,
          ...labels.map((_, index) => series.reduce((acc, item) => acc + toInt(item.data[index]), 0))
        )
      : Math.max(1, ...series.flatMap((item) => item.data));
    const scale = buildIntegerScale(maxValue + (isStacked ? 1 : 0));
    const scrollContainer = document.getElementById("chart-top-volume-scroll");
    const viewportHeight = Math.max(260, scrollContainer?.clientHeight || 340);
    const rowHeight = labels.length > 14 ? 38 : labels.length > 9 ? 48 : 60;
    const height = Math.max(viewportHeight, labels.length * rowHeight + 24);

    dom.chartVolumeTitle.textContent = "Quantidade de (Tratativas / Visitas / Interações)";
    updateVolumeToggleButtons();

    const barHeight = labels.length > 12 ? "52%" : labels.length > 8 ? "58%" : "68%";

    mountChart("volume", "chart-top-volume", {
      chart: {
        type: "bar",
        stacked: isStacked,
        toolbar: { show: false },
        fontFamily: "Sora, sans-serif",
        animations: { enabled: true, speed: 520, easing: "easeinout" },
        height,
      },
      noData: { text: "Sem dados para o filtro selecionado." },
      series,
      colors,
      plotOptions: {
        bar: {
          horizontal: true,
          borderRadius: 7,
          borderRadiusApplication: "end",
          borderRadiusWhenStacked: "last",
          barHeight,
          dataLabels: { position: "center" },
        },
      },
      dataLabels: {
        enabled: true,
        formatter: (value) => (value > 0 ? String(Math.round(value)) : ""),
        style: {
          fontSize: "11px",
          fontWeight: 700,
          colors: ["#ffffff"],
        },
      },
      grid: { borderColor: chartColors.grid, strokeDashArray: 4 },
      xaxis: {
        categories: labels,
        min: scale.min,
        max: scale.max,
        tickAmount: scale.tickAmount,
        labels: { show: false },
        axisBorder: { show: false },
        axisTicks: { show: false },
      },
      yaxis: {
        labels: {
          style: { colors: [chartColors.label] },
          maxWidth: 360,
        },
      },
      legend: {
        show: series.length > 1,
        position: "bottom",
        labels: { colors: chartColors.label },
      },
      tooltip: {
        x: { show: false },
        y: { formatter: (value) => formatInt(value) },
      },
    });
  }

  function renderRoscaChart() {
    const rows = (state.dashboard?.interacoes_por_tipo || []).filter((row) => toInt(row.quantidade) > 0);
    const labels = rows.map((row) => String(row.tipo));
    const series = rows.map((row) => toInt(row.quantidade));
    const chartColors = getChartCssColors();

    mountChart("rosca", "chart-interacoes-tipo", {
      chart: {
        type: "donut",
        fontFamily: "Sora, sans-serif",
        toolbar: { show: false },
        height: "100%",
        animations: { enabled: true, speed: 480, easing: "easeinout" },
      },
      noData: { text: "Sem interaÃ§Ãµes para o perÃ­odo." },
      labels,
      series,
      colors: buildBluePalette(labels.length, chartColors.interacoes),
      legend: {
        position: "bottom",
        labels: { colors: chartColors.label },
      },
      dataLabels: {
        enabled: true,
        formatter: (value) => `${Math.round(value)}%`,
      },
      plotOptions: {
        pie: {
          customScale: 0.96,
          donut: {
            size: "72%",
            labels: {
              show: true,
              name: { show: true, color: chartColors.label },
              value: {
                show: true,
                color: chartColors.label,
                formatter: (value) => String(Math.round(toInt(value))),
              },
              total: {
                show: true,
                label: "Total",
                color: chartColors.label,
                formatter: () => String(series.reduce((acc, value) => acc + value, 0)),
              },
            },
          },
        },
      },
      tooltip: { y: { formatter: (value) => formatInt(value) } },
    });
  }

  function renderStatusChart() {
    const rows = state.dashboard?.demandas_por_status || [];
    const labels = rows.map((row) => String(row.status));
    const values = rows.map((row) => toInt(row.quantidade));
    const chartColors = getChartCssColors();
    const maxValue = Math.max(1, ...values);
    const scale = buildIntegerScale(maxValue);
    const scrollContainer = document.getElementById("chart-demandas-status-scroll");
    const viewportHeight = Math.max(210, scrollContainer?.clientHeight || 240);
    const height = Math.max(viewportHeight, labels.length * 54 + 20);

    let color = chartColors.interacoes;
    if (state.filtros.tipoTratativa === "visitas") {
      color = chartColors.visitas;
    }
    if (state.filtros.tipoTratativa === "all") {
      color = chartColors.accent;
    }

    mountChart("status", "chart-demandas-status", {
      chart: {
        type: "bar",
        fontFamily: "Sora, sans-serif",
        toolbar: { show: false },
        height,
        animations: { enabled: true, speed: 420, easing: "easeinout" },
      },
      noData: { text: "Sem demandas no perÃ­odo." },
      series: [{ name: "Demandas", data: values }],
      colors: [color],
      plotOptions: {
        bar: {
          horizontal: true,
          borderRadius: 6,
          barHeight: "64%",
          dataLabels: { position: "center" },
        },
      },
      dataLabels: {
        enabled: true,
        formatter: (value) => (value > 0 ? String(Math.round(value)) : ""),
        style: {
          fontSize: "11px",
          fontWeight: 700,
          colors: ["#ffffff"],
        },
      },
      grid: { borderColor: chartColors.grid, strokeDashArray: 4 },
      xaxis: {
        categories: labels,
        min: scale.min,
        max: scale.max,
        tickAmount: scale.tickAmount,
        labels: { show: false },
        axisBorder: { show: false },
        axisTicks: { show: false },
      },
      yaxis: {
        labels: { style: { colors: [chartColors.label] } },
      },
      legend: { show: false },
      tooltip: { y: { formatter: (value) => formatInt(value) } },
    });
  }

  function renderCompromissosHoje() {
    const rows = state.dashboard?.compromissos_hoje || [];
    if (rows.length === 0) {
      dom.listaCompromissosHoje.innerHTML = '<div class="empty-state">Nenhum compromisso futuro.</div>';
      return;
    }

    dom.listaCompromissosHoje.innerHTML = rows
      .map((item) => {
        const inicio = formatHour(item.data_inicio);
        const fim = formatHour(item.data_fim);
        const cor = escapeHtml(item.cor || "#cc092f");
        return `
          <article class="compact-item" style="border-left: 4px solid ${cor}">
            <div>
              <strong>${escapeHtml(item.titulo || "-")}</strong>
              <div>${escapeHtml(item.usuario_nome || "-")} - ${escapeHtml(item.tipo_compromisso || "-")}</div>
            </div>
            <div>${inicio} - ${fim}</div>
          </article>
        `;
      })
      .join("");
  }

  async function loadVisitasList() {
    const params = buildFactQuery();
    params.set("limit", "20");
    const response = await apiGet(`visitas.php?${params.toString()}`);
    renderVisitasList(response.visitas || []);
  }

  async function loadInteracoesList() {
    const params = buildFactQuery();
    params.set("limit", "20");
    const response = await apiGet(`interacoes.php?${params.toString()}`);
    renderInteracoesList(response.interacoes || []);
  }

  async function loadCompromissosList() {
    const params = buildFactQuery();
    params.set("limit", "20");
    const response = await apiGet(`compromissos.php?${params.toString()}`);
    renderCompromissosList(response.compromissos || []);
  }

  function renderVisitasList(rows) {
    if (!rows.length) {
      dom.listaVisitas.innerHTML = '<div class="empty-state">Nenhuma visita no filtro atual.</div>';
      return;
    }

    dom.listaVisitas.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th>Data</th>
            <th>UsuÃ¡rio</th>
            <th>AgÃªncia</th>
            <th>Tema</th>
            <th>Status</th>
            <th>Participantes</th>
          </tr>
        </thead>
        <tbody>
          ${rows
            .map(
              (item) => `
            <tr>
              <td>${formatDateTime(item.data_contato || item.criado_em)}</td>
              <td>${escapeHtml(item.usuario_nome || "-")}</td>
              <td>${escapeHtml(item.agencia_nome || "-")}</td>
              <td>${escapeHtml(item.tema_visita || "-")}</td>
              <td><span class="pill">${escapeHtml(item.status_demanda || "Sem status")}</span></td>
              <td>${formatInt(item.total_participantes)}</td>
            </tr>
          `
            )
            .join("")}
        </tbody>
      </table>
    `;
  }

  function renderInteracoesList(rows) {
    if (!rows.length) {
      dom.listaInteracoes.innerHTML = '<div class="empty-state">Nenhuma interaÃ§Ã£o no filtro atual.</div>';
      return;
    }

    dom.listaInteracoes.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th>Data</th>
            <th>UsuÃ¡rio</th>
            <th>Tipo</th>
            <th>Contato</th>
            <th>Assunto</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          ${rows
            .map(
              (item) => `
            <tr>
              <td>${formatDateTime(item.data_contato || item.criado_em)}</td>
              <td>${escapeHtml(item.usuario_nome || "-")}</td>
              <td>${escapeHtml(item.tipo_interacao || "-")}</td>
              <td>${escapeHtml(item.nome_contato || "-")}</td>
              <td>${escapeHtml(item.assunto || "-")}</td>
              <td><span class="pill">${escapeHtml(item.status_demanda || "Sem status")}</span></td>
            </tr>
          `
            )
            .join("")}
        </tbody>
      </table>
    `;
  }

  function renderCompromissosList(rows) {
    if (!rows.length) {
      dom.listaCompromissos.innerHTML = '<div class="empty-state">Nenhum compromisso no filtro atual.</div>';
      return;
    }

    dom.listaCompromissos.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th>InÃ­cio</th>
            <th>Fim</th>
            <th>UsuÃ¡rio</th>
            <th>TÃ­tulo</th>
            <th>Tipo</th>
          </tr>
        </thead>
        <tbody>
          ${rows
            .map(
              (item) => `
            <tr>
              <td>${formatDateTime(item.data_inicio)}</td>
              <td>${formatDateTime(item.data_fim)}</td>
              <td>${escapeHtml(item.usuario_nome || "-")}</td>
              <td>${escapeHtml(item.titulo || "-")}</td>
              <td><span class="pill">${escapeHtml(item.tipo_compromisso || "-")}</span></td>
            </tr>
          `
            )
            .join("")}
        </tbody>
      </table>
    `;
  }

  async function onSubmitVisita(event) {
    event.preventDefault();
    const form = event.currentTarget;

    const payload = {
      usuario_id: toInt(form.usuario_id.value),
      agencia_id: toInt(form.agencia_id.value),
      tema_visita_id: toInt(form.tema_visita_id.value),
      descricao: nonEmptyString(form.descricao.value),
      demandas: nullableString(form.demandas.value),
      area_responsavel_id: nullableInt(form.area_responsavel_id.value),
      status_demanda_id: nullableInt(form.status_demanda_id.value),
      tags: nullableString(form.tags.value),
      data_contato: normalizeDateTimeInput(form.data_contato.value),
      participantes: parsePeopleInput(form.participantes.value),
    };

    await apiPost("visitas.php", payload);
    form.reset();
    applyGlobalUserToForms();
    await refreshAllData("Visita salva e dashboard atualizado.");
  }

  async function onSubmitInteracao(event) {
    event.preventDefault();
    const form = event.currentTarget;

    const payload = {
      usuario_id: toInt(form.usuario_id.value),
      tipo_interacao_id: toInt(form.tipo_interacao_id.value),
      agencia_id: nullableInt(form.agencia_id.value),
      diretoria: nullableString(form.diretoria.value),
      regional: nullableString(form.regional.value),
      nome_contato: nullableString(form.nome_contato.value),
      subsecao_contato: nullableString(form.subsecao_contato.value),
      assunto: nonEmptyString(form.assunto.value),
      descricao: nonEmptyString(form.descricao.value),
      demandas: nullableString(form.demandas.value),
      area_responsavel_id: nullableInt(form.area_responsavel_id.value),
      status_demanda_id: nullableInt(form.status_demanda_id.value),
      tags: nullableString(form.tags.value),
      data_contato: normalizeDateTimeInput(form.data_contato.value),
      contatos: parsePeopleInput(form.contatos.value),
    };

    await apiPost("interacoes.php", payload);
    form.reset();
    applyGlobalUserToForms();
    await refreshAllData("InteraÃ§Ã£o salva e dashboard atualizado.");
  }

  async function onSubmitCompromisso(event) {
    event.preventDefault();
    const form = event.currentTarget;

    const payload = {
      usuario_id: toInt(form.usuario_id.value),
      tipo_compromisso_id: toInt(form.tipo_compromisso_id.value),
      titulo: nonEmptyString(form.titulo.value),
      descricao: nullableString(form.descricao.value),
      data_inicio: normalizeDateTimeInput(form.data_inicio.value),
      data_fim: normalizeDateTimeInput(form.data_fim.value),
      cor: nullableString(form.cor.value),
    };

    await apiPost("compromissos.php", payload);
    form.reset();
    applyGlobalUserToForms();
    await refreshAllData("Compromisso salvo e dashboard atualizado.");
  }

  function openQuickAddModal() {
    dom.formQuickAdd.reset();
    dom.quickAddTipo.value = "interacao";
    updateQuickAddTypeUi();
    applyGlobalUserToForms();
    dom.quickAddModal.classList.remove("is-hidden");
    dom.quickAddModal.setAttribute("aria-hidden", "false");
  }

  function closeQuickAddModal() {
    dom.quickAddModal.classList.add("is-hidden");
    dom.quickAddModal.setAttribute("aria-hidden", "true");
  }

  function updateQuickAddTypeUi() {
    const tipo = dom.quickAddTipo.value;
    toggleQuickSection(dom.quickFieldsInteracao, tipo === "interacao");
    toggleQuickSection(dom.quickFieldsVisita, tipo === "visita");
    toggleQuickSection(dom.quickFieldsCompromisso, tipo === "compromisso");
  }

  function toggleQuickSection(section, active) {
    section.classList.toggle("is-hidden", !active);
    Array.from(section.querySelectorAll("input, select, textarea")).forEach((field) => {
      field.disabled = !active;
    });
  }

  async function onSubmitQuickAdd(event) {
    event.preventDefault();
    const tipo = dom.quickAddTipo.value;

    if (tipo === "interacao") {
      const payload = {
        usuario_id: toInt(document.getElementById("quick-interacao-usuario").value),
        tipo_interacao_id: toInt(document.getElementById("quick-interacao-tipo").value),
        agencia_id: nullableInt(document.getElementById("quick-interacao-agencia").value),
        status_demanda_id: nullableInt(document.getElementById("quick-interacao-status").value),
        assunto: nonEmptyString(document.getElementById("quick-interacao-assunto").value),
        descricao: nonEmptyString(document.getElementById("quick-interacao-descricao").value),
        nome_contato: nullableString(document.getElementById("quick-interacao-contato").value),
        data_contato: normalizeDateTimeInput(document.getElementById("quick-interacao-data").value),
      };
      await apiPost("interacoes.php", payload);
    }

    if (tipo === "visita") {
      const payload = {
        usuario_id: toInt(document.getElementById("quick-visita-usuario").value),
        agencia_id: toInt(document.getElementById("quick-visita-agencia").value),
        tema_visita_id: toInt(document.getElementById("quick-visita-tema").value),
        status_demanda_id: nullableInt(document.getElementById("quick-visita-status").value),
        descricao: nonEmptyString(document.getElementById("quick-visita-descricao").value),
        participantes: parsePeopleInput(document.getElementById("quick-visita-participantes").value),
        data_contato: normalizeDateTimeInput(document.getElementById("quick-visita-data").value),
        tags: nullableString(document.getElementById("quick-visita-tags").value),
      };
      await apiPost("visitas.php", payload);
    }

    if (tipo === "compromisso") {
      const payload = {
        usuario_id: toInt(document.getElementById("quick-compromisso-usuario").value),
        tipo_compromisso_id: toInt(document.getElementById("quick-compromisso-tipo").value),
        titulo: nonEmptyString(document.getElementById("quick-compromisso-titulo").value),
        data_inicio: normalizeDateTimeInput(document.getElementById("quick-compromisso-inicio").value),
        data_fim: normalizeDateTimeInput(document.getElementById("quick-compromisso-fim").value),
        descricao: nullableString(document.getElementById("quick-compromisso-descricao").value),
      };
      await apiPost("compromissos.php", payload);
    }

    closeQuickAddModal();
    await refreshAllData("Registro salvo e dashboard atualizado.");
  }

  function buildDashboardQuery() {
    const params = new URLSearchParams();
    params.set("periodo_modo", state.filtros.periodoModo);
    params.set("tipo_tratativa", state.filtros.tipoTratativa);
    if (state.filtros.usuarioId) {
      params.set("usuario_id", String(state.filtros.usuarioId));
    }
    if (state.filtros.agenciaId) {
      params.set("agencia_id", String(state.filtros.agenciaId));
    }
    if (state.filtros.funcionarioNome) {
      params.set("funcionario_nome", state.filtros.funcionarioNome);
    }
    if (state.filtros.periodoModo === "meses" && state.filtros.meses.length > 0) {
      params.set("meses", state.filtros.meses.join(","));
    }
    return params;
  }

  function buildFactQuery() {
    const params = new URLSearchParams();
    if (state.filtros.usuarioId) {
      params.set("usuario_id", String(state.filtros.usuarioId));
    }
    if (state.filtros.agenciaId) {
      params.set("agencia_id", String(state.filtros.agenciaId));
    }
    if (state.filtros.periodoModo === "meses" && state.filtros.meses.length > 0) {
      params.set("meses", state.filtros.meses.join(","));
    }
    return params;
  }

  function readFiltersFromInputs() {
    state.filtros.periodoModo = dom.periodoAcumulado.checked ? "acumulado" : "meses";
    state.filtros.tipoTratativa = dom.filtroTratativaGlobal.value || "all";

    const userValue = dom.filtroUsuarioGlobal.value;
    state.filtros.usuarioId = userValue && userValue !== "all" ? toInt(userValue) : null;
    const agenciaValue = dom.filtroAgenciaGlobal.value;
    state.filtros.agenciaId = agenciaValue && agenciaValue !== "all" ? toInt(agenciaValue) : null;
    const funcionarioValue = dom.filtroFuncionarioGlobal.value;
    state.filtros.funcionarioNome = funcionarioValue && funcionarioValue !== "all" ? funcionarioValue : null;

    state.filtros.meses = getCheckedMonthsFromDropdown();
    if (state.filtros.periodoModo === "meses" && state.filtros.meses.length === 0) {
      const firstRef = dom.periodoMesesOptions.querySelector('input[type="checkbox"]')?.value;
      if (firstRef) {
        state.filtros.meses = [firstRef];
        const firstInput = dom.periodoMesesOptions.querySelector(`input[value="${firstRef}"]`);
        if (firstInput instanceof HTMLInputElement) {
          firstInput.checked = true;
        }
      } else {
        state.filtros.periodoModo = "acumulado";
        dom.periodoAcumulado.checked = true;
      }
    }
    setPeriodoUiState();
    applyGlobalUserToForms();
    updateSidebarSelectedUser();
  }

  function syncFilterInputs() {
    dom.periodoAcumulado.checked = state.filtros.periodoModo === "acumulado";
    Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]')).forEach((input) => {
      input.checked = state.filtros.meses.includes(input.value);
    });
    dom.filtroTratativaGlobal.value = state.filtros.tipoTratativa;
    dom.filtroUsuarioGlobal.value = state.filtros.usuarioId ? String(state.filtros.usuarioId) : "all";
    dom.filtroAgenciaGlobal.value = state.filtros.agenciaId ? String(state.filtros.agenciaId) : "all";
    dom.filtroFuncionarioGlobal.value = state.filtros.funcionarioNome || "all";
    setPeriodoUiState();
    updateSidebarSelectedUser();
  }

  function setPeriodoUiState() {
    const acumulado = state.filtros.periodoModo === "acumulado";
    dom.periodoAcumulado.checked = acumulado;

    const inputs = Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]'));
    inputs.forEach((input) => {
      input.disabled = acumulado;
    });

    dom.periodoMesesOptions.classList.toggle("is-disabled", acumulado);
    updatePeriodoDropdownLabel();
  }

  function updatePeriodoDropdownLabel() {
    if (state.filtros.periodoModo === "acumulado") {
      dom.btnPeriodoDropdown.textContent = "Acumulado";
      return;
    }

    const labels = state.filtros.meses.map((mes) => monthLabel(mes));
    if (labels.length === 0) {
      dom.btnPeriodoDropdown.textContent = "Selecione mÃªs(es)";
      return;
    }

    dom.btnPeriodoDropdown.textContent =
      labels.length > 2 ? `${labels.slice(0, 2).join(", ")} +${labels.length - 2}` : labels.join(", ");
  }

  function togglePeriodoDropdown(open) {
    const show = open === true;
    dom.periodoDropdownPanel.classList.toggle("is-hidden", !show);
    dom.btnPeriodoDropdown.setAttribute("aria-expanded", show ? "true" : "false");
  }

  function getCheckedMonthsFromDropdown() {
    return Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]:checked'))
      .map((input) => input.value)
      .filter(Boolean);
  }

  function updateVolumeToggleButtons() {
    const buttons = Array.from(dom.toggleVolumeGroup.querySelectorAll(".toggle-btn"));
    buttons.forEach((btn) => {
      btn.classList.toggle("is-active", btn.dataset.agrupamento === state.volumeAgrupamento);
    });
  }

  function applyGlobalUserToForms() {
    if (!state.filtros.usuarioId) {
      return;
    }
    const value = String(state.filtros.usuarioId);
    [
      "visita-usuario",
      "interacao-usuario",
      "compromisso-usuario",
      "quick-interacao-usuario",
      "quick-visita-usuario",
      "quick-compromisso-usuario",
    ].forEach((id) => {
      const select = document.getElementById(id);
      if (select && Array.from(select.options).some((option) => option.value === value)) {
        select.value = value;
      }
    });
  }

  function clearAllFilters() {
    const currentRef = currentMonthRef();
    const availableRefs = Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]')).map((input) => input.value);
    const firstRef = availableRefs.includes(currentRef) ? currentRef : availableRefs[0] || currentRef;

    state.filtros.periodoModo = "meses";
    state.filtros.meses = [firstRef];
    state.filtros.usuarioId = null;
    state.filtros.tipoTratativa = "all";
    state.filtros.agenciaId = null;
    state.filtros.funcionarioNome = null;

    syncFilterInputs();
    applyGlobalUserToForms();
  }

  function updateSidebarSelectedUser(tempUserId = state.filtros.usuarioId) {
    if (!dom.sidebarSelectedUser) {
      return;
    }

    if (!tempUserId) {
      dom.sidebarSelectedUser.textContent = "TODOS";
      return;
    }

    const found = state.dimensoes.usuarios.find((item) => toInt(item.id) === toInt(tempUserId));
    dom.sidebarSelectedUser.textContent = (found?.nome || "TODOS").toUpperCase();
  }

  function applyTheme(theme) {
    const finalTheme = theme === "dark" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", finalTheme);
    if (dom.themeSwitchInput) {
      dom.themeSwitchInput.checked = finalTheme === "dark";
    }
    localStorage.setItem("alidemar-theme", finalTheme);
  }

  async function loadAccessContext() {
    if (dom.windowsUserEmail) {
      dom.windowsUserEmail.textContent = "Windows: validando acesso...";
    }

    const payload = await apiGet("acesso.php");

    state.acesso = {
      autorizado: payload.autorizado === true,
      carregado: true,
      funcionalLogin: nullableString(payload.funcional_login),
      identidade: payload.identidade || null,
      registro: payload.registro || null,
    };

    updateWindowsIdentityLabel(payload.identidade || null);
    return payload;
  }

  async function loadWindowsIdentityOnly() {
    if (dom.windowsUserEmail) {
      dom.windowsUserEmail.textContent = "Windows: carregando...";
    }

    try {
      const payload = await apiGet("sistema_usuario.php");
      updateWindowsIdentityLabel(payload);
    } catch (error) {
      if (dom.windowsUserEmail) {
        dom.windowsUserEmail.textContent = "Windows: indisponivel";
      }
    }
  }

  function updateWindowsIdentityLabel(identity) {
    if (!dom.windowsUserEmail) {
      return;
    }

    const email = nullableString(identity?.email);
    const usuario = nullableString(identity?.usuario);
    const funcional = nullableString(identity?.funcional);

    if (email && funcional) {
      dom.windowsUserEmail.textContent = `Windows: ${email} (${funcional})`;
      return;
    }

    if (email) {
      dom.windowsUserEmail.textContent = `Windows: ${email}`;
      return;
    }

    if (funcional) {
      dom.windowsUserEmail.textContent = `Windows: ${funcional}`;
      return;
    }

    if (usuario) {
      dom.windowsUserEmail.textContent = `Windows: ${usuario}`;
      return;
    }

    dom.windowsUserEmail.textContent = "Windows: nao identificado";
  }

  function lockApplication(accessPayload) {
    if (!dom.accessOverlay) {
      return;
    }

    const funcional = nullableString(accessPayload?.funcional_login);
    const mensagemApi = nullableString(accessPayload?.mensagem);
    const titulo = "Acesso nao autorizado";
    let mensagem = "Seu usuario nao possui acesso a esta aplicacao.";

    if (funcional) {
      mensagem = `Seu login Windows (${funcional}) nao possui acesso a esta aplicacao.`;
    } else if (mensagemApi) {
      mensagem = mensagemApi;
    }

    if (mensagemApi && mensagemApi !== mensagem) {
      mensagem = `${mensagem} ${mensagemApi}`;
    }

    dom.accessOverlayTitle.textContent = titulo;
    dom.accessOverlayMessage.textContent = mensagem;
    dom.accessOverlay.classList.remove("is-hidden");
    dom.accessOverlay.setAttribute("aria-hidden", "false");
    document.body.classList.add("is-access-locked");
  }

  function unlockApplication() {
    if (!dom.accessOverlay) {
      return;
    }

    dom.accessOverlay.classList.add("is-hidden");
    dom.accessOverlay.setAttribute("aria-hidden", "true");
    document.body.classList.remove("is-access-locked");
  }

  function loadTheme() {
    return localStorage.getItem("alidemar-theme") || "light";
  }

  function mountChart(key, elementId, options) {
    if (!window.ApexCharts) {
      return;
    }

    const element = document.getElementById(elementId);
    if (!element) {
      return;
    }

    if (state.charts[key]) {
      state.charts[key].destroy();
    }

    const chart = new ApexCharts(element, options);
    state.charts[key] = chart;
    chart.render();
  }

  function getChartCssColors() {
    const styles = getComputedStyle(document.documentElement);
    return {
      visitas: styles.getPropertyValue("--chart-visitas").trim(),
      interacoes: styles.getPropertyValue("--chart-interacoes").trim(),
      accent: styles.getPropertyValue("--accent").trim(),
      grid: styles.getPropertyValue("--chart-grid").trim(),
      label: styles.getPropertyValue("--chart-label").trim(),
    };
  }

  function buildBluePalette(length, baseColor) {
    const fallback = ["#1b2563", "#29408f", "#3d59ad", "#5574c5", "#7291da", "#94afea", "#bed0f7"];
    if (length <= fallback.length) {
      return fallback.slice(0, Math.max(1, length));
    }
    const out = [];
    for (let index = 0; index < length; index += 1) {
      if (index < fallback.length) {
        out.push(fallback[index]);
      } else {
        out.push(baseColor || "#1b2563");
      }
    }
    return out;
  }

  function buildIntegerScale(maxValue) {
    const max = Math.max(1, Math.ceil(maxValue));
    if (max <= 12) {
      return { min: 0, max, tickAmount: max };
    }
    const rounded = Math.ceil(max / 5) * 5;
    return { min: 0, max: rounded, tickAmount: 5 };
  }

  function fitRowsForVolume(rows, isByAgencia, maxBars) {
    if (rows.length <= maxBars) {
      return rows;
    }

    const keepCount = Math.max(1, maxBars - 1);
    const visible = rows.slice(0, keepCount);
    const hidden = rows.slice(keepCount);

    const agregado = hidden.reduce(
      (acc, item) => {
        acc.total_visitas += toInt(item.total_visitas);
        acc.total_interacoes += toInt(item.total_interacoes);
        return acc;
      },
      { total_visitas: 0, total_interacoes: 0 }
    );

    const othersLabel = isByAgencia ? "Outras agÃªncias" : "Outros funcionÃ¡rios";
    const others = isByAgencia
      ? { agencia_nome: othersLabel, ...agregado }
      : { funcionario_nome: othersLabel, ...agregado };

    return [...visible, others];
  }

  function toMonthCountMap(rows) {
    return rows.reduce((acc, row) => {
      const mesRef = monthRefFromDate(row.data);
      if (!mesRef) {
        return acc;
      }
      acc[mesRef] = (acc[mesRef] || 0) + toInt(row.quantidade);
      return acc;
    }, {});
  }

  function monthRefFromDate(value) {
    if (!value) {
      return null;
    }

    const text = String(value);
    if (/^\d{4}-(0[1-9]|1[0-2])/.test(text)) {
      return text.slice(0, 7);
    }

    const date = new Date(text.replace(" ", "T"));
    if (Number.isNaN(date.getTime())) {
      return null;
    }

    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
  }

  function parsePeopleInput(rawText) {
    if (!rawText || !rawText.trim()) {
      return [];
    }

    return rawText
      .split(";")
      .map((part) => part.trim())
      .filter(Boolean)
      .map((part) => {
        const pieces = part.split("|");
        const nome = (pieces[0] || "").trim();
        const subsecao = (pieces[1] || "").trim();
        if (!nome) {
          return null;
        }
        return {
          nome,
          subsecao: subsecao || null,
        };
      })
      .filter(Boolean);
  }

  function currentMonthRef() {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  }

  function monthLabel(mesRef) {
    const [year, month] = String(mesRef).split("-");
    const monthIndex = Number(month) - 1;
    const monthName = MONTHS_PT[monthIndex] || month;
    return `${monthName} - ${year}`;
  }

  function normalizeDateTimeInput(value) {
    if (!value) {
      return null;
    }
    const normalized = value.replace("T", " ");
    return normalized.length === 16 ? `${normalized}:00` : normalized;
  }

  function formatDateTime(value) {
    if (!value) {
      return "-";
    }
    const date = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(date.getTime())) {
      return value;
    }
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    const hour = String(date.getHours()).padStart(2, "0");
    const minute = String(date.getMinutes()).padStart(2, "0");
    return `${day}/${month}/${year} ${hour}:${minute}`;
  }

  function formatHour(value) {
    if (!value) {
      return "--:--";
    }
    const date = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(date.getTime())) {
      return "--:--";
    }
    const hour = String(date.getHours()).padStart(2, "0");
    const minute = String(date.getMinutes()).padStart(2, "0");
    return `${hour}:${minute}`;
  }

  function formatInt(value) {
    return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 }).format(toInt(value));
  }

  function showFeedback(message, type = "success") {
    if (!dom.feedback) {
      return;
    }

    dom.feedback.textContent = message;
    dom.feedback.classList.add("is-visible");
    dom.feedback.classList.remove("success", "error");
    dom.feedback.classList.add(type === "error" ? "error" : "success");

    if (feedbackTimer) {
      clearTimeout(feedbackTimer);
    }
    feedbackTimer = setTimeout(() => {
      dom.feedback.classList.remove("is-visible");
    }, 3500);
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function toInt(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) {
      return 0;
    }
    return Math.trunc(number);
  }

  function nullableInt(value) {
    if (value === null || value === undefined || String(value).trim() === "") {
      return null;
    }
    return toInt(value);
  }

  function nullableString(value) {
    if (value === null || value === undefined) {
      return null;
    }
    const text = String(value).trim();
    return text === "" ? null : text;
  }

  function nonEmptyString(value) {
    const text = nullableString(value);
    if (!text) {
      throw new Error("Preencha os campos obrigatÃ³rios antes de salvar.");
    }
    return text;
  }

  async function apiGet(path) {
    return apiRequest(path, { method: "GET" });
  }

  async function apiPost(path, payload) {
    return apiRequest(path, {
      method: "POST",
      body: JSON.stringify(payload),
      headers: { "Content-Type": "application/json" },
    });
  }

  async function apiRequest(path, options) {
    const response = await fetch(`${API_ROOT}/${path}`, options);
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.erro || `Erro ${response.status}`);
    }
    return data;
  }
})();

