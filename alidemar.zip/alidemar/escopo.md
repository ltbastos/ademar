# Contexto do Projeto

## Resumo
- Projeto atual: **Pre-Aprovado PJ** (PHP + JS + CSS).
- Banco de dados: MySQL/MariaDB (dump em `dump-preaprovados-202511162054.sql`).
- Arquitetura: frontend em `index.php` + APIs PHP no mesmo diretório.

## Endpoints/Fluxo Atual
- `filtros.php`: retorna estados, cidades e bairros (`tipo=estados|cidades|bairros`).
- `buscar_empresas.php`: lista empresas e produtos pre-aprovados com filtros (`q`, `estado`, `cidade`, `bairro`).
- `autocomplete.php`: sugestões por prefixo de nome/CNPJ.
- `detalhes.php`: página de detalhe da empresa e tabela de produtos.
- `script.js`: consome os endpoints acima, atualiza lista e gráfico (Chart.js).

## Modelo de Dados
- `d_empresas` (dimensão de empresas, PK `cnpj`).
- `d_produtos` (dimensão de produtos).
- `f_preaprovados` (fato de valores pre-aprovados por `cnpj`, `id_produto`, `data_referencia`).

## Decisão Registrada (2026-02-27)
- Você vai criar **uma nova aplicação** reaproveitando o mesmo backend.
- Stack alvo confirmada: **PHP + MySQL no XAMPP**.

## Observação
- Conexão atual está hardcoded nos endpoints:
  - host `localhost`
  - banco `PreAprovados`
  - usuário `root`
  - senha vazia
