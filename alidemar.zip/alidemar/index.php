﻿<!DOCTYPE html>
<html lang="pt-BR" data-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Alidemar | Painel de Gestão Comercial</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <div class="ambient"></div>

  <div class="app-layout">
    <aside class="sidebar">
      <div class="brand">
        <div id="sidebar-selected-user" class="brand-user">TODOS</div>
      </div>

      <nav class="nav">
        <button class="nav-btn is-active" data-view="dashboard" type="button">
          <span class="nav-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24">
              <rect x="3.5" y="3.5" width="7" height="7"></rect>
              <rect x="13.5" y="3.5" width="7" height="7"></rect>
              <rect x="3.5" y="13.5" width="7" height="7"></rect>
              <rect x="13.5" y="13.5" width="7" height="7"></rect>
            </svg>
          </span>
          <span>Dashboard</span>
        </button>
        <button class="nav-btn" data-view="visitas" type="button">
          <span class="nav-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24">
              <path d="M12 20s6-6 6-10a6 6 0 1 0-12 0c0 4 6 10 6 10Z"></path>
              <circle cx="12" cy="10" r="2.3"></circle>
            </svg>
          </span>
          <span>Visitas</span>
        </button>
        <button class="nav-btn" data-view="interacoes" type="button">
          <span class="nav-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24">
              <path d="M5 6h14v10H9l-4 4V6Z"></path>
            </svg>
          </span>
          <span>Interações</span>
        </button>
        <button class="nav-btn" data-view="compromissos" type="button">
          <span class="nav-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24">
              <rect x="3.5" y="5.5" width="17" height="15"></rect>
              <path d="M3.5 9.5h17"></path>
              <path d="M8 3.5v4"></path>
              <path d="M16 3.5v4"></path>
            </svg>
          </span>
          <span>Compromissos</span>
        </button>
      </nav>

      <section class="sidebar-filters card-lite">
        <h3>Filtros globais</h3>

        <label>Período
          <div id="filtro-periodo-dropdown" class="multi-dropdown">
            <button id="btn-periodo-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Mês atual</button>
            <div id="periodo-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <label class="multi-option">
                <input id="periodo-acumulado" type="checkbox" />
                <span>Acumulado (todos os meses)</span>
              </label>
              <div id="periodo-meses-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>

        <label>Usuário
          <select id="filtro-usuario-global"></select>
        </label>

        <label>Tipo de tratativa
          <select id="filtro-tratativa-global">
            <option value="all">Visitas + Interações</option>
            <option value="visitas">Somente visitas</option>
            <option value="interacoes">Somente interações</option>
          </select>
        </label>

        <label>Agência
          <select id="filtro-agencia-global"></select>
        </label>

        <label>Funcionário
          <select id="filtro-funcionario-global"></select>
        </label>

        <div class="sidebar-filter-actions">
          <button id="btn-aplicar-filtros" class="btn btn-ghost" type="button">Aplicar filtros</button>
          <button id="btn-limpar-filtros" class="btn btn-ghost" type="button">Limpar filtros</button>
        </div>
      </section>

      <div id="windows-user-email" class="sidebar-system-user">Windows: carregando...</div>
    </aside>

    <main class="main-content">
      <header class="topbar card">
        <div class="topbar-title-group">
          <h2 id="view-title">Painel de Gestão dos Gerentes de Segmento</h2>
        </div>

        <div class="topbar-actions">
          <button id="btn-open-quick-add" class="btn btn-add" type="button" aria-label="Novo registro">+</button>
          <label class="theme-switch" for="theme-switch-input" aria-label="Alternar tema">
            <input id="theme-switch-input" type="checkbox" />
            <span class="theme-switch-track">
              <span class="theme-switch-icon sun">&#9728;</span>
              <span class="theme-switch-thumb"></span>
              <span class="theme-switch-icon moon">&#9790;</span>
            </span>
          </label>
        </div>
      </header>

      <div id="global-feedback" class="feedback" role="status" aria-live="polite"></div>

      <section id="view-dashboard" class="view is-active">
        <div class="kpi-grid">
          <article id="kpi-card-visitas" class="kpi-card">
            <span>Total visitas</span>
            <strong id="kpi-total-visitas">0</strong>
          </article>
          <article id="kpi-card-interacoes" class="kpi-card">
            <span>Total interações</span>
            <strong id="kpi-total-interacoes">0</strong>
          </article>
          <article class="kpi-card">
            <span>Registros no período</span>
            <strong id="kpi-total-registros">0</strong>
          </article>
          <article class="kpi-card">
            <span>Demandas abertas</span>
            <strong id="kpi-demandas-abertas">0</strong>
          </article>
          <article class="kpi-card">
            <span>Compromissos no período</span>
            <strong id="kpi-total-compromissos">0</strong>
          </article>
        </div>

        <div class="dashboard-grid">
          <article id="card-evolucao" class="card chart-card chart-evolucao">
            <h3>Evolução de tratativas</h3>
            <div id="chart-evolucao" class="chart"></div>
          </article>

          <article id="card-top-volume" class="card chart-card chart-volume">
            <div class="card-head-inline">
              <h3 id="chart-volume-title">Quantidade de (Tratativas / Visitas / Interações)</h3>
              <div id="toggle-volume-group" class="toggle-group">
                <button class="toggle-btn is-active" data-agrupamento="agencia" type="button">Agência</button>
                <button class="toggle-btn" data-agrupamento="funcionario" type="button">Funcionário</button>
              </div>
            </div>
            <div id="chart-top-volume-scroll" class="chart-scroll-y">
              <div id="chart-top-volume" class="chart chart-tall"></div>
            </div>
          </article>

          <article id="card-interacoes-tipo" class="card chart-card chart-rosca">
            <h3>Interações por tipo</h3>
            <div id="chart-interacoes-tipo" class="chart"></div>
          </article>

          <article id="card-demandas-status" class="card chart-card chart-status">
            <h3>Tratativas por Status</h3>
            <div id="chart-demandas-status-scroll" class="chart-scroll-y">
              <div id="chart-demandas-status" class="chart"></div>
            </div>
          </article>

          <article id="card-compromissos-hoje" class="card chart-card chart-card-full">
            <h3>Próximos Compromissos</h3>
            <div id="lista-compromissos-hoje" class="compact-list compact-list-scroll"></div>
          </article>
        </div>
      </section>

      <section id="view-visitas" class="view">
        <div class="split-grid">
          <article class="card card-scroll">
            <h3>Nova visita</h3>
            <form id="form-visita" class="form-grid">
              <label>Usuário
                <select name="usuario_id" id="visita-usuario" required></select>
              </label>
              <label>Agência
                <select name="agencia_id" id="visita-agencia" required></select>
              </label>
              <label>Tema
                <select name="tema_visita_id" id="visita-tema" required></select>
              </label>
              <label>Status
                <select name="status_demanda_id" id="visita-status"></select>
              </label>
              <label>Área responsável
                <select name="area_responsavel_id" id="visita-area"></select>
              </label>
              <label>Data de contato
                <input type="datetime-local" name="data_contato" />
              </label>
              <label class="span-2">Tags
                <input type="text" name="tags" placeholder="credito, carteira, follow-up" />
              </label>
              <label class="span-2">Descrição
                <textarea name="descricao" required></textarea>
              </label>
              <label class="span-2">Demandas
                <textarea name="demandas"></textarea>
              </label>
              <label class="span-2">Participantes (Nome|Subseção; Nome|Subseção)
                <input type="text" name="participantes" placeholder="João|Gerente Agência; Ana|Relacionamento" />
              </label>
              <button class="btn" type="submit">Salvar visita</button>
            </form>
          </article>

          <article class="card card-scroll">
            <h3>Últimas visitas</h3>
            <div id="lista-visitas"></div>
          </article>
        </div>
      </section>

      <section id="view-interacoes" class="view">
        <div class="split-grid">
          <article class="card card-scroll">
            <h3>Nova interação</h3>
            <form id="form-interacao" class="form-grid">
              <label>Usuário
                <select name="usuario_id" id="interacao-usuario" required></select>
              </label>
              <label>Tipo de interação
                <select name="tipo_interacao_id" id="interacao-tipo" required></select>
              </label>
              <label>Agência
                <select name="agencia_id" id="interacao-agencia"></select>
              </label>
              <label>Status
                <select name="status_demanda_id" id="interacao-status"></select>
              </label>
              <label>Área responsável
                <select name="area_responsavel_id" id="interacao-area"></select>
              </label>
              <label>Data de contato
                <input type="datetime-local" name="data_contato" />
              </label>
              <label>Diretoria
                <input type="text" name="diretoria" />
              </label>
              <label>Regional
                <input type="text" name="regional" />
              </label>
              <label>Contato principal
                <input type="text" name="nome_contato" />
              </label>
              <label>Subseção do contato
                <input type="text" name="subsecao_contato" />
              </label>
              <label class="span-2">Assunto
                <input type="text" name="assunto" required />
              </label>
              <label class="span-2">Descrição
                <textarea name="descricao" required></textarea>
              </label>
              <label class="span-2">Demandas
                <textarea name="demandas"></textarea>
              </label>
              <label class="span-2">Tags
                <input type="text" name="tags" />
              </label>
              <label class="span-2">Contatos (Nome|Subseção; Nome|Subseção)
                <input type="text" name="contatos" placeholder="Mariana|Diretor; Felipe|Team Leader" />
              </label>
              <button class="btn" type="submit">Salvar interação</button>
            </form>
          </article>

          <article class="card card-scroll">
            <h3>Últimas interações</h3>
            <div id="lista-interacoes"></div>
          </article>
        </div>
      </section>

      <section id="view-compromissos" class="view">
        <div class="split-grid">
          <article class="card card-scroll">
            <h3>Novo compromisso</h3>
            <form id="form-compromisso" class="form-grid">
              <label>Usuário
                <select name="usuario_id" id="compromisso-usuario" required></select>
              </label>
              <label>Tipo
                <select name="tipo_compromisso_id" id="compromisso-tipo" required></select>
              </label>
              <label class="span-2">Título
                <input type="text" name="titulo" required />
              </label>
              <label class="span-2">Descrição
                <textarea name="descricao"></textarea>
              </label>
              <label>Data de início
                <input type="datetime-local" name="data_inicio" required />
              </label>
              <label>Data fim
                <input type="datetime-local" name="data_fim" required />
              </label>
              <label>Cor
                <input type="color" name="cor" value="#cc092f" />
              </label>
              <button class="btn" type="submit">Salvar compromisso</button>
            </form>
          </article>

          <article class="card card-scroll">
            <h3>Próximos compromissos</h3>
            <div id="lista-compromissos"></div>
          </article>
        </div>
      </section>
    </main>
  </div>

  <div id="access-overlay" class="access-overlay is-hidden" aria-hidden="true">
    <div class="access-overlay-card">
      <h3 id="access-overlay-title">Acesso nao autorizado</h3>
      <p id="access-overlay-message">Seu usuario nao possui acesso a esta aplicacao.</p>
    </div>
  </div>

  <div id="quick-add-modal" class="modal-backdrop is-hidden" aria-hidden="true">
    <div class="modal-card">
      <div class="modal-head">
        <h3>Novo registro rápido</h3>
        <button id="btn-close-quick-add" class="modal-close" type="button" aria-label="Fechar">x</button>
      </div>

      <form id="form-quick-add" class="form-grid modal-form">
        <label class="span-2">Tipo de Tratativa
          <select id="quick-add-tipo" name="tipo_insert" required>
            <option value="interacao">Interação</option>
            <option value="visita">Visita</option>
            <option value="compromisso">Compromisso</option>
          </select>
        </label>

        <div id="quick-fields-interacao" class="quick-fields span-2">
          <label>Usuário
            <select id="quick-interacao-usuario" required></select>
          </label>
          <label>Tipo de interação
            <select id="quick-interacao-tipo" required></select>
          </label>
          <label>Agência
            <select id="quick-interacao-agencia"></select>
          </label>
          <label>Status
            <select id="quick-interacao-status"></select>
          </label>
          <label class="span-2">Assunto
            <input id="quick-interacao-assunto" type="text" required />
          </label>
          <label class="span-2">Descrição
            <textarea id="quick-interacao-descricao" required></textarea>
          </label>
          <label>Contato principal
            <input id="quick-interacao-contato" type="text" />
          </label>
          <label>Data de contato
            <input id="quick-interacao-data" type="datetime-local" />
          </label>
        </div>

        <div id="quick-fields-visita" class="quick-fields span-2 is-hidden">
          <label>Usuário
            <select id="quick-visita-usuario" required></select>
          </label>
          <label>Agência
            <select id="quick-visita-agencia" required></select>
          </label>
          <label>Tema visita
            <select id="quick-visita-tema" required></select>
          </label>
          <label>Status
            <select id="quick-visita-status"></select>
          </label>
          <label class="span-2">Descrição
            <textarea id="quick-visita-descricao" required></textarea>
          </label>
          <label class="span-2">Participantes (Nome|Subseção; Nome|Subseção)
            <input id="quick-visita-participantes" type="text" />
          </label>
          <label>Data de contato
            <input id="quick-visita-data" type="datetime-local" />
          </label>
          <label>Tags
            <input id="quick-visita-tags" type="text" />
          </label>
        </div>

        <div id="quick-fields-compromisso" class="quick-fields span-2 is-hidden">
          <label>Usuário
            <select id="quick-compromisso-usuario" required></select>
          </label>
          <label>Tipo compromisso
            <select id="quick-compromisso-tipo" required></select>
          </label>
          <label class="span-2">Título
            <input id="quick-compromisso-titulo" type="text" required />
          </label>
          <label>Data de início
            <input id="quick-compromisso-inicio" type="datetime-local" required />
          </label>
          <label>Data fim
            <input id="quick-compromisso-fim" type="datetime-local" required />
          </label>
          <label class="span-2">Descrição
            <textarea id="quick-compromisso-descricao"></textarea>
          </label>
        </div>

        <div class="span-2 modal-actions">
          <button id="btn-save-quick-add" class="btn" type="submit">Salvar</button>
        </div>
      </form>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
  <script src="app.js"></script>
</body>
</html>
