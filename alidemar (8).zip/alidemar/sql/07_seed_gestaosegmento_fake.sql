﻿-- Dados fictícios opcionais para testes visuais no GestaoSegmento
USE `GestaoSegmento`;

SET @u_ademar := (SELECT id_usuario FROM dUsuarios WHERE usuario = 'Ademar Liberato' LIMIT 1);
SET @u_aline  := (SELECT id_usuario FROM dUsuarios WHERE usuario = 'Aline Rosa' LIMIT 1);

SET @c_regional   := (SELECT id_cargo FROM dCargos WHERE cargo = 'Gerente Regional' LIMIT 1);
SET @c_exec       := (SELECT id_cargo FROM dCargos WHERE cargo = 'Gerente Executivo Comercial' LIMIT 1);
SET @c_relac      := (SELECT id_cargo FROM dCargos WHERE cargo = 'Gerente de Relacionamento' LIMIT 1);
SET @c_assistente := (SELECT id_cargo FROM dCargos WHERE cargo = 'Assistente' LIMIT 1);

SET @a_orc  := 1;   -- Orçamento
SET @a_est  := 2;   -- Estratégia Comercial
SET @a_venc := 3;   -- Gestão de Vencidos
SET @a_cash := 9;   -- Produtividade Cash
SET @a_con  := 13;  -- Conecta
SET @a_of   := 14;  -- Open Finance

INSERT INTO fTratativas (`data`, id_tratativa, id_usuario, id_cargo, id_assunto, descricao, contatos, alcance) VALUES
('2025-09-03 09:10:00', 2, @u_ademar, @c_regional, @a_orc,  'Visita presencial com foco em orçamento.', '[{"nome":"Carlos Lima","subsecao":"Gerente Regional"}]', 11),
('2025-09-05 10:20:00', 1, @u_ademar, @c_exec,     @a_est,  'Reunião Teams sobre estratégia comercial.', '[{"nome":"Ana Costa","subsecao":"Gerente Executivo Comercial"}]', 8),
('2025-09-09 14:30:00', 3, @u_aline,  @c_relac,    @a_con,  'Ligação para alinhamento de carteira.', '[{"nome":"Rita Campos","subsecao":"Gerente de Relacionamento"}]', 5),
('2025-09-15 11:40:00', 2, @u_aline,  @c_assistente,@a_cash,'Visita de acompanhamento de produtividade.', '[{"nome":"Bruno Dias","subsecao":"Assistente"}]', 9),

('2025-10-02 09:00:00', 1, @u_ademar, @c_exec,     @a_orc,  'Teams mensal de metas.', '[{"nome":"João Silva","subsecao":"Gerente Executivo Comercial"}]', 12),
('2025-10-04 16:10:00', 2, @u_ademar, @c_regional, @a_venc, 'Visita para gestão de vencidos.', '[{"nome":"Larissa Rocha","subsecao":"Gerente Regional"}]', 14),
('2025-10-07 08:50:00', 3, @u_aline,  @c_relac,    @a_of,   'Ligação sobre oferta Open Finance.', '[{"nome":"Renata Souza","subsecao":"Gerente de Relacionamento"}]', 6),
('2025-10-22 13:15:00', 1, @u_aline,  @c_exec,     @a_est,  'Teams de revisão de pipeline.', '[{"nome":"Thiago Prado","subsecao":"Gerente Executivo Comercial"}]', 10),

('2025-11-01 10:00:00', 2, @u_ademar, @c_regional, @a_con,  'Visita comercial com pauta Conecta.', '[{"nome":"Pedro Nogueira","subsecao":"Gerente Regional"}]', 15),
('2025-11-06 15:45:00', 1, @u_aline,  @c_exec,     @a_cash, 'Teams para produtividade cash.', '[{"nome":"Mariana Freitas","subsecao":"Gerente Executivo Comercial"}]', 9),
('2025-11-12 09:35:00', 3, @u_ademar, @c_relac,    @a_venc, 'Ligação de cobrança de pendências.', '[{"nome":"Clara Ribeiro","subsecao":"Gerente de Relacionamento"}]', 4),
('2025-11-20 11:10:00', 2, @u_aline,  @c_assistente,@a_orc, 'Visita para revisão de orçamento PJ.', '[{"nome":"Sonia Araujo","subsecao":"Assistente"}]', 13),

('2025-12-03 14:00:00', 1, @u_ademar, @c_exec,     @a_est,  'Teams de encerramento do trimestre.', '[{"nome":"Felipe Gomes","subsecao":"Gerente Executivo Comercial"}]', 7),
('2025-12-08 10:25:00', 2, @u_aline,  @c_regional, @a_con,  'Visita com foco em Conecta.', '[{"nome":"Patricia Mello","subsecao":"Gerente Regional"}]', 16),
('2025-12-16 16:35:00', 3, @u_aline,  @c_relac,    @a_of,   'Ligação de reforço Open Finance.', '[{"nome":"Davi Moreira","subsecao":"Gerente de Relacionamento"}]', 5),
('2025-12-23 09:55:00', 2, @u_ademar, @c_assistente,@a_cash,'Visita para melhoria de conversão.', '[{"nome":"Ana Costa","subsecao":"Assistente"}]', 12),

('2026-01-04 08:40:00', 2, @u_ademar, @c_regional, @a_orc,  'Visita de abertura do ano.', '[{"nome":"João Silva","subsecao":"Gerente Regional"}]', 18),
('2026-01-10 10:30:00', 1, @u_ademar, @c_exec,     @a_est,  'Teams com plano comercial do mês.', '[{"nome":"Rita Campos","subsecao":"Gerente Executivo Comercial"}]', 11),
('2026-01-14 15:20:00', 3, @u_aline,  @c_relac,    @a_con,  'Ligação para alinhamento de metas.', '[{"nome":"Carlos Lima","subsecao":"Gerente de Relacionamento"}]', 6),
('2026-01-18 19:00:00', 4, @u_aline,  @c_exec,     @a_est,  'Live comercial para revisão de estratégia regional.', '[{"nome":"Time Comercial","subsecao":"Live"}]', 42),
('2026-01-28 13:45:00', 1, @u_aline,  @c_exec,     @a_of,   'Teams de oferta Open Finance.', '[{"nome":"Bruno Dias","subsecao":"Gerente Executivo Comercial"}]', 10),

('2026-02-02 09:00:00', 2, @u_aline,  @c_assistente,@a_cash,'Visita técnica de produtividade.', '[{"nome":"Larissa Rocha","subsecao":"Assistente"}]', 8),
('2026-02-05 11:30:00', 1, @u_ademar, @c_exec,     @a_venc, 'Teams para carteira vencida.', '[{"nome":"Mariana Freitas","subsecao":"Gerente Executivo Comercial"}]', 9),
('2026-02-12 17:00:00', 3, @u_ademar, @c_relac,    @a_orc,  'Ligação de suporte comercial.', '[{"nome":"Renata Souza","subsecao":"Gerente de Relacionamento"}]', 5),
('2026-02-18 10:50:00', 2, @u_aline,  @c_regional, @a_est,  'Visita para estratégia regional.', '[{"nome":"Pedro Nogueira","subsecao":"Gerente Regional"}]', 14),
('2026-02-24 15:30:00', 5, @u_ademar, @c_regional, @a_con,  'Evento regional com foco em Conecta e negócios.', '[{"nome":"Público Regional","subsecao":"Evento"}]', 65);
