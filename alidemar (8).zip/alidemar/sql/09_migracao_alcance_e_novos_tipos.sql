-- Migracao segura para base ja existente do GestaoSegmento
-- Nao apaga dados. Apenas adiciona a coluna alcance e garante os novos tipos.

USE `GestaoSegmento`;

SET NAMES utf8mb4;

SET @sql_add_alcance = (
  SELECT IF(
    EXISTS (
      SELECT 1
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'fTratativas'
        AND COLUMN_NAME = 'alcance'
    ),
    'SELECT "Coluna alcance ja existe." AS info',
    'ALTER TABLE `fTratativas` ADD COLUMN `alcance` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `contatos`'
  )
);

PREPARE stmt_add_alcance FROM @sql_add_alcance;
EXECUTE stmt_add_alcance;
DEALLOCATE PREPARE stmt_add_alcance;

UPDATE `fTratativas`
SET `alcance` = 0
WHERE `alcance` IS NULL;

INSERT INTO `dTipoTratativa` (`id_tratativa`, `tipo_tratativa`, `ativo`)
VALUES
  (1, 'Teams', 1),
  (2, 'Visitas', 1),
  (3, 'Ligacoes', 1),
  (4, 'Live', 1),
  (5, 'Evento', 1)
ON DUPLICATE KEY UPDATE
  `tipo_tratativa` = VALUES(`tipo_tratativa`),
  `ativo` = 1;
