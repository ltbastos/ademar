<?php

function gs_ensure_tratativas_support(mysqli $db): void
{
    gs_ensure_tipo_tratativa_defaults($db);
    gs_ensure_alcance_column($db);
}

function gs_ensure_tipo_tratativa_defaults(mysqli $db): void
{
    $defaults = [
        [1, 'Teams'],
        [2, 'Visitas'],
        [3, 'Ligacoes'],
        [4, 'Live'],
        [5, 'Evento'],
    ];

    foreach ($defaults as [$id, $nome]) {
        db_execute(
            $db,
            'INSERT INTO dTipoTratativa (id_tratativa, tipo_tratativa, ativo)
             VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE
               tipo_tratativa = VALUES(tipo_tratativa),
               ativo = 1',
            'is',
            [$id, $nome]
        );
    }
}

function gs_ensure_alcance_column(mysqli $db): void
{
    if (!gs_has_column($db, 'fTratativas', 'alcance')) {
        db_execute(
            $db,
            'ALTER TABLE fTratativas
             ADD COLUMN alcance INT UNSIGNED NOT NULL DEFAULT 0
             AFTER contatos'
        );
    }

    db_execute(
        $db,
        'UPDATE fTratativas
         SET alcance = 0
         WHERE alcance IS NULL'
    );
}

function gs_has_table(mysqli $db, string $tableName): bool
{
    $row = db_query_one(
        $db,
        'SELECT 1 AS existe
         FROM INFORMATION_SCHEMA.TABLES
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
         LIMIT 1',
        's',
        [$tableName]
    );

    return $row !== null;
}

function gs_has_column(mysqli $db, string $tableName, string $columnName): bool
{
    $row = db_query_one(
        $db,
        'SELECT 1 AS existe
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
           AND COLUMN_NAME = ?
         LIMIT 1',
        'ss',
        [$tableName, $columnName]
    );

    return $row !== null;
}

function gs_has_tratativas_cargos_table(mysqli $db): bool
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }

    $cached = gs_has_table($db, 'fTratativasCargos');
    return $cached;
}

function gs_fetch_tipo_tratativas_ativas(mysqli $db): array
{
    return db_query_all(
        $db,
        'SELECT
            t.id_tratativa AS id,
            t.tipo_tratativa AS nome
         FROM dTipoTratativa t
         WHERE t.ativo = 1
         ORDER BY t.id_tratativa ASC'
    );
}

function gs_tipo_tratativa_id_exists(mysqli $db, int $idTratativa): bool
{
    $row = db_query_one(
        $db,
        'SELECT 1 AS existe
         FROM dTipoTratativa
         WHERE id_tratativa = ?
           AND ativo = 1
         LIMIT 1',
        'i',
        [$idTratativa]
    );

    return $row !== null;
}

function gs_resolve_tipo_tratativa_filter(mysqli $db, $raw): ?int
{
    $text = to_string_or_null($raw);
    if ($text === null || strtolower($text) === 'all') {
        return null;
    }

    $id = to_int_or_null($text);
    if ($id !== null && $id > 0 && gs_tipo_tratativa_id_exists($db, $id)) {
        return $id;
    }

    $normalized = gs_normalize_tipo_token($text);
    $legacyMap = [
        'teams' => 1,
        'visitas' => 2,
        'ligacao' => 3,
        'ligacoes' => 3,
        'live' => 4,
        'evento' => 5,
    ];

    $resolved = $legacyMap[$normalized] ?? null;
    if ($resolved !== null && gs_tipo_tratativa_id_exists($db, $resolved)) {
        return $resolved;
    }

    return null;
}

function gs_normalize_tipo_token(string $text): string
{
    $value = strtolower(trim($text));
    $value = strtr(
        $value,
        [
            'á' => 'a',
            'à' => 'a',
            'â' => 'a',
            'ã' => 'a',
            'ä' => 'a',
            'é' => 'e',
            'è' => 'e',
            'ê' => 'e',
            'ë' => 'e',
            'í' => 'i',
            'ì' => 'i',
            'î' => 'i',
            'ï' => 'i',
            'ó' => 'o',
            'ò' => 'o',
            'ô' => 'o',
            'õ' => 'o',
            'ö' => 'o',
            'ú' => 'u',
            'ù' => 'u',
            'û' => 'u',
            'ü' => 'u',
            'ç' => 'c',
        ]
    );
    $value = preg_replace('/[^a-z0-9]+/', '', $value) ?? '';

    return $value;
}

function gs_cargo_count_sql(mysqli $db, string $alias): string
{
    if (gs_has_tratativas_cargos_table($db)) {
        return '(SELECT COUNT(*)
            FROM fTratativasCargos tc
            WHERE tc.id_tratativa = ' . $alias . '.id)';
    }

    return '(CASE WHEN ' . $alias . '.id_cargo IS NULL THEN 0 ELSE 1 END)';
}

function gs_alcance_total_sql(mysqli $db, string $alias): string
{
    return '(COALESCE(' . $alias . '.alcance, 0) + ' . gs_cargo_count_sql($db, $alias) . ')';
}

function gs_parse_alcance($raw, int $default = 0): ?int
{
    if ($raw === null) {
        return $default;
    }

    $text = trim((string) $raw);
    if ($text === '') {
        return $default;
    }

    if (preg_match('/^\d+$/', $text) !== 1) {
        return null;
    }

    $value = (int) $text;
    return $value >= 0 ? $value : null;
}
