﻿<!DOCTYPE html>
<html lang="pt-BR" data-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Conseg PJ</title>
  <link id="site-favicon" rel="icon" type="image/svg+xml" href="assets/logo-bu-empresas-negocios-icon-blue.svg" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" />
  <script>
    (() => {
      const lightHref = "assets/logo-bu-empresas-negocios-icon-blue.svg";
      const darkHref = "assets/logo-bu-empresas-negocios-icon-red.svg";
      const media = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;

      const applyFavicon = () => {
        const link = document.getElementById("site-favicon");
        if (!link) {
          return;
        }
        link.href = media && media.matches ? darkHref : lightHref;
      };

      applyFavicon();

      if (media) {
        if (typeof media.addEventListener === "function") {
          media.addEventListener("change", applyFavicon);
        } else if (typeof media.addListener === "function") {
          media.addListener(applyFavicon);
        }
      }
    })();
  </script>
</head>
<body>
  <div class="ambient"></div>

  <section id="auth-screen" class="auth-screen">
    <div class="auth-shell">
      <div class="auth-card">
        <div class="auth-logo-stage">
          <img class="auth-logo auth-logo-light" src="assets/logo-bu-empresas-negocios.svg" alt="BU Empresas e Negócios" />
          <img class="auth-logo auth-logo-dark" src="assets/logo-bu-empresas-negocios-dark.svg" alt="BU Empresas e Negócios" />
        </div>

        <div class="auth-card-head">
          <h1>Conseg PJ</h1>
        </div>

        <div id="auth-feedback" class="auth-feedback is-hidden" role="status" aria-live="polite"></div>

        <div class="auth-mode-switch" role="tablist" aria-label="Modos de autenticação">
          <button id="btn-auth-mode-login" class="auth-mode-btn is-active" type="button" role="tab" aria-selected="true">Entrar</button>
          <button id="btn-auth-mode-setup" class="auth-mode-btn" type="button" role="tab" aria-selected="false">Primeiro acesso</button>
        </div>

        <form id="form-login" class="auth-form" autocomplete="on">
          <label>Funcional
            <input id="login-funcional" type="text" maxlength="16" placeholder="Ex.: F750931" autocomplete="username" required />
          </label>

          <label>Senha
            <input id="login-senha" type="password" placeholder="Digite sua senha" autocomplete="current-password" required />
          </label>

          <button id="btn-auth-login" class="btn auth-submit-btn" type="submit">Entrar</button>
        </form>

        <form id="form-setup" class="auth-form is-hidden" autocomplete="on">
          <label>Funcional
            <input id="setup-funcional" type="text" maxlength="16" placeholder="Ex.: F750931" autocomplete="username" required />
          </label>

          <label>E-mail corporativo
            <input id="setup-email" type="email" maxlength="191" placeholder="nome@bradesco.com.br" autocomplete="email" required />
          </label>

          <label>Nova senha
            <input id="setup-senha" type="password" minlength="6" placeholder="Mínimo de 6 caracteres" autocomplete="new-password" required />
          </label>

          <label>Confirmar senha
            <input id="setup-confirmacao-senha" type="password" minlength="6" placeholder="Repita a senha" autocomplete="new-password" required />
          </label>

          <button id="btn-auth-setup" class="btn auth-submit-btn" type="submit">Cadastrar senha</button>
        </form>
      </div>
    </div>
  </section>

  <div id="app-layout" class="app-layout is-hidden">
    <aside class="sidebar">
      <div class="brand">
        <div id="sidebar-selected-user" class="brand-user">TODOS</div>
      </div>

      <section class="sidebar-pages card-lite">
        <h3>Páginas</h3>
        <nav class="nav">
          <button class="nav-btn is-active" data-view="dashboard" type="button">
            <span class="nav-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24">
                <rect x="3.5" y="3.5" width="7" height="7"></rect>
                <rect x="13.5" y="3.5" width="7" height="7"></rect>
                <rect x="3.5" y="13.5" width="7" height="7"></rect>
                <rect x="13.5" y="13.5" width="7" height="7"></rect>
              </svg>
            </span>
            <span>Dashboard</span>
          </button>

          <button class="nav-btn" data-view="analitico" type="button">
            <span class="nav-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24">
                <path d="M4 5.5h16"></path>
                <path d="M4 12h16"></path>
                <path d="M4 18.5h16"></path>
                <circle cx="7" cy="5.5" r="0.6"></circle>
                <circle cx="7" cy="12" r="0.6"></circle>
                <circle cx="7" cy="18.5" r="0.6"></circle>
              </svg>
            </span>
            <span>Analítico</span>
          </button>
        </nav>
      </section>

      <section class="sidebar-filters card-lite">
        <h3>Filtros globais</h3>

        <label>Período
          <div id="filtro-periodo-dropdown" class="multi-dropdown">
            <button id="btn-periodo-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Mês atual</button>
            <div id="periodo-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div class="multi-options-actions">
                <button id="btn-periodo-toggle-all" class="multi-options-toggle" type="button">Selecionar tudo</button>
              </div>
              <div id="periodo-meses-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>

        <label>Usuário
          <div id="filtro-usuario-dropdown" class="multi-dropdown">
            <button id="btn-usuario-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Todos</button>
            <div id="usuario-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div class="multi-options-actions">
                <button id="btn-usuario-toggle-all" class="multi-options-toggle" type="button">Selecionar tudo</button>
              </div>
              <div id="usuario-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>

        <label>Tipo de tratativa
          <div id="filtro-tratativa-dropdown" class="multi-dropdown">
            <button id="btn-tratativa-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Todos</button>
            <div id="tratativa-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div class="multi-options-actions">
                <button id="btn-tratativa-toggle-all" class="multi-options-toggle" type="button">Selecionar tudo</button>
              </div>
              <div id="tratativa-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>

        <label>Cargo
          <div id="filtro-cargo-dropdown" class="multi-dropdown">
            <button id="btn-cargo-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Todos</button>
            <div id="cargo-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div class="multi-options-actions">
                <button id="btn-cargo-toggle-all" class="multi-options-toggle" type="button">Selecionar tudo</button>
              </div>
              <div id="cargo-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>

        <label>Assunto
          <div id="filtro-assunto-dropdown" class="multi-dropdown">
            <button id="btn-assunto-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Todos</button>
            <div id="assunto-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div class="multi-options-actions">
                <button id="btn-assunto-toggle-all" class="multi-options-toggle" type="button">Selecionar tudo</button>
              </div>
              <div id="assunto-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>
      </section>

      <section class="sidebar-identity card-lite">
        <h3>Identidade Windows / AD</h3>
        <div id="identity-note" class="identity-note">Carregando contexto do ambiente...</div>
        <dl id="identity-grid" class="identity-grid">
          <div>
            <dt>Usuário de rede</dt>
            <dd id="identity-user">-</dd>
          </div>
          <div>
            <dt>Usuário Windows</dt>
            <dd id="identity-username">-</dd>
          </div>
          <div>
            <dt>Grupo</dt>
            <dd id="identity-groups-count">-</dd>
          </div>
          <div>
            <dt>Computador</dt>
            <dd id="identity-computer">-</dd>
          </div>
          <div>
            <dt>Domínio</dt>
            <dd id="identity-domain">-</dd>
          </div>
          <div>
            <dt>Logon Server</dt>
            <dd id="identity-logonserver">-</dd>
          </div>
        </dl>
        <div id="identity-groups" class="identity-groups"></div>
      </section>
    </aside>

    <main class="main-content">
      <header class="topbar card">
        <div class="topbar-title-group">
          <h2 id="view-title">Conseg PJ</h2>
        </div>

        <div class="topbar-actions">
          <div id="auth-user-chip" class="auth-user-chip is-hidden">
            <strong id="auth-user-name">-</strong>
            <span id="auth-user-meta">-</span>
          </div>
          <button id="btn-open-quick-add" class="btn btn-add" type="button" aria-label="Nova tratativa">+</button>
          <label class="theme-switch" for="theme-switch-input" aria-label="Alternar tema">
            <input id="theme-switch-input" type="checkbox" />
            <span class="theme-switch-track">
              <span class="theme-switch-icon sun">&#9728;</span>
              <span class="theme-switch-thumb"></span>
              <span class="theme-switch-icon moon">&#9790;</span>
            </span>
          </label>
          <button id="btn-logout" class="btn btn-ghost" type="button">Sair</button>
        </div>
      </header>

      <div id="mobile-filters-host" class="mobile-filters-host"></div>

      <div id="global-feedback" class="feedback" role="status" aria-live="polite"></div>
      <div id="period-empty-message" class="empty-inline is-hidden">Não há dados para os meses selecionados.</div>
      <div id="global-loading" class="loading-overlay" aria-hidden="false">
        <div class="loading-spinner" aria-hidden="true"></div>
        <p id="global-loading-text">Inicializando dashboard...</p>
      </div>

      <section id="view-dashboard" class="view is-active">
        <div class="kpi-grid">
          <article class="kpi-card">
            <span>Total de Tratativas</span>
            <strong id="kpi-total-tratativas">0</strong>
          </article>
          <article class="kpi-card">
            <span>Teams</span>
            <strong id="kpi-total-teams">0</strong>
          </article>
          <article class="kpi-card">
            <span>Visitas</span>
            <strong id="kpi-total-visitas">0</strong>
          </article>
          <article class="kpi-card">
            <span>Ligações</span>
            <strong id="kpi-total-ligacoes">0</strong>
          </article>
          <article class="kpi-card">
            <span>Evento</span>
            <strong id="kpi-total-evento">0</strong>
          </article>
          <article class="kpi-card">
            <span>Live</span>
            <strong id="kpi-total-live">0</strong>
          </article>
          <article class="kpi-card">
            <span>Alcance</span>
            <strong id="kpi-total-alcance">0</strong>
          </article>
        </div>

        <div class="dashboard-grid">
          <article id="card-evolucao" class="card chart-card chart-evolucao">
            <div class="card-head-inline card-head-evolucao">
              <h3 id="chart-evolucao-title">Evolução de tratativas</h3>
              <div class="card-head-evolucao-actions">
                <div class="toggle-group">
                  <button id="btn-evolucao-tratativas" class="toggle-btn is-active" type="button" data-evolucao-modo="tratativas">Tratativas</button>
                  <button id="btn-evolucao-alcance" class="toggle-btn" type="button" data-evolucao-modo="alcance">Alcance</button>
                </div>
                <div class="toggle-group toggle-group-arrows">
                  <button
                    id="btn-granularidade-mes"
                    class="toggle-btn toggle-btn-icon"
                    type="button"
                    data-granularidade="mes"
                    title="Subir nível para mensal"
                    aria-label="Subir nível para mensal"
                  >
                    <span class="toggle-btn-icon-wrap" aria-hidden="true">
                      <svg viewBox="0 0 24 24">
                        <path d="M12 18V6"></path>
                        <path d="M7 11l5-5 5 5"></path>
                      </svg>
                    </span>
                  </button>
                  <button
                    id="btn-granularidade-dia"
                    class="toggle-btn toggle-btn-icon is-active"
                    type="button"
                    data-granularidade="dia"
                    title="Descer nível para diário"
                    aria-label="Descer nível para diário"
                  >
                    <span class="toggle-btn-icon-wrap" aria-hidden="true">
                      <svg viewBox="0 0 24 24">
                        <path d="M12 6v12"></path>
                        <path d="M7 13l5 5 5-5"></path>
                      </svg>
                    </span>
                  </button>
                </div>
              </div>
            </div>
            <div id="chart-evolucao-scroll" class="chart-scroll-x">
              <div id="chart-evolucao" class="chart"></div>
            </div>
          </article>

          <article id="card-top-volume" class="card chart-card chart-volume">
            <div class="card-head-inline">
              <h3 id="chart-volume-title">Quantidade de Tratativas por Assunto</h3>
            </div>
            <div id="chart-top-volume-scroll" class="chart-scroll-y">
              <div id="chart-top-volume" class="chart chart-tall"></div>
            </div>
          </article>

          <article id="card-interacoes-tipo" class="card chart-card chart-rosca">
            <h3>Tratativas por tipo</h3>
            <div id="chart-interacoes-tipo" class="chart"></div>
          </article>

          <article id="card-demandas-status" class="card chart-card chart-status">
            <h3>Tratativas por Cargo</h3>
            <div id="chart-demandas-status-scroll" class="chart-scroll-x">
              <div id="chart-demandas-status" class="chart"></div>
            </div>
          </article>

        </div>
      </section>

      <section id="view-analitico" class="view">
        <article class="card card-scroll">
          <div class="card-head-inline">
            <h3>Tratativas analíticas</h3>
            <div class="analitico-toolbar">
              <input id="analitico-search" type="search" placeholder="Pesquisar na tabela..." autocomplete="off" />
              <button id="btn-export-csv" class="btn btn-ghost" type="button">Exportar CSV</button>
            </div>
          </div>
          <div id="lista-analitico"></div>
        </article>
      </section>
    </main>
  </div>

  <div id="quick-add-modal" class="modal-backdrop is-hidden" aria-hidden="true">
    <div class="modal-card">
      <div class="modal-head">
        <h3 id="quick-modal-title">Nova tratativa</h3>
        <button id="btn-close-quick-add" class="modal-close" type="button" aria-label="Fechar">x</button>
      </div>

      <form id="form-quick-add" class="form-grid modal-form">
        <input id="quick-tratativa-id" type="hidden" />

        <label>Tipo de Tratativa
          <select id="quick-tratativa-tipo" required></select>
        </label>

        <label>Usuário
          <select id="quick-tratativa-usuario" required></select>
        </label>

        <label>Cargo
          <div id="quick-cargo-dropdown" class="multi-dropdown modal-multi-dropdown">
            <button id="btn-quick-cargo-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Selecione cargo(s)</button>
            <div id="quick-cargo-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div id="quick-cargo-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>

        <label>Junção
          <input id="quick-tratativa-agencia" type="text" placeholder="Digite a junção" />
        </label>

        <label class="span-2">Assunto
          <div id="quick-assunto-dropdown" class="multi-dropdown modal-multi-dropdown">
            <button id="btn-quick-assunto-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Selecione assunto(s)</button>
            <div id="quick-assunto-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div id="quick-assunto-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>

        <label class="span-2">Descrição
          <textarea id="quick-tratativa-descricao"></textarea>
        </label>

        <label class="span-2">Contato
          <input id="quick-tratativa-contato" type="text" placeholder="Nome do contato" />
        </label>

        <label>Alcance
          <input id="quick-tratativa-alcance" type="number" min="0" step="1" value="0" placeholder="Somado aos cargos selecionados" required />
        </label>

        <label>Data
          <input id="quick-tratativa-data" type="date" required />
        </label>

        <div class="span-2 modal-actions">
          <button id="btn-cancel-quick-add" class="btn btn-ghost" type="button">Cancelar</button>
          <button id="btn-save-quick-add" class="btn" type="submit">Salvar tratativa</button>
        </div>
      </form>
    </div>
  </div>

  <div id="confirm-modal" class="confirm-backdrop is-hidden" aria-hidden="true">
    <div class="confirm-card" role="dialog" aria-modal="true" aria-labelledby="confirm-title" aria-describedby="confirm-message">
      <h3 id="confirm-title">Confirmar ação</h3>
      <p id="confirm-message">Tem certeza que deseja continuar?</p>
      <div class="confirm-actions">
        <button id="btn-confirm-cancel" class="btn btn-ghost" type="button">Cancelar</button>
        <button id="btn-confirm-ok" class="btn" type="button">Confirmar</button>
      </div>
    </div>
  </div>

  <script src="vendor/apexcharts.min.js"></script>
  <script src="app.js"></script>
</body>
</html>
