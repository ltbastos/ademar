CREATE DATABASE IF NOT EXISTS `estrutura`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `estrutura`;

CREATE TABLE IF NOT EXISTS `auth_colaborador_aliases` (
  `id_alias` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_colaborador` BIGINT UNSIGNED NOT NULL,
  `origem` VARCHAR(80) NOT NULL,
  `alias_nome` VARCHAR(191) NOT NULL,
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_alias`),
  UNIQUE KEY `uk_auth_colaborador_aliases_origem_nome` (`origem`, `alias_nome`),
  KEY `idx_auth_colaborador_aliases_colaborador` (`id_colaborador`),
  KEY `idx_auth_colaborador_aliases_ativo` (`ativo`),
  CONSTRAINT `fk_auth_colaborador_aliases_colaborador`
    FOREIGN KEY (`id_colaborador`) REFERENCES `colaboradores` (`id_colaborador`)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `auth_colaborador_aliases` (`id_colaborador`, `origem`, `alias_nome`, `ativo`)
SELECT c.id_colaborador, 'alidemar', 'Ademar Liberato', 1
FROM colaboradores c
WHERE c.funcional = 'F750931'
ON DUPLICATE KEY UPDATE
  `id_colaborador` = VALUES(`id_colaborador`),
  `ativo` = VALUES(`ativo`);

INSERT INTO `auth_colaborador_aliases` (`id_colaborador`, `origem`, `alias_nome`, `ativo`)
SELECT c.id_colaborador, 'alidemar', 'Aline Rosa', 1
FROM colaboradores c
WHERE c.funcional = 'E963052'
ON DUPLICATE KEY UPDATE
  `id_colaborador` = VALUES(`id_colaborador`),
  `ativo` = VALUES(`ativo`);
