CREATE DATABASE IF NOT EXISTS `estrutura`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `estrutura`;

CREATE TABLE IF NOT EXISTS `colaboradores` (
  `id_colaborador` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `juncao` INT UNSIGNED NULL,
  `juncao_sup` INT UNSIGNED NULL,
  `posto` INT UNSIGNED NULL,
  `funcional` VARCHAR(16) NOT NULL,
  `cod_funcional` VARCHAR(16) NULL,
  `email` VARCHAR(191) NULL,
  `nome` VARCHAR(200) NOT NULL,
  `funcao` VARCHAR(120) NULL,
  `nivel` VARCHAR(20) NULL,
  `cargo` VARCHAR(200) NULL,
  `departamento` VARCHAR(200) NULL,
  `area` VARCHAR(200) NULL,
  `modificado_em` DATETIME NULL,
  `aprovador` VARCHAR(120) NULL,
  `juncoes_extras` TEXT NULL,
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_colaborador`),
  UNIQUE KEY `uk_colaboradores_funcional` (`funcional`),
  UNIQUE KEY `uk_colaboradores_cod_funcional` (`cod_funcional`),
  UNIQUE KEY `uk_colaboradores_email` (`email`),
  KEY `idx_colaboradores_juncao` (`juncao`),
  KEY `idx_colaboradores_juncao_sup` (`juncao_sup`),
  KEY `idx_colaboradores_funcao` (`funcao`),
  KEY `idx_colaboradores_nivel` (`nivel`),
  KEY `idx_colaboradores_departamento` (`departamento`(191)),
  KEY `idx_colaboradores_area` (`area`(191)),
  KEY `idx_colaboradores_ativo` (`ativo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `colaboradores` (
  `juncao`,
  `juncao_sup`,
  `posto`,
  `funcional`,
  `cod_funcional`,
  `email`,
  `nome`,
  `funcao`,
  `nivel`,
  `cargo`,
  `departamento`,
  `area`,
  `modificado_em`,
  `aprovador`,
  `juncoes_extras`,
  `ativo`
)
SELECT
  m.`Juncao`,
  m.`JuncaoSup`,
  m.`Posto`,
  UPPER(TRIM(m.`FuncionalLetra`)),
  NULLIF(TRIM(m.`CodFuncional`), ''),
  NULLIF(LOWER(TRIM(m.`Email`)), ''),
  TRIM(m.`Nome`),
  NULLIF(TRIM(m.`Funcao`), ''),
  NULLIF(TRIM(m.`Nivel`), ''),
  NULLIF(TRIM(m.`Cargo`), ''),
  NULLIF(TRIM(m.`Departamento`), ''),
  NULLIF(TRIM(m.`Area`), ''),
  m.`Modificado`,
  NULLIF(TRIM(m.`Aprovador`), ''),
  NULLIF(TRIM(m.`Juncoes_Extras`), ''),
  1
FROM `mesu` m
WHERE NULLIF(TRIM(m.`FuncionalLetra`), '') IS NOT NULL
ON DUPLICATE KEY UPDATE
  `juncao` = VALUES(`juncao`),
  `juncao_sup` = VALUES(`juncao_sup`),
  `posto` = VALUES(`posto`),
  `cod_funcional` = VALUES(`cod_funcional`),
  `email` = VALUES(`email`),
  `nome` = VALUES(`nome`),
  `funcao` = VALUES(`funcao`),
  `nivel` = VALUES(`nivel`),
  `cargo` = VALUES(`cargo`),
  `departamento` = VALUES(`departamento`),
  `area` = VALUES(`area`),
  `modificado_em` = VALUES(`modificado_em`),
  `aprovador` = VALUES(`aprovador`),
  `juncoes_extras` = VALUES(`juncoes_extras`),
  `ativo` = VALUES(`ativo`);
