CREATE DATABASE IF NOT EXISTS `estrutura`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `estrutura`;

CREATE TABLE IF NOT EXISTS `auth_aplicacoes` (
  `id_aplicacao` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `codigo` VARCHAR(80) NOT NULL,
  `nome` VARCHAR(150) NOT NULL,
  `descricao` VARCHAR(255) NULL,
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_aplicacao`),
  UNIQUE KEY `uk_auth_aplicacoes_codigo` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `auth_usuarios` (
  `id_auth_usuario` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_colaborador` BIGINT UNSIGNED NOT NULL,
  `senha_hash` VARCHAR(255) NOT NULL,
  `precisa_trocar_senha` TINYINT(1) NOT NULL DEFAULT 0,
  `ultimo_login_em` DATETIME NULL,
  `ultimo_login_ip` VARCHAR(45) NULL,
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_auth_usuario`),
  UNIQUE KEY `uk_auth_usuarios_colaborador` (`id_colaborador`),
  KEY `idx_auth_usuarios_ativo` (`ativo`),
  CONSTRAINT `fk_auth_usuarios_colaborador`
    FOREIGN KEY (`id_colaborador`) REFERENCES `colaboradores` (`id_colaborador`)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `auth_usuario_aplicacoes` (
  `id_auth_usuario_aplicacao` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_auth_usuario` BIGINT UNSIGNED NOT NULL,
  `id_aplicacao` INT UNSIGNED NOT NULL,
  `perfil` VARCHAR(40) NOT NULL DEFAULT 'usuario',
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_auth_usuario_aplicacao`),
  UNIQUE KEY `uk_auth_usuario_aplicacoes_usuario_app` (`id_auth_usuario`, `id_aplicacao`),
  KEY `idx_auth_usuario_aplicacoes_app` (`id_aplicacao`),
  KEY `idx_auth_usuario_aplicacoes_ativo` (`ativo`),
  CONSTRAINT `fk_auth_usuario_aplicacoes_usuario`
    FOREIGN KEY (`id_auth_usuario`) REFERENCES `auth_usuarios` (`id_auth_usuario`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_auth_usuario_aplicacoes_app`
    FOREIGN KEY (`id_aplicacao`) REFERENCES `auth_aplicacoes` (`id_aplicacao`)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `auth_eventos_login` (
  `id_evento` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_auth_usuario` BIGINT UNSIGNED NULL,
  `id_aplicacao` INT UNSIGNED NULL,
  `tipo_evento` VARCHAR(40) NOT NULL,
  `funcional_informado` VARCHAR(16) NULL,
  `ip` VARCHAR(45) NULL,
  `user_agent` VARCHAR(255) NULL,
  `detalhe` VARCHAR(255) NULL,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_evento`),
  KEY `idx_auth_eventos_login_usuario` (`id_auth_usuario`),
  KEY `idx_auth_eventos_login_aplicacao` (`id_aplicacao`),
  KEY `idx_auth_eventos_login_tipo` (`tipo_evento`),
  KEY `idx_auth_eventos_login_criado_em` (`criado_em`),
  CONSTRAINT `fk_auth_eventos_login_usuario`
    FOREIGN KEY (`id_auth_usuario`) REFERENCES `auth_usuarios` (`id_auth_usuario`)
    ON DELETE SET NULL,
  CONSTRAINT `fk_auth_eventos_login_aplicacao`
    FOREIGN KEY (`id_aplicacao`) REFERENCES `auth_aplicacoes` (`id_aplicacao`)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `auth_aplicacoes` (`codigo`, `nome`, `descricao`, `ativo`)
VALUES (
  'alidemar',
  'Conseg PJ',
  'Ferramenta de Gestao dos Consultores de Segmento',
  1
)
ON DUPLICATE KEY UPDATE
  `nome` = VALUES(`nome`),
  `descricao` = VALUES(`descricao`),
  `ativo` = VALUES(`ativo`);
