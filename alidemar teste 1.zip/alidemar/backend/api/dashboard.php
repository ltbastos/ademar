﻿<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/access_scope.php';
require_once __DIR__ . '/../lib/tratativas_support.php';

init_api();

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
        json_error('Metodo nao permitido.', 405);
    }

    $authUser = auth_require_user();
    $db = db_connect();
    gs_ensure_tratativas_support($db);
    ensure_relation_tables($db);
    $scope = app_scope_context($db, $authUser);
    $tiposTratativa = gs_fetch_tipo_tratativas_ativas($db);

    $requestedUsuarioIds = parse_int_refs($_GET['usuario_ids'] ?? null);
    if (count($requestedUsuarioIds) === 0) {
        $singleUsuario = to_int_or_null($_GET['usuario_id'] ?? null);
        if ($singleUsuario !== null && $singleUsuario > 0) {
            $requestedUsuarioIds = [$singleUsuario];
        }
    }
    $usuarioIds = app_scope_effective_user_ids($requestedUsuarioIds, $scope);
    $forceNoResults = app_scope_force_no_results($requestedUsuarioIds, $scope);

    $cargoIds = parse_int_refs($_GET['cargo_ids'] ?? null);
    if (count($cargoIds) === 0) {
        $singleCargo = to_int_or_null($_GET['cargo_id'] ?? null);
        if ($singleCargo !== null && $singleCargo > 0) {
            $cargoIds = [$singleCargo];
        }
    }
    $assuntoIds = parse_int_refs($_GET['assunto_ids'] ?? null);
    if (count($assuntoIds) === 0) {
        $singleAssunto = to_int_or_null($_GET['assunto_id'] ?? null);
        if ($singleAssunto !== null && $singleAssunto > 0) {
            $assuntoIds = [$singleAssunto];
        }
    }
    $tipoIdsFiltro = parse_tipo_tratativa_ids_request($db, $tiposTratativa, $_GET);
    $granularidade = resolve_granularidade($_GET['granularidade'] ?? 'mes');
    $periodo = resolve_periodo($_GET);

    $tipoIds = tipo_ids_por_filtro($tiposTratativa, $tipoIdsFiltro);
    $filtro = build_filtro_tratativas($db, 't', $periodo, $usuarioIds, $tipoIds, $cargoIds, $assuntoIds, $forceNoResults);

    $kpis = fetch_kpis($db, $filtro, $tiposTratativa);
    $timeline = fetch_timeline_por_tipo($db, $filtro, $granularidade, $tiposTratativa, 'quantidade');
    $alcanceTimeline = fetch_timeline_por_tipo($db, $filtro, $granularidade, $tiposTratativa, 'alcance');

    $tratativasPorTipo = fetch_tratativas_por_tipo($db, $filtro, $tiposTratativa);
    $tratativasPorAssunto = fetch_tratativas_por_assunto($db, $filtro, $tiposTratativa);
    $tratativasPorCargo = fetch_tratativas_por_cargo($db, $filtro, $tiposTratativa);

    $mesesDisponiveis = fetch_meses_disponiveis($db, $usuarioIds, $tipoIds, $cargoIds, $assuntoIds, $forceNoResults);

    json_response([
        'periodo' => $periodo,
        'usuario_id' => count($usuarioIds) === 1 ? $usuarioIds[0] : null,
        'usuario_ids' => $usuarioIds,
        'cargo_ids' => $cargoIds,
        'assunto_ids' => $assuntoIds,
        'tipo_tratativa_id' => count($tipoIdsFiltro) === 1 ? $tipoIdsFiltro[0] : null,
        'tipo_tratativa_ids' => $tipoIdsFiltro,
        'tipos_tratativa' => $tiposTratativa,
        'granularidade' => $granularidade,
        'meses_disponiveis' => $mesesDisponiveis,
        'kpis' => $kpis,
        'timeline_por_tipo' => $timeline,
        'alcance_timeline_por_tipo' => $alcanceTimeline,
        'visitas_timeline' => $timeline[2] ?? [],
        'teams_timeline' => $timeline[1] ?? [],
        'ligacoes_timeline' => $timeline[3] ?? [],
        'tratativas_por_tipo' => $tratativasPorTipo,
        'tratativas_por_assunto' => $tratativasPorAssunto,
        'tratativas_por_cargo' => $tratativasPorCargo,
    ]);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}

function resolve_granularidade(string $input): string
{
    $value = strtolower(trim($input));
    return $value === 'dia' ? 'dia' : 'mes';
}

function parse_tipo_tratativa_ids_request(mysqli $db, array $tiposTratativa, array $source): array
{
    $tipoIds = parse_int_refs($source['tipo_tratativa_ids'] ?? null);
    if (count($tipoIds) === 0) {
        $singleTipoId = gs_resolve_tipo_tratativa_filter($db, $source['tipo_tratativa_id'] ?? ($source['tipo_tratativa'] ?? 'all'));
        if ($singleTipoId !== null && $singleTipoId > 0) {
            $tipoIds = [$singleTipoId];
        }
    }

    if (count($tipoIds) === 0) {
        return [];
    }

    $validIds = [];
    foreach ($tiposTratativa as $row) {
        $id = (int) ($row['id'] ?? 0);
        if ($id > 0) {
            $validIds[$id] = true;
        }
    }

    return array_values(
        array_filter(
            $tipoIds,
            static function (int $id) use ($validIds): bool {
                return isset($validIds[$id]);
            }
        )
    );
}

function tipo_ids_por_filtro(array $tiposTratativa, array $tipoIdsFiltro): array
{
    if (count($tipoIdsFiltro) > 0) {
        return $tipoIdsFiltro;
    }

    return array_values(
        array_filter(
            array_map(
                static function (array $row): int {
                    return (int) ($row['id'] ?? 0);
                },
                $tiposTratativa
            ),
            static function (int $id): bool {
                return $id > 0;
            }
        )
    );
}

function resolve_periodo(array $source): array
{
    $meses = parse_month_refs($source['meses'] ?? null);
    if (count($meses) === 0) {
        $meses = [date('Y-m')];
    }

    sort($meses);

    $inicio = $meses[0] . '-01';
    $ultimoMes = $meses[count($meses) - 1];
    $fim = $ultimoMes . '-31';
    $dateObj = DateTime::createFromFormat('Y-m-d', $ultimoMes . '-01');
    if ($dateObj instanceof DateTime) {
        $dateObj->modify('last day of this month');
        $fim = $dateObj->format('Y-m-d');
    }

    return [
        'modo' => 'meses',
        'meses' => $meses,
        'data_inicio' => $inicio,
        'data_fim' => $fim,
    ];
}

function parse_month_refs($raw): array
{
    $text = to_string_or_null($raw);
    if ($text === null) {
        return [];
    }

    $parts = preg_split('/\s*,\s*/', $text) ?: [];
    $valid = [];

    foreach ($parts as $part) {
        if (preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $part) === 1) {
            $valid[$part] = true;
        }
    }

    return array_keys($valid);
}

function parse_int_refs($raw): array
{
    $text = to_string_or_null($raw);
    if ($text === null) {
        return [];
    }

    $parts = preg_split('/\s*,\s*/', $text) ?: [];
    $valid = [];
    foreach ($parts as $part) {
        if (preg_match('/^\d+$/', $part) !== 1) {
            continue;
        }
        $intVal = (int) $part;
        if ($intVal > 0) {
            $valid[$intVal] = true;
        }
    }
    return array_keys($valid);
}

function build_filtro_tratativas(
    mysqli $db,
    string $alias,
    array $periodo,
    array $usuarioIds,
    array $tipoIds,
    array $cargoIds,
    array $assuntoIds,
    bool $forceNoResults = false
): array
{
    $clauses = ['1=1'];
    $types = '';
    $params = [];

    if ($forceNoResults) {
        $clauses[] = '0=1';
    }

    if ($periodo['modo'] === 'meses' && count($periodo['meses']) > 0) {
        $placeholders = implode(', ', array_fill(0, count($periodo['meses']), '?'));
        $clauses[] = 'DATE_FORMAT(' . $alias . '.`data`, "%Y-%m") IN (' . $placeholders . ')';
        $types .= str_repeat('s', count($periodo['meses']));
        $params = array_merge($params, $periodo['meses']);
    }

    if (count($usuarioIds) > 0) {
        $placeholders = implode(', ', array_fill(0, count($usuarioIds), '?'));
        $clauses[] = $alias . '.id_usuario IN (' . $placeholders . ')';
        $types .= str_repeat('i', count($usuarioIds));
        $params = array_merge($params, $usuarioIds);
    }

    if (count($tipoIds) > 0) {
        $placeholders = implode(', ', array_fill(0, count($tipoIds), '?'));
        $clauses[] = $alias . '.id_tratativa IN (' . $placeholders . ')';
        $types .= str_repeat('i', count($tipoIds));
        $params = array_merge($params, $tipoIds);
    }

    if (count($cargoIds) > 0) {
        if (has_tratativas_cargos_table($db)) {
            $placeholders = implode(', ', array_fill(0, count($cargoIds), '?'));
            $clauses[] = 'EXISTS (
                SELECT 1
                FROM fTratativasCargos tc
                WHERE tc.id_tratativa = ' . $alias . '.id
                  AND tc.id_cargo IN (' . $placeholders . ')
            )';
        } else {
            $placeholders = implode(', ', array_fill(0, count($cargoIds), '?'));
            $clauses[] = $alias . '.id_cargo IN (' . $placeholders . ')';
        }
        $types .= str_repeat('i', count($cargoIds));
        $params = array_merge($params, $cargoIds);
    }

    if (count($assuntoIds) > 0) {
        if (has_tratativas_assuntos_table($db)) {
            $placeholders = implode(', ', array_fill(0, count($assuntoIds), '?'));
            $clauses[] = 'EXISTS (
                SELECT 1
                FROM fTratativasAssuntos ta
                WHERE ta.id_tratativa = ' . $alias . '.id
                  AND ta.id_assunto IN (' . $placeholders . ')
            )';
        } else {
            $placeholders = implode(', ', array_fill(0, count($assuntoIds), '?'));
            $clauses[] = $alias . '.id_assunto IN (' . $placeholders . ')';
        }
        $types .= str_repeat('i', count($assuntoIds));
        $params = array_merge($params, $assuntoIds);
    }

    return [
        'where_sql' => implode(' AND ', $clauses),
        'types' => $types,
        'params' => $params,
    ];
}

function fetch_kpis(mysqli $db, array $filtro, array $tiposTratativa): array
{
    $rows = db_query_all(
        $db,
        'SELECT t.id_tratativa, COUNT(*) AS total
         FROM fTratativas t
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY t.id_tratativa',
        $filtro['types'],
        $filtro['params']
    );

    $counts = build_tipo_counts_template($tiposTratativa);
    foreach ($rows as $row) {
        $idTratativa = (int) ($row['id_tratativa'] ?? 0);
        if (!isset($counts[$idTratativa])) {
            continue;
        }
        $counts[$idTratativa] = (int) ($row['total'] ?? 0);
    }

    $alcanceRow = db_query_one(
        $db,
        'SELECT COALESCE(SUM(' . gs_alcance_total_sql($db, 't') . '), 0) AS total
         FROM fTratativas t
         WHERE ' . $filtro['where_sql'],
        $filtro['types'],
        $filtro['params']
    );
    $totalTratativas = array_sum($counts);

    return [
        'total_tratativas' => $totalTratativas,
        'total_teams' => $counts[1] ?? 0,
        'total_visitas' => $counts[2] ?? 0,
        'total_ligacoes' => $counts[3] ?? 0,
        'total_live' => $counts[4] ?? 0,
        'total_evento' => $counts[5] ?? 0,
        'total_alcance' => (int) ($alcanceRow['total'] ?? 0),
        'totais_por_tipo' => $counts,
    ];
}

function fetch_timeline_por_tipo(mysqli $db, array $filtro, string $granularidade, array $tiposTratativa, string $metrica = 'quantidade'): array
{
    $dateExpr = $granularidade === 'dia'
        ? 'DATE_FORMAT(t.`data`, "%Y-%m-%d")'
        : 'DATE_FORMAT(t.`data`, "%Y-%m-01")';
    $valueExpr = $metrica === 'alcance'
        ? 'SUM(' . gs_alcance_total_sql($db, 't') . ')'
        : 'COUNT(*)';

    $rows = db_query_all(
        $db,
        'SELECT
            ' . $dateExpr . ' AS data_ref,
            t.id_tratativa,
            ' . $valueExpr . ' AS quantidade
         FROM fTratativas t
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY ' . $dateExpr . ', t.id_tratativa
         ORDER BY data_ref ASC',
        $filtro['types'],
        $filtro['params']
    );

    $timeline = [];
    foreach ($tiposTratativa as $tipoRow) {
        $id = (int) ($tipoRow['id'] ?? 0);
        if ($id > 0) {
            $timeline[$id] = [];
        }
    }

    foreach ($rows as $row) {
        $idTratativa = (int) ($row['id_tratativa'] ?? 0);
        if (!isset($timeline[$idTratativa])) {
            continue;
        }

        $timeline[$idTratativa][] = [
            'data' => $row['data_ref'],
            'quantidade' => (int) ($row['quantidade'] ?? 0),
        ];
    }

    return $timeline;
}

function fetch_tratativas_por_tipo(mysqli $db, array $filtro, array $tiposTratativa): array
{
    $rows = db_query_all(
        $db,
        'SELECT t.id_tratativa, COUNT(*) AS total
         FROM fTratativas t
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY t.id_tratativa',
        $filtro['types'],
        $filtro['params']
    );

    $counts = build_tipo_counts_template($tiposTratativa);
    foreach ($rows as $row) {
        $idTratativa = (int) ($row['id_tratativa'] ?? 0);
        if (isset($counts[$idTratativa])) {
            $counts[$idTratativa] = (int) ($row['total'] ?? 0);
        }
    }

    $out = [];
    foreach ($tiposTratativa as $tipoRow) {
        $id = (int) ($tipoRow['id'] ?? 0);
        if ($id <= 0) {
            continue;
        }
        $out[] = [
            'id_tratativa' => $id,
            'tipo_tratativa' => $tipoRow['nome'] ?? ('Tipo ' . $id),
            'total' => $counts[$id] ?? 0,
        ];
    }

    return $out;
}

function fetch_tratativas_por_assunto(mysqli $db, array $filtro, array $tiposTratativa): array
{
    $useBridge = has_tratativas_assuntos_table($db);
    if ($useBridge) {
        $sql = 'SELECT
            COALESCE(a.assunto, "Sem assunto") AS assunto,
            t.id_tratativa,
            COUNT(*) AS total
         FROM fTratativas t
         LEFT JOIN fTratativasAssuntos ta ON ta.id_tratativa = t.id
         LEFT JOIN dAssuntos a ON a.id_assunto = ta.id_assunto
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY COALESCE(a.assunto, "Sem assunto"), t.id_tratativa
         ORDER BY assunto ASC, t.id_tratativa ASC';
    } else {
        $sql = 'SELECT
            COALESCE(a.assunto, "Sem assunto") AS assunto,
            t.id_tratativa,
            COUNT(*) AS total
         FROM fTratativas t
         LEFT JOIN dAssuntos a ON a.id_assunto = t.id_assunto
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY COALESCE(a.assunto, "Sem assunto"), t.id_tratativa
         ORDER BY assunto ASC, t.id_tratativa ASC';
    }

    $rows = db_query_all($db, $sql, $filtro['types'], $filtro['params']);

    return pivot_totais_por_tipo($rows, $tiposTratativa, 'assunto');
}

function fetch_tratativas_por_cargo(mysqli $db, array $filtro, array $tiposTratativa): array
{
    $useBridge = has_tratativas_cargos_table($db);
    if ($useBridge) {
        $sql = 'SELECT
            COALESCE(c.cargo, "Não informado") AS cargo,
            t.id_tratativa,
            COUNT(*) AS total
         FROM fTratativas t
         LEFT JOIN fTratativasCargos tc ON tc.id_tratativa = t.id
         LEFT JOIN dCargos c ON c.id_cargo = tc.id_cargo
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY COALESCE(c.cargo, "Não informado"), t.id_tratativa
         ORDER BY cargo ASC, t.id_tratativa ASC';
    } else {
        $sql = 'SELECT
            COALESCE(c.cargo, "Não informado") AS cargo,
            t.id_tratativa,
            COUNT(*) AS total
         FROM fTratativas t
         LEFT JOIN dCargos c ON c.id_cargo = t.id_cargo
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY COALESCE(c.cargo, "Não informado"), t.id_tratativa
         ORDER BY cargo ASC, t.id_tratativa ASC';
    }

    $rows = db_query_all($db, $sql, $filtro['types'], $filtro['params']);

    return pivot_totais_por_tipo($rows, $tiposTratativa, 'cargo');
}

function pivot_totais_por_tipo(array $rows, array $tiposTratativa, string $labelKey): array
{
    $countsTemplate = build_tipo_counts_template($tiposTratativa);
    $grouped = [];

    foreach ($rows as $row) {
        $label = to_string_or_null($row[$labelKey] ?? null);
        if ($label === null) {
            $label = $labelKey === 'cargo' ? 'Não informado' : 'Sem assunto';
        }

        if (!isset($grouped[$label])) {
            $grouped[$label] = [
                $labelKey => $label,
                'totais_por_tipo' => $countsTemplate,
                'total' => 0,
            ];
        }

        $idTratativa = (int) ($row['id_tratativa'] ?? 0);
        if (!isset($grouped[$label]['totais_por_tipo'][$idTratativa])) {
            continue;
        }

        $grouped[$label]['totais_por_tipo'][$idTratativa] = (int) ($row['total'] ?? 0);
    }

    foreach ($grouped as &$row) {
        $row['total'] = array_sum($row['totais_por_tipo']);
        $row['total_teams'] = $row['totais_por_tipo'][1] ?? 0;
        $row['total_visitas'] = $row['totais_por_tipo'][2] ?? 0;
        $row['total_ligacoes'] = $row['totais_por_tipo'][3] ?? 0;
        $row['total_live'] = $row['totais_por_tipo'][4] ?? 0;
        $row['total_evento'] = $row['totais_por_tipo'][5] ?? 0;
    }
    unset($row);

    usort(
        $grouped,
        static function (array $left, array $right) use ($labelKey): int {
            $leftTotal = (int) ($left['total'] ?? 0);
            $rightTotal = (int) ($right['total'] ?? 0);
            if ($leftTotal !== $rightTotal) {
                return $rightTotal <=> $leftTotal;
            }

            return strcmp((string) ($left[$labelKey] ?? ''), (string) ($right[$labelKey] ?? ''));
        }
    );

    return array_slice($grouped, 0, 30);
}

function build_tipo_counts_template(array $tiposTratativa): array
{
    $counts = [];
    foreach ($tiposTratativa as $tipoRow) {
        $id = (int) ($tipoRow['id'] ?? 0);
        if ($id > 0) {
            $counts[$id] = 0;
        }
    }

    return $counts;
}

function fetch_meses_disponiveis(
    mysqli $db,
    array $usuarioIds,
    array $tipoIds,
    array $cargoIds,
    array $assuntoIds,
    bool $forceNoResults = false
): array
{
    if ($forceNoResults) {
        return [];
    }

    $where = ['1=1'];
    $types = '';
    $params = [];

    if (count($usuarioIds) > 0) {
        $placeholders = implode(', ', array_fill(0, count($usuarioIds), '?'));
        $where[] = 't.id_usuario IN (' . $placeholders . ')';
        $types .= str_repeat('i', count($usuarioIds));
        $params = array_merge($params, $usuarioIds);
    }

    if (count($tipoIds) > 0) {
        $placeholders = implode(', ', array_fill(0, count($tipoIds), '?'));
        $where[] = 't.id_tratativa IN (' . $placeholders . ')';
        $types .= str_repeat('i', count($tipoIds));
        $params = array_merge($params, $tipoIds);
    }

    if (count($cargoIds) > 0) {
        if (has_tratativas_cargos_table($db)) {
            $placeholders = implode(', ', array_fill(0, count($cargoIds), '?'));
            $where[] = 'EXISTS (
                SELECT 1
                FROM fTratativasCargos tc
                WHERE tc.id_tratativa = t.id
                  AND tc.id_cargo IN (' . $placeholders . ')
            )';
        } else {
            $placeholders = implode(', ', array_fill(0, count($cargoIds), '?'));
            $where[] = 't.id_cargo IN (' . $placeholders . ')';
        }
        $types .= str_repeat('i', count($cargoIds));
        $params = array_merge($params, $cargoIds);
    }

    if (count($assuntoIds) > 0) {
        if (has_tratativas_assuntos_table($db)) {
            $placeholders = implode(', ', array_fill(0, count($assuntoIds), '?'));
            $where[] = 'EXISTS (
                SELECT 1
                FROM fTratativasAssuntos ta
                WHERE ta.id_tratativa = t.id
                  AND ta.id_assunto IN (' . $placeholders . ')
            )';
        } else {
            $placeholders = implode(', ', array_fill(0, count($assuntoIds), '?'));
            $where[] = 't.id_assunto IN (' . $placeholders . ')';
        }
        $types .= str_repeat('i', count($assuntoIds));
        $params = array_merge($params, $assuntoIds);
    }

    $rows = db_query_all(
        $db,
        'SELECT DISTINCT DATE_FORMAT(t.`data`, "%Y-%m") AS mes_ref
         FROM fTratativas t
         WHERE ' . implode(' AND ', $where) . '
         ORDER BY mes_ref DESC',
        $types,
        $params
    );

    $out = [];
    foreach ($rows as $row) {
        $mesRef = to_string_or_null($row['mes_ref'] ?? null);
        if ($mesRef === null) {
            continue;
        }

        $out[] = [
            'mes_ref' => $mesRef,
            'label' => month_label_pt($mesRef),
        ];
    }

    if (count($out) === 0) {
        $currentMes = date('Y-m');
        $out[] = [
            'mes_ref' => $currentMes,
            'label' => month_label_pt($currentMes),
        ];
    }

    return $out;
}

function month_label_pt(string $mesRef): string
{
    $meses = [
        '01' => 'Jan',
        '02' => 'Fev',
        '03' => 'Mar',
        '04' => 'Abr',
        '05' => 'Mai',
        '06' => 'Jun',
        '07' => 'Jul',
        '08' => 'Ago',
        '09' => 'Set',
        '10' => 'Out',
        '11' => 'Nov',
        '12' => 'Dez',
    ];

    $year = substr($mesRef, 0, 4);
    $month = substr($mesRef, 5, 2);

    return ($meses[$month] ?? $month) . ' - ' . $year;
}

function ensure_relation_tables(mysqli $db): void
{
    db_execute(
        $db,
        'CREATE TABLE IF NOT EXISTS fTratativasCargos (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            id_tratativa BIGINT UNSIGNED NOT NULL,
            id_cargo INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uk_fTratativasCargos (id_tratativa, id_cargo),
            KEY idx_fTratativasCargos_cargo (id_cargo),
            CONSTRAINT fk_fTratativasCargos_tratativa FOREIGN KEY (id_tratativa) REFERENCES fTratativas(id) ON DELETE CASCADE,
            CONSTRAINT fk_fTratativasCargos_cargo FOREIGN KEY (id_cargo) REFERENCES dCargos(id_cargo) ON DELETE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );

    db_execute(
        $db,
        'CREATE TABLE IF NOT EXISTS fTratativasAssuntos (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            id_tratativa BIGINT UNSIGNED NOT NULL,
            id_assunto INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uk_fTratativasAssuntos (id_tratativa, id_assunto),
            KEY idx_fTratativasAssuntos_assunto (id_assunto),
            CONSTRAINT fk_fTratativasAssuntos_tratativa FOREIGN KEY (id_tratativa) REFERENCES fTratativas(id) ON DELETE CASCADE,
            CONSTRAINT fk_fTratativasAssuntos_assunto FOREIGN KEY (id_assunto) REFERENCES dAssuntos(id_assunto) ON DELETE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );

    db_execute(
        $db,
        'INSERT IGNORE INTO fTratativasCargos (id_tratativa, id_cargo)
         SELECT t.id, t.id_cargo
         FROM fTratativas t
         WHERE t.id_cargo IS NOT NULL'
    );

    db_execute(
        $db,
        'INSERT IGNORE INTO fTratativasAssuntos (id_tratativa, id_assunto)
         SELECT t.id, t.id_assunto
         FROM fTratativas t
         WHERE t.id_assunto IS NOT NULL'
    );
}

function has_table(mysqli $db, string $tableName): bool
{
    $row = db_query_one(
        $db,
        'SELECT 1 AS existe
         FROM INFORMATION_SCHEMA.TABLES
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
         LIMIT 1',
        's',
        [$tableName]
    );
    return $row !== null;
}

function has_tratativas_cargos_table(mysqli $db): bool
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $cached = has_table($db, 'fTratativasCargos');
    return $cached;
}

function has_tratativas_assuntos_table(mysqli $db): bool
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $cached = has_table($db, 'fTratativasAssuntos');
    return $cached;
}
