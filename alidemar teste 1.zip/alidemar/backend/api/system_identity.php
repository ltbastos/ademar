<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/system_identity.php';

init_api();

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
        json_error('Metodo nao permitido.', 405);
    }

    auth_require_user();
    json_response([
        'identidade' => system_identity_snapshot(),
    ]);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}
