<?php

function init_api(): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function json_response(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if ($json === false) {
        $normalized = json_normalize_value($payload);
        $json = json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    if ($json === false) {
        http_response_code(500);
        $json = '{"erro":"Falha ao serializar a resposta JSON."}';
    }

    echo $json;
    exit;
}

function json_error(string $message, int $statusCode = 400, array $extra = []): void
{
    json_response(array_merge(['erro' => $message], $extra), $statusCode);
}

function json_input(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        json_error('JSON invalido no corpo da requisicao.', 400);
    }

    return $decoded;
}

function to_int_or_null($value): ?int
{
    if ($value === null || $value === '' || $value === false) {
        return null;
    }

    if (!is_numeric($value)) {
        return null;
    }

    return (int) $value;
}

function to_string_or_null($value): ?string
{
    if ($value === null) {
        return null;
    }

    $text = trim((string) $value);
    return $text === '' ? null : $text;
}

function parse_datetime_or_null($value): ?string
{
    $text = to_string_or_null($value);
    if ($text === null) {
        return null;
    }

    $timestamp = strtotime($text);
    if ($timestamp === false) {
        json_error('Data/hora invalida: ' . $text, 422);
    }

    return date('Y-m-d H:i:s', $timestamp);
}

function require_fields(array $payload, array $required): void
{
    foreach ($required as $field) {
        if (!array_key_exists($field, $payload)) {
            json_error('Campo obrigatorio ausente: ' . $field, 422);
        }

        if (is_string($payload[$field]) && trim($payload[$field]) === '') {
            json_error('Campo obrigatorio vazio: ' . $field, 422);
        }

        if ($payload[$field] === null) {
            json_error('Campo obrigatorio nulo: ' . $field, 422);
        }
    }
}

function json_normalize_value($value)
{
    if (is_array($value)) {
        $normalized = [];
        foreach ($value as $key => $item) {
            $normalized[$key] = json_normalize_value($item);
        }
        return $normalized;
    }

    if (is_string($value)) {
        return json_normalize_string($value);
    }

    return $value;
}

function json_normalize_string(string $value): string
{
    if ($value === '' || preg_match('//u', $value) === 1) {
        return $value;
    }

    foreach (['UTF-8', 'UTF-16LE', 'UTF-16BE', 'Windows-1252', 'CP1252', 'ISO-8859-1', 'CP850', 'IBM850', 'CP437'] as $encoding) {
        $converted = @iconv($encoding, 'UTF-8//IGNORE', $value);
        if ($converted !== false && $converted !== '' && preg_match('//u', $converted) === 1) {
            return trim($converted);
        }
    }

    $sanitized = @iconv('UTF-8', 'UTF-8//IGNORE', $value);
    if ($sanitized !== false && $sanitized !== '' && preg_match('//u', $sanitized) === 1) {
        return trim($sanitized);
    }

    return '';
}
