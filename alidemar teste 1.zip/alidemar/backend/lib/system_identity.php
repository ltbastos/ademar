<?php

require_once __DIR__ . '/http.php';

function system_identity_snapshot(): array
{
    $env = system_identity_env();
    $computer = system_identity_computer();
    $groups = system_identity_groups();
    $whoami = system_identity_exec('whoami');
    $upn = system_identity_exec('whoami /upn');
    $fqdn = system_identity_exec('whoami /fqdn');

    $isDomain = (bool) ($computer['part_of_domain'] ?? false);
    $domain = to_string_or_null($computer['domain'] ?? null) ?? ($env['userdomain'] ?? null);
    $machine = to_string_or_null($computer['name'] ?? null) ?? ($env['computername'] ?? null);
    $networkUser = to_string_or_null($computer['username'] ?? null) ?? $whoami;

    return [
        'fonte' => 'windows_server_context',
        'observacao' => $isDomain
            ? 'Dados coletados do contexto Windows atual do servidor/PHP. Sem autenticacao integrada, isso pode nao representar o usuario real do navegador.'
            : 'Sem dominio detectado neste ambiente. Os dados abaixo refletem o contexto Windows atual do servidor/PHP, nao necessariamente o usuario real do navegador.',
        'windows' => [
            'whoami' => $whoami,
            'usuario_rede' => $networkUser,
            'usuario_windows' => $env['username'] ?? null,
            'dominio' => $domain,
            'computador' => $machine,
            'logonserver' => $env['logonserver'] ?? null,
            'upn' => system_identity_is_error($upn) ? null : $upn,
            'fqdn' => system_identity_is_error($fqdn) ? null : $fqdn,
            'part_of_domain' => $isDomain,
            'grupos' => $groups,
        ],
        'ambiente' => [
            'php_sapi' => PHP_SAPI,
            'server_software' => to_string_or_null($_SERVER['SERVER_SOFTWARE'] ?? null),
            'remote_addr' => to_string_or_null($_SERVER['REMOTE_ADDR'] ?? null),
        ],
    ];
}

function system_identity_env(): array
{
    $map = [];
    foreach (['USERNAME', 'USERDOMAIN', 'COMPUTERNAME', 'LOGONSERVER', 'USERPROFILE'] as $key) {
        $value = getenv($key);
        $map[strtolower($key)] = $value !== false ? trim((string) $value) : null;
    }

    return $map;
}

function system_identity_groups(): array
{
    $output = system_identity_exec('whoami /groups /fo csv /nh');
    if ($output === null || system_identity_is_error($output)) {
        return [];
    }

    $rows = preg_split('/\r\n|\r|\n/', $output) ?: [];
    $groups = [];

    foreach ($rows as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }

        $cols = str_getcsv($line);
        if (!is_array($cols) || count($cols) < 1) {
            continue;
        }

        $name = trim((string) ($cols[0] ?? ''));
        if ($name === '') {
            continue;
        }

        $groups[] = [
            'nome' => $name,
            'tipo' => trim((string) ($cols[1] ?? '')),
            'sid' => trim((string) ($cols[2] ?? '')),
            'atributos' => trim((string) ($cols[3] ?? '')),
        ];
    }

    return $groups;
}

function system_identity_computer(): array
{
    $script = '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;'
        . '$cs=Get-CimInstance Win32_ComputerSystem;'
        . '[pscustomobject]@{'
        . 'name=$cs.Name;'
        . 'domain=$cs.Domain;'
        . 'part_of_domain=$cs.PartOfDomain;'
        . 'username=$cs.UserName'
        . '} | ConvertTo-Json -Compress';

    $output = system_identity_exec_powershell($script);
    if ($output === null || system_identity_is_error($output)) {
        return [];
    }

    $decoded = json_decode($output, true);
    return is_array($decoded) ? $decoded : [];
}

function system_identity_exec_powershell(string $script): ?string
{
    $boot = '[Console]::InputEncoding=[System.Text.Encoding]::UTF8;'
        . '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;'
        . '$OutputEncoding=[System.Text.Encoding]::UTF8;';
    $command = 'powershell -NoProfile -ExecutionPolicy Bypass -Command ' . escapeshellarg($boot . $script);
    return system_identity_exec($command);
}

function system_identity_exec(string $command): ?string
{
    if (!function_exists('shell_exec')) {
        return null;
    }

    $output = @shell_exec($command . ' 2>&1');
    if ($output === null) {
        return null;
    }

    $text = trim(system_identity_normalize_text((string) $output));
    return $text === '' ? null : $text;
}

function system_identity_is_error(?string $output): bool
{
    if ($output === null) {
        return true;
    }

    $normalized = strtolower($output);
    return strpos($normalized, 'erro:') !== false
        || strpos($normalized, 'error:') !== false
        || strpos($normalized, 'não é possível') !== false
        || strpos($normalized, 'nao e possivel') !== false;
}

function system_identity_normalize_text(string $text): string
{
    if ($text === '') {
        return '';
    }

    if (strpos($text, "\xFF\xFE") === 0 || strpos($text, "\xFE\xFF") === 0) {
        $encoding = strpos($text, "\xFF\xFE") === 0 ? 'UTF-16LE' : 'UTF-16BE';
        $converted = @iconv($encoding, 'UTF-8//IGNORE', $text);
        if ($converted !== false && $converted !== '') {
            return $converted;
        }
    }

    if (preg_match('//u', $text) === 1) {
        return $text;
    }

    foreach (['CP850', 'IBM850', 'CP437', 'Windows-1252', 'CP1252', 'ISO-8859-1'] as $encoding) {
        $converted = @iconv($encoding, 'UTF-8//IGNORE', $text);
        if ($converted !== false && $converted !== '' && preg_match('//u', $converted) === 1) {
            return $converted;
        }
    }

    $sanitized = @iconv('UTF-8', 'UTF-8//IGNORE', $text);
    return $sanitized !== false ? $sanitized : $text;
}
