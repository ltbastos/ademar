# Backend - GestaoSegmento

Stack: PHP (`mysqli`) + MySQL/MariaDB (XAMPP)

## Banco de dados

Execute nesta ordem:

1. `sql/06_schema_gestao_segmento.sql`
2. `sql/07_seed_gestaosegmento_fake.sql` (opcional, dados ficticios)

Banco: `GestaoSegmento`

## Configuracao

Arquivo: `backend/config/database.php`

Padrao:
- host: `localhost`
- porta: `3306`
- database: `GestaoSegmento`
- user: `root`
- password: vazia

## Endpoints

- `GET /backend/api/dimensoes.php?tipo=all`
  - retorna: usuarios, tipos de tratativa, assuntos e cargos.

- `GET /backend/api/dashboard.php`
  - filtros: `usuario_id`, `tipo_tratativa` (`all|teams|visitas|ligacao`), `meses` (`YYYY-MM,YYYY-MM`).
  - retorno: KPIs, evolucao temporal, tratativas por assunto, tratativas por cargo.

- `GET /backend/api/tratativas.php`
  - lista tratativas (fato) com filtros.

- `GET /backend/api/tratativas.php?id=123`
  - detalhe da tratativa.

- `POST /backend/api/tratativas.php`
  - cria tratativa.

- `PUT /backend/api/tratativas.php`
  - atualiza tratativa.

- `DELETE /backend/api/tratativas.php`
  - exclui tratativa por `id`.

## Estrutura principal da fato

Tabela: `fTratativas`

Campos:
- `id`
- `data`
- `id_tratativa`
- `id_usuario`
- `id_cargo`
- `id_assunto`
- `agencia`
- `descricao`
- `contatos`
