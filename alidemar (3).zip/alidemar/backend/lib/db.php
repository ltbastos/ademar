<?php

function db_connect(): mysqli
{
    static $connection = null;

    if ($connection instanceof mysqli) {
        return $connection;
    }

    $config = require __DIR__ . '/../config/database.php';

    $connection = new mysqli(
        $config['host'],
        $config['user'],
        $config['password'],
        $config['database'],
        (int) $config['port']
    );

    if ($connection->connect_errno) {
        throw new RuntimeException('Falha de conexao com o banco: ' . $connection->connect_error);
    }

    if (!$connection->set_charset($config['charset'])) {
        throw new RuntimeException('Falha ao definir charset: ' . $connection->error);
    }

    return $connection;
}

function db_query_all(mysqli $db, string $sql, string $types = '', array $params = []): array
{
    $stmt = $db->prepare($sql);
    if (!$stmt) {
        throw new RuntimeException('Erro ao preparar consulta: ' . $db->error);
    }

    if ($types !== '') {
        if (!$stmt->bind_param($types, ...$params)) {
            throw new RuntimeException('Erro ao associar parametros: ' . $stmt->error);
        }
    }

    if (!$stmt->execute()) {
        throw new RuntimeException('Erro ao executar consulta: ' . $stmt->error);
    }

    $result = $stmt->get_result();
    $rows = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

    $stmt->close();
    return $rows;
}

function db_query_one(mysqli $db, string $sql, string $types = '', array $params = []): ?array
{
    $rows = db_query_all($db, $sql, $types, $params);
    return $rows[0] ?? null;
}

function db_execute(mysqli $db, string $sql, string $types = '', array $params = []): array
{
    $stmt = $db->prepare($sql);
    if (!$stmt) {
        throw new RuntimeException('Erro ao preparar operacao: ' . $db->error);
    }

    if ($types !== '') {
        if (!$stmt->bind_param($types, ...$params)) {
            throw new RuntimeException('Erro ao associar parametros: ' . $stmt->error);
        }
    }

    if (!$stmt->execute()) {
        throw new RuntimeException('Erro ao executar operacao: ' . $stmt->error);
    }

    $result = [
        'affected_rows' => $stmt->affected_rows,
        'insert_id' => $stmt->insert_id,
    ];

    $stmt->close();
    return $result;
}
