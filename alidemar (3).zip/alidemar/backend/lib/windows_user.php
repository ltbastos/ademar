<?php

function detect_windows_identity(): array
{
    $candidates = [];
    $email = null;
    $usuario = null;
    $fonte = 'indisponivel';
    $detalhe = null;

    $upnEnv = to_string_or_null(getenv('USERDNSDOMAIN'));
    $usernameEnv = to_string_or_null(getenv('USERNAME'));

    if ($usernameEnv !== null) {
        $usuario = $usernameEnv;
        $fonte = 'USERNAME';
        windows_identity_add_candidate($candidates, windows_identity_candidate($usernameEnv));
    }

    if ($usernameEnv !== null && $upnEnv !== null) {
        $emailCandidate = strtolower($usernameEnv . '@' . $upnEnv);
        if (windows_identity_is_email($emailCandidate)) {
            $email = $emailCandidate;
            $fonte = 'USERDNSDOMAIN';
            windows_identity_add_candidate($candidates, windows_identity_candidate($emailCandidate));
        }
    }

    $remoteUser = to_string_or_null($_SERVER['REMOTE_USER'] ?? null);
    if ($remoteUser !== null) {
        windows_identity_add_candidate($candidates, windows_identity_candidate($remoteUser));
        if (windows_identity_is_email($remoteUser)) {
            $email = strtolower($remoteUser);
            $fonte = 'REMOTE_USER';
        }
    }

    if ($usuario === null || count($candidates) === 0) {
        $whoami = windows_identity_read_command('cmd /c whoami');
        if ($whoami !== null) {
            if ($usuario === null) {
                $usuario = $whoami;
            }
            if ($fonte === 'indisponivel') {
                $fonte = 'whoami';
            }
            windows_identity_add_candidate($candidates, windows_identity_candidate($whoami));
        }

        $whoamiUpn = windows_identity_read_command('cmd /c whoami /upn');
        if ($whoamiUpn !== null) {
            if ($email === null && windows_identity_is_email($whoamiUpn)) {
                $email = strtolower($whoamiUpn);
                $fonte = 'whoami_upn';
            }
            windows_identity_add_candidate($candidates, windows_identity_candidate($whoamiUpn));
        }
    }

    if ($email !== null) {
        windows_identity_add_candidate($candidates, windows_identity_candidate($email));
    }

    $funcional = windows_identity_pick_funcional($candidates);

    if ($funcional === null) {
        $detalhe = 'Nao foi possivel extrair FuncionalLetra do usuario do Windows.';
    }

    return [
        'email' => $email,
        'usuario' => $usuario,
        'funcional' => $funcional,
        'fonte' => $fonte,
        'detalhe' => $detalhe,
        'candidatos' => $candidates,
    ];
}

function windows_identity_read_command(string $command): ?string
{
    if (!windows_identity_can_run_shell()) {
        return null;
    }

    $output = @shell_exec($command . ' 2>NUL');
    return windows_identity_normalize_output($output);
}

function windows_identity_normalize_output(?string $value): ?string
{
    if ($value === null) {
        return null;
    }

    $text = trim(str_replace(["\r", "\n"], ' ', $value));
    if ($text === '' || stripos($text, 'ERROR:') === 0) {
        return null;
    }

    return $text;
}

function windows_identity_can_run_shell(): bool
{
    if (!function_exists('shell_exec')) {
        return false;
    }

    $disabled = to_string_or_null((string) ini_get('disable_functions'));
    if ($disabled === null) {
        return true;
    }

    $list = array_map('trim', explode(',', $disabled));
    return !in_array('shell_exec', $list, true);
}

function windows_identity_is_email(string $text): bool
{
    return filter_var($text, FILTER_VALIDATE_EMAIL) !== false;
}

function windows_identity_candidate(?string $raw): ?string
{
    if ($raw === null) {
        return null;
    }

    $value = trim((string) $raw);
    if ($value === '') {
        return null;
    }

    if (strpos($value, '\\') !== false) {
        $parts = explode('\\', $value);
        $value = (string) end($parts);
    }

    if (strpos($value, '/') !== false) {
        $parts = explode('/', $value);
        $value = (string) end($parts);
    }

    if (strpos($value, '@') !== false) {
        $parts = explode('@', $value, 2);
        $value = $parts[0];
    }

    $value = strtoupper(trim($value));
    $value = preg_replace('/\s+/', '', $value) ?? '';

    return $value !== '' ? $value : null;
}

function windows_identity_add_candidate(array &$candidates, ?string $candidate): void
{
    if ($candidate === null) {
        return;
    }

    if (!in_array($candidate, $candidates, true)) {
        $candidates[] = $candidate;
    }
}

function windows_identity_pick_funcional(array $candidates): ?string
{
    foreach ($candidates as $candidate) {
        if (preg_match('/^[A-Z]\d{4,}$/', $candidate) === 1) {
            return $candidate;
        }
    }

    return $candidates[0] ?? null;
}
