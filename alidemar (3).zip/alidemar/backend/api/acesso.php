﻿<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/windows_user.php';

init_api();

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
        json_error('Metodo nao permitido.', 405);
    }

    $identity = detect_windows_identity();
    $funcionalLogin = to_string_or_null($identity['funcional']);

    $autorizado = false;
    $mensagem = 'Acesso negado para este usuario.';
    $registro = null;

    if ($funcionalLogin === null) {
        $mensagem = 'Nao foi possivel identificar o FuncionalLetra do usuario logado no Windows.';
    } else {
        $db = db_connect();
        $registro = db_query_one(
            $db,
            'SELECT id, FuncionalLetra, Email, Nome, Funcao, Nivel, Cargo, Departamento, Area
             FROM estrutura.mesu
             WHERE UPPER(TRIM(FuncionalLetra)) = ?
             LIMIT 1',
            's',
            [strtoupper($funcionalLogin)]
        );

        if ($registro !== null) {
            $autorizado = true;
            $mensagem = 'Acesso autorizado.';
        } else {
            $mensagem = 'Funcional nao encontrado na tabela estrutura.mesu.';
        }
    }

    json_response([
        'autorizado' => $autorizado,
        'mensagem' => $mensagem,
        'funcional_login' => $funcionalLogin,
        'identidade' => [
            'email' => $identity['email'],
            'usuario' => $identity['usuario'],
            'funcional' => $identity['funcional'],
            'fonte' => $identity['fonte'],
            'detalhe' => $identity['detalhe'],
        ],
        'registro' => $registro,
    ]);
} catch (Throwable $e) {
    json_error('Erro ao validar acesso na estrutura.', 500, ['detalhe' => $e->getMessage()]);
}
