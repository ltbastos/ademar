﻿<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/db.php';

init_api();

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
        json_error('Metodo nao permitido.', 405);
    }

    $db = db_connect();
    ensure_relation_tables($db);

    $usuarioId = to_int_or_null($_GET['usuario_id'] ?? null);
    $cargoIds = parse_int_refs($_GET['cargo_ids'] ?? null);
    if (count($cargoIds) === 0) {
        $singleCargo = to_int_or_null($_GET['cargo_id'] ?? null);
        if ($singleCargo !== null && $singleCargo > 0) {
            $cargoIds = [$singleCargo];
        }
    }
    $assuntoIds = parse_int_refs($_GET['assunto_ids'] ?? null);
    if (count($assuntoIds) === 0) {
        $singleAssunto = to_int_or_null($_GET['assunto_id'] ?? null);
        if ($singleAssunto !== null && $singleAssunto > 0) {
            $assuntoIds = [$singleAssunto];
        }
    }
    $tipoTratativa = resolve_tipo_tratativa($_GET['tipo_tratativa'] ?? 'all');
    $granularidade = resolve_granularidade($_GET['granularidade'] ?? 'mes');
    $periodo = resolve_periodo($_GET);

    $tipoIds = tipo_ids_por_filtro($tipoTratativa);
    $filtro = build_filtro_tratativas($db, 't', $periodo, $usuarioId, $tipoIds, $cargoIds, $assuntoIds);

    $kpis = fetch_kpis($db, $filtro);
    $timeline = fetch_timeline_por_tipo($db, $filtro, $granularidade);

    $tratativasPorTipo = fetch_tratativas_por_tipo($db, $filtro);
    $tratativasPorAssunto = fetch_tratativas_por_assunto($db, $filtro);
    $tratativasPorCargo = fetch_tratativas_por_cargo($db, $filtro);

    $mesesDisponiveis = fetch_meses_disponiveis($db, $usuarioId, $tipoIds, $cargoIds, $assuntoIds);

    json_response([
        'periodo' => $periodo,
        'usuario_id' => $usuarioId,
        'cargo_ids' => $cargoIds,
        'assunto_ids' => $assuntoIds,
        'tipo_tratativa' => $tipoTratativa,
        'granularidade' => $granularidade,
        'meses_disponiveis' => $mesesDisponiveis,
        'kpis' => $kpis,
        'visitas_timeline' => $timeline[2],
        'teams_timeline' => $timeline[1],
        'ligacoes_timeline' => $timeline[3],
        'tratativas_por_tipo' => $tratativasPorTipo,
        'tratativas_por_assunto' => $tratativasPorAssunto,
        'tratativas_por_cargo' => $tratativasPorCargo,
    ]);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}

function resolve_tipo_tratativa(string $input): string
{
    $value = strtolower(trim($input));
    if (!in_array($value, ['all', 'visitas', 'teams', 'ligacao'], true)) {
        return 'all';
    }

    return $value;
}

function resolve_granularidade(string $input): string
{
    $value = strtolower(trim($input));
    return $value === 'dia' ? 'dia' : 'mes';
}

function tipo_ids_por_filtro(string $tipoTratativa): array
{
    if ($tipoTratativa === 'teams') {
        return [1];
    }
    if ($tipoTratativa === 'visitas') {
        return [2];
    }
    if ($tipoTratativa === 'ligacao') {
        return [3];
    }

    return [1, 2, 3];
}

function resolve_periodo(array $source): array
{
    $meses = parse_month_refs($source['meses'] ?? null);
    if (count($meses) === 0) {
        $meses = [date('Y-m')];
    }

    sort($meses);

    $inicio = $meses[0] . '-01';
    $ultimoMes = $meses[count($meses) - 1];
    $fim = $ultimoMes . '-31';
    $dateObj = DateTime::createFromFormat('Y-m-d', $ultimoMes . '-01');
    if ($dateObj instanceof DateTime) {
        $dateObj->modify('last day of this month');
        $fim = $dateObj->format('Y-m-d');
    }

    return [
        'modo' => 'meses',
        'meses' => $meses,
        'data_inicio' => $inicio,
        'data_fim' => $fim,
    ];
}

function parse_month_refs($raw): array
{
    $text = to_string_or_null($raw);
    if ($text === null) {
        return [];
    }

    $parts = preg_split('/\s*,\s*/', $text) ?: [];
    $valid = [];

    foreach ($parts as $part) {
        if (preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $part) === 1) {
            $valid[$part] = true;
        }
    }

    return array_keys($valid);
}

function parse_int_refs($raw): array
{
    $text = to_string_or_null($raw);
    if ($text === null) {
        return [];
    }

    $parts = preg_split('/\s*,\s*/', $text) ?: [];
    $valid = [];
    foreach ($parts as $part) {
        if (preg_match('/^\d+$/', $part) !== 1) {
            continue;
        }
        $intVal = (int) $part;
        if ($intVal > 0) {
            $valid[$intVal] = true;
        }
    }
    return array_keys($valid);
}

function build_filtro_tratativas(
    mysqli $db,
    string $alias,
    array $periodo,
    ?int $usuarioId,
    array $tipoIds,
    array $cargoIds,
    array $assuntoIds
): array
{
    $clauses = ['1=1'];
    $types = '';
    $params = [];

    if ($periodo['modo'] === 'meses' && count($periodo['meses']) > 0) {
        $placeholders = implode(', ', array_fill(0, count($periodo['meses']), '?'));
        $clauses[] = 'DATE_FORMAT(' . $alias . '.`data`, "%Y-%m") IN (' . $placeholders . ')';
        $types .= str_repeat('s', count($periodo['meses']));
        $params = array_merge($params, $periodo['meses']);
    }

    if ($usuarioId !== null && $usuarioId > 0) {
        $clauses[] = $alias . '.id_usuario = ?';
        $types .= 'i';
        $params[] = $usuarioId;
    }

    if (count($tipoIds) > 0) {
        $placeholders = implode(', ', array_fill(0, count($tipoIds), '?'));
        $clauses[] = $alias . '.id_tratativa IN (' . $placeholders . ')';
        $types .= str_repeat('i', count($tipoIds));
        $params = array_merge($params, $tipoIds);
    }

    if (count($cargoIds) > 0) {
        if (has_tratativas_cargos_table($db)) {
            $placeholders = implode(', ', array_fill(0, count($cargoIds), '?'));
            $clauses[] = 'EXISTS (
                SELECT 1
                FROM fTratativasCargos tc
                WHERE tc.id_tratativa = ' . $alias . '.id
                  AND tc.id_cargo IN (' . $placeholders . ')
            )';
        } else {
            $placeholders = implode(', ', array_fill(0, count($cargoIds), '?'));
            $clauses[] = $alias . '.id_cargo IN (' . $placeholders . ')';
        }
        $types .= str_repeat('i', count($cargoIds));
        $params = array_merge($params, $cargoIds);
    }

    if (count($assuntoIds) > 0) {
        if (has_tratativas_assuntos_table($db)) {
            $placeholders = implode(', ', array_fill(0, count($assuntoIds), '?'));
            $clauses[] = 'EXISTS (
                SELECT 1
                FROM fTratativasAssuntos ta
                WHERE ta.id_tratativa = ' . $alias . '.id
                  AND ta.id_assunto IN (' . $placeholders . ')
            )';
        } else {
            $placeholders = implode(', ', array_fill(0, count($assuntoIds), '?'));
            $clauses[] = $alias . '.id_assunto IN (' . $placeholders . ')';
        }
        $types .= str_repeat('i', count($assuntoIds));
        $params = array_merge($params, $assuntoIds);
    }

    return [
        'where_sql' => implode(' AND ', $clauses),
        'types' => $types,
        'params' => $params,
    ];
}

function fetch_kpis(mysqli $db, array $filtro): array
{
    $rows = db_query_all(
        $db,
        'SELECT t.id_tratativa, COUNT(*) AS total
         FROM fTratativas t
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY t.id_tratativa',
        $filtro['types'],
        $filtro['params']
    );

    $counts = [1 => 0, 2 => 0, 3 => 0];
    foreach ($rows as $row) {
        $idTratativa = (int) ($row['id_tratativa'] ?? 0);
        if (!isset($counts[$idTratativa])) {
            continue;
        }
        $counts[$idTratativa] = (int) ($row['total'] ?? 0);
    }

    $totalVisitas = $counts[2];
    $totalTeams = $counts[1];
    $totalLigacoes = $counts[3];
    $totalTratativas = $totalTeams + $totalVisitas + $totalLigacoes;
    $usuariosRow = db_query_one(
        $db,
        'SELECT COUNT(DISTINCT id_usuario) AS total FROM dUsuarios WHERE ativo = 1'
    );
    $totalUsuarios = (int) ($usuariosRow['total'] ?? 0);

    return [
        'total_tratativas' => $totalTratativas,
        'total_teams' => $totalTeams,
        'total_visitas' => $totalVisitas,
        'total_ligacoes' => $totalLigacoes,
        'total_usuarios' => $totalUsuarios,
    ];
}

function fetch_timeline_por_tipo(mysqli $db, array $filtro, string $granularidade): array
{
    $dateExpr = $granularidade === 'dia'
        ? 'DATE_FORMAT(t.`data`, "%Y-%m-%d")'
        : 'DATE_FORMAT(t.`data`, "%Y-%m-01")';

    $rows = db_query_all(
        $db,
        'SELECT
            ' . $dateExpr . ' AS data_ref,
            t.id_tratativa,
            COUNT(*) AS quantidade
         FROM fTratativas t
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY ' . $dateExpr . ', t.id_tratativa
         ORDER BY data_ref ASC',
        $filtro['types'],
        $filtro['params']
    );

    $timeline = [
        1 => [],
        2 => [],
        3 => [],
    ];

    foreach ($rows as $row) {
        $idTratativa = (int) ($row['id_tratativa'] ?? 0);
        if (!isset($timeline[$idTratativa])) {
            continue;
        }

        $timeline[$idTratativa][] = [
            'data' => $row['data_ref'],
            'quantidade' => (int) ($row['quantidade'] ?? 0),
        ];
    }

    return $timeline;
}

function fetch_tratativas_por_tipo(mysqli $db, array $filtro): array
{
    $rows = db_query_all(
        $db,
        'SELECT t.id_tratativa, COUNT(*) AS total
         FROM fTratativas t
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY t.id_tratativa',
        $filtro['types'],
        $filtro['params']
    );

    $counts = [1 => 0, 2 => 0, 3 => 0];
    foreach ($rows as $row) {
        $idTratativa = (int) ($row['id_tratativa'] ?? 0);
        if (isset($counts[$idTratativa])) {
            $counts[$idTratativa] = (int) ($row['total'] ?? 0);
        }
    }

    return [
        'total_visitas' => $counts[2],
        'total_teams' => $counts[1],
        'total_ligacoes' => $counts[3],
    ];
}

function fetch_tratativas_por_assunto(mysqli $db, array $filtro): array
{
    $useBridge = has_tratativas_assuntos_table($db);
    if ($useBridge) {
        $sql = 'SELECT
            COALESCE(a.assunto, "Sem assunto") AS assunto,
            SUM(CASE WHEN t.id_tratativa = 2 THEN 1 ELSE 0 END) AS total_visitas,
            SUM(CASE WHEN t.id_tratativa = 1 THEN 1 ELSE 0 END) AS total_teams,
            SUM(CASE WHEN t.id_tratativa = 3 THEN 1 ELSE 0 END) AS total_ligacoes,
            COUNT(*) AS total
         FROM fTratativas t
         LEFT JOIN fTratativasAssuntos ta ON ta.id_tratativa = t.id
         LEFT JOIN dAssuntos a ON a.id_assunto = ta.id_assunto
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY COALESCE(a.assunto, "Sem assunto")
         ORDER BY total DESC, assunto ASC
         LIMIT 30';
    } else {
        $sql = 'SELECT
            COALESCE(a.assunto, "Sem assunto") AS assunto,
            SUM(CASE WHEN t.id_tratativa = 2 THEN 1 ELSE 0 END) AS total_visitas,
            SUM(CASE WHEN t.id_tratativa = 1 THEN 1 ELSE 0 END) AS total_teams,
            SUM(CASE WHEN t.id_tratativa = 3 THEN 1 ELSE 0 END) AS total_ligacoes,
            COUNT(*) AS total
         FROM fTratativas t
         LEFT JOIN dAssuntos a ON a.id_assunto = t.id_assunto
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY COALESCE(a.assunto, "Sem assunto")
         ORDER BY total DESC, assunto ASC
         LIMIT 30';
    }

    $rows = db_query_all($db, $sql, $filtro['types'], $filtro['params']);

    foreach ($rows as &$row) {
        $row['total_visitas'] = (int) ($row['total_visitas'] ?? 0);
        $row['total_teams'] = (int) ($row['total_teams'] ?? 0);
        $row['total_ligacoes'] = (int) ($row['total_ligacoes'] ?? 0);
        $row['total'] = (int) ($row['total'] ?? 0);
    }
    unset($row);

    return $rows;
}

function fetch_tratativas_por_cargo(mysqli $db, array $filtro): array
{
    $useBridge = has_tratativas_cargos_table($db);
    if ($useBridge) {
        $sql = 'SELECT
            COALESCE(c.cargo, "Não informado") AS cargo,
            SUM(CASE WHEN t.id_tratativa = 1 THEN 1 ELSE 0 END) AS total_teams,
            SUM(CASE WHEN t.id_tratativa = 2 THEN 1 ELSE 0 END) AS total_visitas,
            SUM(CASE WHEN t.id_tratativa = 3 THEN 1 ELSE 0 END) AS total_ligacoes,
            COUNT(*) AS total
         FROM fTratativas t
         LEFT JOIN fTratativasCargos tc ON tc.id_tratativa = t.id
         LEFT JOIN dCargos c ON c.id_cargo = tc.id_cargo
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY COALESCE(c.cargo, "Não informado")
         ORDER BY total DESC, cargo ASC
         LIMIT 30';
    } else {
        $sql = 'SELECT
            COALESCE(c.cargo, "Não informado") AS cargo,
            SUM(CASE WHEN t.id_tratativa = 1 THEN 1 ELSE 0 END) AS total_teams,
            SUM(CASE WHEN t.id_tratativa = 2 THEN 1 ELSE 0 END) AS total_visitas,
            SUM(CASE WHEN t.id_tratativa = 3 THEN 1 ELSE 0 END) AS total_ligacoes,
            COUNT(*) AS total
         FROM fTratativas t
         LEFT JOIN dCargos c ON c.id_cargo = t.id_cargo
         WHERE ' . $filtro['where_sql'] . '
         GROUP BY COALESCE(c.cargo, "Não informado")
         ORDER BY total DESC, cargo ASC
         LIMIT 30';
    }

    $rows = db_query_all($db, $sql, $filtro['types'], $filtro['params']);

    foreach ($rows as &$row) {
        $row['total_teams'] = (int) ($row['total_teams'] ?? 0);
        $row['total_visitas'] = (int) ($row['total_visitas'] ?? 0);
        $row['total_ligacoes'] = (int) ($row['total_ligacoes'] ?? 0);
        $row['total'] = (int) ($row['total'] ?? 0);
    }
    unset($row);

    return $rows;
}

function fetch_meses_disponiveis(mysqli $db, ?int $usuarioId, array $tipoIds, array $cargoIds, array $assuntoIds): array
{
    $where = ['1=1'];
    $types = '';
    $params = [];

    if ($usuarioId !== null && $usuarioId > 0) {
        $where[] = 't.id_usuario = ?';
        $types .= 'i';
        $params[] = $usuarioId;
    }

    if (count($tipoIds) > 0) {
        $placeholders = implode(', ', array_fill(0, count($tipoIds), '?'));
        $where[] = 't.id_tratativa IN (' . $placeholders . ')';
        $types .= str_repeat('i', count($tipoIds));
        $params = array_merge($params, $tipoIds);
    }

    if (count($cargoIds) > 0) {
        if (has_tratativas_cargos_table($db)) {
            $placeholders = implode(', ', array_fill(0, count($cargoIds), '?'));
            $where[] = 'EXISTS (
                SELECT 1
                FROM fTratativasCargos tc
                WHERE tc.id_tratativa = t.id
                  AND tc.id_cargo IN (' . $placeholders . ')
            )';
        } else {
            $placeholders = implode(', ', array_fill(0, count($cargoIds), '?'));
            $where[] = 't.id_cargo IN (' . $placeholders . ')';
        }
        $types .= str_repeat('i', count($cargoIds));
        $params = array_merge($params, $cargoIds);
    }

    if (count($assuntoIds) > 0) {
        if (has_tratativas_assuntos_table($db)) {
            $placeholders = implode(', ', array_fill(0, count($assuntoIds), '?'));
            $where[] = 'EXISTS (
                SELECT 1
                FROM fTratativasAssuntos ta
                WHERE ta.id_tratativa = t.id
                  AND ta.id_assunto IN (' . $placeholders . ')
            )';
        } else {
            $placeholders = implode(', ', array_fill(0, count($assuntoIds), '?'));
            $where[] = 't.id_assunto IN (' . $placeholders . ')';
        }
        $types .= str_repeat('i', count($assuntoIds));
        $params = array_merge($params, $assuntoIds);
    }

    $rows = db_query_all(
        $db,
        'SELECT DISTINCT DATE_FORMAT(t.`data`, "%Y-%m") AS mes_ref
         FROM fTratativas t
         WHERE ' . implode(' AND ', $where) . '
         ORDER BY mes_ref DESC',
        $types,
        $params
    );

    $out = [];
    foreach ($rows as $row) {
        $mesRef = to_string_or_null($row['mes_ref'] ?? null);
        if ($mesRef === null) {
            continue;
        }

        $out[] = [
            'mes_ref' => $mesRef,
            'label' => month_label_pt($mesRef),
        ];
    }

    if (count($out) === 0) {
        $currentMes = date('Y-m');
        $out[] = [
            'mes_ref' => $currentMes,
            'label' => month_label_pt($currentMes),
        ];
    }

    return $out;
}

function month_label_pt(string $mesRef): string
{
    $meses = [
        '01' => 'Jan',
        '02' => 'Fev',
        '03' => 'Mar',
        '04' => 'Abr',
        '05' => 'Mai',
        '06' => 'Jun',
        '07' => 'Jul',
        '08' => 'Ago',
        '09' => 'Set',
        '10' => 'Out',
        '11' => 'Nov',
        '12' => 'Dez',
    ];

    $year = substr($mesRef, 0, 4);
    $month = substr($mesRef, 5, 2);

    return ($meses[$month] ?? $month) . ' - ' . $year;
}

function ensure_relation_tables(mysqli $db): void
{
    db_execute(
        $db,
        'CREATE TABLE IF NOT EXISTS fTratativasCargos (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            id_tratativa BIGINT UNSIGNED NOT NULL,
            id_cargo INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uk_fTratativasCargos (id_tratativa, id_cargo),
            KEY idx_fTratativasCargos_cargo (id_cargo),
            CONSTRAINT fk_fTratativasCargos_tratativa FOREIGN KEY (id_tratativa) REFERENCES fTratativas(id) ON DELETE CASCADE,
            CONSTRAINT fk_fTratativasCargos_cargo FOREIGN KEY (id_cargo) REFERENCES dCargos(id_cargo) ON DELETE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );

    db_execute(
        $db,
        'CREATE TABLE IF NOT EXISTS fTratativasAssuntos (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            id_tratativa BIGINT UNSIGNED NOT NULL,
            id_assunto INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uk_fTratativasAssuntos (id_tratativa, id_assunto),
            KEY idx_fTratativasAssuntos_assunto (id_assunto),
            CONSTRAINT fk_fTratativasAssuntos_tratativa FOREIGN KEY (id_tratativa) REFERENCES fTratativas(id) ON DELETE CASCADE,
            CONSTRAINT fk_fTratativasAssuntos_assunto FOREIGN KEY (id_assunto) REFERENCES dAssuntos(id_assunto) ON DELETE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );

    db_execute(
        $db,
        'INSERT IGNORE INTO fTratativasCargos (id_tratativa, id_cargo)
         SELECT t.id, t.id_cargo
         FROM fTratativas t
         WHERE t.id_cargo IS NOT NULL'
    );

    db_execute(
        $db,
        'INSERT IGNORE INTO fTratativasAssuntos (id_tratativa, id_assunto)
         SELECT t.id, t.id_assunto
         FROM fTratativas t
         WHERE t.id_assunto IS NOT NULL'
    );
}

function has_table(mysqli $db, string $tableName): bool
{
    $row = db_query_one(
        $db,
        'SELECT 1 AS existe
         FROM INFORMATION_SCHEMA.TABLES
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
         LIMIT 1',
        's',
        [$tableName]
    );
    return $row !== null;
}

function has_tratativas_cargos_table(mysqli $db): bool
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $cached = has_table($db, 'fTratativasCargos');
    return $cached;
}

function has_tratativas_assuntos_table(mysqli $db): bool
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $cached = has_table($db, 'fTratativasAssuntos');
    return $cached;
}
