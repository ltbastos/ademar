﻿<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/windows_user.php';

init_api();

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
        json_error('Metodo nao permitido.', 405);
    }

    $detected = detect_windows_identity();

    json_response([
        'email' => $detected['email'],
        'usuario' => $detected['usuario'],
        'funcional' => $detected['funcional'],
        'fonte' => $detected['fonte'],
        'detalhe' => $detected['detalhe'],
        'candidatos' => $detected['candidatos'],
    ]);
} catch (Throwable $e) {
    json_error('Erro ao obter usuario do sistema.', 500, ['detalhe' => $e->getMessage()]);
}
