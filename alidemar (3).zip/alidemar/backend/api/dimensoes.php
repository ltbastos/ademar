﻿<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/db.php';

init_api();

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
        json_error('Metodo nao permitido.', 405);
    }

    $db = db_connect();
    ensure_assunto_outros($db);
    $tipo = to_string_or_null($_GET['tipo'] ?? 'all') ?? 'all';

    $dados = [
        'usuarios' => fetch_usuarios($db),
        'temas_visita' => fetch_assuntos($db),
        'assuntos' => fetch_assuntos($db),
        'tipos_interacao' => fetch_tipos_interacao($db),
        'tipos_tratativa' => fetch_tipos_interacao($db),
        'cargos' => fetch_cargos($db),
    ];

    if ($tipo === 'all') {
        json_response(['dados' => $dados]);
    }

    if (!array_key_exists($tipo, $dados)) {
        json_error('Tipo de dimensao invalido.', 422);
    }

    json_response([
        'tipo' => $tipo,
        'dados' => $dados[$tipo],
    ]);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}

function fetch_usuarios(mysqli $db): array
{
    return db_query_all(
        $db,
        'SELECT
            u.id_usuario AS id,
            u.usuario AS nome,
            LOWER(REPLACE(TRIM(u.usuario), " ", "-")) AS slug,
            u.ativo,
            u.criado_em,
            u.atualizado_em
         FROM dUsuarios u
         WHERE u.ativo = 1
         ORDER BY u.usuario ASC'
    );
}

function fetch_assuntos(mysqli $db): array
{
    return db_query_all(
        $db,
        'SELECT
            a.id_assunto AS id,
            a.assunto AS nome,
            a.ativo,
            a.criado_em,
            a.atualizado_em
         FROM dAssuntos a
         WHERE a.ativo = 1
         ORDER BY a.assunto ASC'
    );
}

function ensure_assunto_outros(mysqli $db): void
{
    db_execute(
        $db,
        'UPDATE dAssuntos
         SET ativo = 1
         WHERE LOWER(TRIM(assunto)) = "outros"'
    );

    db_execute(
        $db,
        'INSERT INTO dAssuntos (assunto, ativo)
         SELECT "Outros", 1
         WHERE NOT EXISTS (
             SELECT 1
             FROM dAssuntos
             WHERE LOWER(TRIM(assunto)) = "outros"
         )'
    );
}

function fetch_tipos_interacao(mysqli $db): array
{
    return db_query_all(
        $db,
        'SELECT
            t.id_tratativa AS id,
            t.tipo_tratativa AS nome,
            t.ativo,
            t.criado_em,
            t.atualizado_em
         FROM dTipoTratativa t
         WHERE t.ativo = 1
         ORDER BY t.id_tratativa ASC'
    );
}

function fetch_cargos(mysqli $db): array
{
    return db_query_all(
        $db,
        'SELECT
            c.id_cargo AS id,
            c.cargo AS nome,
            c.ativo,
            c.criado_em,
            c.atualizado_em
         FROM dCargos c
         WHERE c.ativo = 1
         ORDER BY CASE LOWER(TRIM(c.cargo))
             WHEN "regional" THEN 1
             WHEN "diretor regional" THEN 1
             WHEN "superintendente" THEN 2
             WHEN "gerente regional" THEN 3
             WHEN "gerente executivo comercial" THEN 4
             WHEN "gereten executivo comercial" THEN 4
             WHEN "gerente de agência" THEN 5
             WHEN "gerente de agencia" THEN 5
             WHEN "gerente de plataforma" THEN 6
             WHEN "team leader" THEN 7
             WHEN "gerente de gestão" THEN 8
             WHEN "gerente de gestao" THEN 8
             WHEN "gerente de relacionamento" THEN 9
             WHEN "assistente" THEN 10
             ELSE 99
         END,
         c.cargo ASC'
    );
}
