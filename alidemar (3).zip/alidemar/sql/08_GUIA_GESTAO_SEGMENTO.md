﻿# Guia Rapido - Banco GestaoSegmento

Use este passo a passo para subir o novo banco no outro computador exatamente como esta agora.

## Ordem de execucao
1. `06_schema_gestao_segmento.sql`
2. `07_seed_gestaosegmento_fake.sql` (opcional, so para visualizar dashboard com volume)

## O que cada arquivo faz
- `06_schema_gestao_segmento.sql`
  - cria o banco `GestaoSegmento`
  - cria as dimensoes `dAssuntos`, `dUsuarios`, `dCargos`, `dTipoTratativa`, `dCalendario`
  - cria a fato `fTratativas`
  - ja inclui os cadastros base (Ademar/Aline, cargos e assuntos)
- `07_seed_gestaosegmento_fake.sql`
  - adiciona tratativas ficticias para teste visual dos graficos

## Validacao rapida
Rode os selects abaixo apos executar os scripts:

```sql
SELECT COUNT(*) AS total_usuarios FROM GestaoSegmento.dUsuarios;
SELECT COUNT(*) AS total_cargos FROM GestaoSegmento.dCargos;
SELECT COUNT(*) AS total_assuntos FROM GestaoSegmento.dAssuntos;
SELECT COUNT(*) AS total_tipos FROM GestaoSegmento.dTipoTratativa;
SELECT COUNT(*) AS total_calendario FROM GestaoSegmento.dCalendario;
SELECT COUNT(*) AS total_tratativas FROM GestaoSegmento.fTratativas;
```

## Observacao
A aplicacao ja foi configurada para usar este banco em:
- `backend/config/database.php` (`database = GestaoSegmento`)
