# Escopo Atual - Alidemar

## Stack
- Frontend: HTML + CSS + JavaScript
- Backend: PHP (`mysqli`)
- Banco: MySQL/MariaDB (XAMPP)

## Banco principal
- `GestaoSegmento`
- Fato: `fTratativas`
- Dimensões: `dUsuarios`, `dTipoTratativa`, `dCargos`, `dAssuntos`, `dCalendario`

## Módulos da aplicação
- Dashboard
- Analítico (tabela da fato com edição)

## Filtros globais
- Período (multi-seleção de mês/ano)
- Usuário
- Tipo de tratativa
