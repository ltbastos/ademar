﻿<!DOCTYPE html>
<html lang="pt-BR" data-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Alidemar | Ferramenta de Gestão dos Consultores de Segmento</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <div class="ambient"></div>

  <div class="app-layout">
    <aside class="sidebar">
      <div class="brand">
        <div id="sidebar-selected-user" class="brand-user">TODOS</div>
      </div>

      <section class="sidebar-pages card-lite">
        <h3>Páginas</h3>
        <nav class="nav">
          <button class="nav-btn is-active" data-view="dashboard" type="button">
            <span class="nav-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24">
                <rect x="3.5" y="3.5" width="7" height="7"></rect>
                <rect x="13.5" y="3.5" width="7" height="7"></rect>
                <rect x="3.5" y="13.5" width="7" height="7"></rect>
                <rect x="13.5" y="13.5" width="7" height="7"></rect>
              </svg>
            </span>
            <span>Dashboard</span>
          </button>

          <button class="nav-btn" data-view="analitico" type="button">
            <span class="nav-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24">
                <path d="M4 5.5h16"></path>
                <path d="M4 12h16"></path>
                <path d="M4 18.5h16"></path>
                <circle cx="7" cy="5.5" r="0.6"></circle>
                <circle cx="7" cy="12" r="0.6"></circle>
                <circle cx="7" cy="18.5" r="0.6"></circle>
              </svg>
            </span>
            <span>Analítico</span>
          </button>
        </nav>
      </section>

      <section class="sidebar-filters card-lite">
        <h3>Filtros globais</h3>

        <label>Período
          <div id="filtro-periodo-dropdown" class="multi-dropdown">
            <button id="btn-periodo-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Mês atual</button>
            <div id="periodo-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div class="multi-options-actions">
                <button id="btn-periodo-toggle-all" class="multi-options-toggle" type="button">Selecionar tudo</button>
              </div>
              <div id="periodo-meses-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>

        <label>Usuário
          <select id="filtro-usuario-global"></select>
        </label>

        <label>Tipo de tratativa
          <select id="filtro-tratativa-global">
            <option value="all">Teams + Visitas + Ligações</option>
            <option value="teams">Somente Teams</option>
            <option value="visitas">Somente Visitas</option>
            <option value="ligacao">Somente Ligações</option>
          </select>
        </label>

        <label>Cargo
          <div id="filtro-cargo-dropdown" class="multi-dropdown">
            <button id="btn-cargo-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Todos</button>
            <div id="cargo-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div class="multi-options-actions">
                <button id="btn-cargo-toggle-all" class="multi-options-toggle" type="button">Selecionar tudo</button>
              </div>
              <div id="cargo-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>

        <label>Assunto
          <div id="filtro-assunto-dropdown" class="multi-dropdown">
            <button id="btn-assunto-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Todos</button>
            <div id="assunto-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div class="multi-options-actions">
                <button id="btn-assunto-toggle-all" class="multi-options-toggle" type="button">Selecionar tudo</button>
              </div>
              <div id="assunto-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>
      </section>
    </aside>

    <main class="main-content">
      <header class="topbar card">
        <div class="topbar-title-group">
          <h2 id="view-title">Ferramenta de Gestão dos Consultores de Segmento</h2>
        </div>

        <div class="topbar-actions">
          <button id="btn-open-quick-add" class="btn btn-add" type="button" aria-label="Nova tratativa">+</button>
          <label class="theme-switch" for="theme-switch-input" aria-label="Alternar tema">
            <input id="theme-switch-input" type="checkbox" />
            <span class="theme-switch-track">
              <span class="theme-switch-icon sun">&#9728;</span>
              <span class="theme-switch-thumb"></span>
              <span class="theme-switch-icon moon">&#9790;</span>
            </span>
          </label>
        </div>
      </header>

      <div id="global-feedback" class="feedback" role="status" aria-live="polite"></div>
      <div id="period-empty-message" class="empty-inline is-hidden">Não há dados para os meses selecionados.</div>
      <div id="global-loading" class="loading-overlay" aria-hidden="false">
        <div class="loading-spinner" aria-hidden="true"></div>
        <p id="global-loading-text">Inicializando dashboard...</p>
      </div>

      <section id="view-dashboard" class="view is-active">
        <div class="kpi-grid">
          <article class="kpi-card">
            <span>Total de Tratativas</span>
            <strong id="kpi-total-tratativas">0</strong>
          </article>
          <article class="kpi-card">
            <span>Teams</span>
            <strong id="kpi-total-teams">0</strong>
          </article>
          <article class="kpi-card">
            <span>Visitas</span>
            <strong id="kpi-total-visitas">0</strong>
          </article>
          <article class="kpi-card">
            <span>Ligações</span>
            <strong id="kpi-total-ligacoes">0</strong>
          </article>
          <article class="kpi-card">
            <span>Total de Usuários</span>
            <strong id="kpi-total-usuarios">0</strong>
          </article>
        </div>

        <div class="dashboard-grid">
          <article id="card-evolucao" class="card chart-card chart-evolucao">
            <div class="card-head-inline card-head-evolucao">
              <h3>Evolução de tratativas</h3>
              <div class="toggle-group">
                <button id="btn-granularidade-mes" class="toggle-btn is-active" type="button" data-granularidade="mes">Mensal</button>
                <button id="btn-granularidade-dia" class="toggle-btn" type="button" data-granularidade="dia">Diário</button>
              </div>
            </div>
            <div id="chart-evolucao-scroll" class="chart-scroll-x">
              <div id="chart-evolucao" class="chart"></div>
            </div>
          </article>

          <article id="card-top-volume" class="card chart-card chart-volume">
            <div class="card-head-inline">
              <h3 id="chart-volume-title">Quantidade de Tratativas por Assunto</h3>
            </div>
            <div id="chart-top-volume-scroll" class="chart-scroll-y">
              <div id="chart-top-volume" class="chart chart-tall"></div>
            </div>
          </article>

          <article id="card-interacoes-tipo" class="card chart-card chart-rosca">
            <h3>Tratativas por tipo</h3>
            <div id="chart-interacoes-tipo" class="chart"></div>
          </article>

          <article id="card-demandas-status" class="card chart-card chart-status">
            <h3>Tratativas por Cargo</h3>
            <div id="chart-demandas-status-scroll" class="chart-scroll-x">
              <div id="chart-demandas-status" class="chart"></div>
            </div>
          </article>

        </div>
      </section>

      <section id="view-analitico" class="view">
        <article class="card card-scroll">
          <div class="card-head-inline">
            <h3>Tratativas analíticas</h3>
            <div class="analitico-toolbar">
              <input id="analitico-search" type="search" placeholder="Pesquisar na tabela..." autocomplete="off" />
              <button id="btn-export-csv" class="btn btn-ghost" type="button">Exportar CSV</button>
            </div>
          </div>
          <div id="lista-analitico"></div>
        </article>
      </section>
    </main>
  </div>

  <div id="quick-add-modal" class="modal-backdrop is-hidden" aria-hidden="true">
    <div class="modal-card">
      <div class="modal-head">
        <h3 id="quick-modal-title">Nova tratativa</h3>
        <button id="btn-close-quick-add" class="modal-close" type="button" aria-label="Fechar">x</button>
      </div>

      <form id="form-quick-add" class="form-grid modal-form">
        <input id="quick-tratativa-id" type="hidden" />

        <label>Tipo de Tratativa
          <select id="quick-tratativa-tipo" required></select>
        </label>

        <label>Usuário
          <select id="quick-tratativa-usuario" required></select>
        </label>

        <label>Cargo
          <div id="quick-cargo-dropdown" class="multi-dropdown modal-multi-dropdown">
            <button id="btn-quick-cargo-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Selecione cargo(s)</button>
            <div id="quick-cargo-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div id="quick-cargo-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>

        <label>Junção
          <input id="quick-tratativa-agencia" type="text" placeholder="Digite a junção" />
        </label>

        <label class="span-2">Assunto
          <div id="quick-assunto-dropdown" class="multi-dropdown modal-multi-dropdown">
            <button id="btn-quick-assunto-dropdown" class="multi-dropdown-trigger" type="button" aria-expanded="false">Selecione assunto(s)</button>
            <div id="quick-assunto-dropdown-panel" class="multi-dropdown-panel is-hidden">
              <div id="quick-assunto-options" class="multi-options-list"></div>
            </div>
          </div>
        </label>

        <label class="span-2">Descrição
          <textarea id="quick-tratativa-descricao"></textarea>
        </label>

        <label class="span-2">Contato
          <input id="quick-tratativa-contato" type="text" placeholder="Nome do contato" />
        </label>

        <label>Data
          <input id="quick-tratativa-data" type="datetime-local" required />
        </label>

        <div class="span-2 modal-actions">
          <button id="btn-cancel-quick-add" class="btn btn-ghost" type="button">Cancelar</button>
          <button id="btn-save-quick-add" class="btn" type="submit">Salvar tratativa</button>
        </div>
      </form>
    </div>
  </div>

  <div id="confirm-modal" class="confirm-backdrop is-hidden" aria-hidden="true">
    <div class="confirm-card" role="dialog" aria-modal="true" aria-labelledby="confirm-title" aria-describedby="confirm-message">
      <h3 id="confirm-title">Confirmar ação</h3>
      <p id="confirm-message">Tem certeza que deseja continuar?</p>
      <div class="confirm-actions">
        <button id="btn-confirm-cancel" class="btn btn-ghost" type="button">Cancelar</button>
        <button id="btn-confirm-ok" class="btn" type="button">Confirmar</button>
      </div>
    </div>
  </div>

  <script src="vendor/apexcharts.min.js"></script>
  <script src="app.js"></script>
</body>
</html>
