﻿-- ==========================================================
-- Banco novo: GestaoSegmento
-- Modelo estrela simplificado para tratativas
-- Compatível com MySQL do XAMPP antigo
-- ==========================================================

CREATE DATABASE IF NOT EXISTS `GestaoSegmento`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `GestaoSegmento`;

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `fTratativas`;
DROP TABLE IF EXISTS `dCalendario`;
DROP TABLE IF EXISTS `dAssuntos`;
DROP TABLE IF EXISTS `dCargos`;
DROP TABLE IF EXISTS `dUsuarios`;
DROP TABLE IF EXISTS `dTipoTratativa`;

CREATE TABLE `dTipoTratativa` (
  `id_tratativa` TINYINT UNSIGNED NOT NULL,
  `tipo_tratativa` VARCHAR(30) NOT NULL,
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tratativa`),
  UNIQUE KEY `uk_dTipoTratativa_nome` (`tipo_tratativa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `dTipoTratativa` (`id_tratativa`, `tipo_tratativa`) VALUES
  (1, 'Teams'),
  (2, 'Visitas'),
  (3, 'Ligações');

CREATE TABLE `dUsuarios` (
  `id_usuario` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `usuario` VARCHAR(120) NOT NULL,
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `uk_dUsuarios_usuario` (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `dUsuarios` (`usuario`) VALUES
  ('Ademar Liberato'),
  ('Aline Rosa');

CREATE TABLE `dCargos` (
  `id_cargo` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `cargo` VARCHAR(150) NOT NULL,
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cargo`),
  UNIQUE KEY `uk_dCargos_cargo` (`cargo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `dCargos` (`cargo`) VALUES
  ('Diretor Regional'),
  ('Superintendente'),
  ('Gerente Regional'),
  ('Gerente Executivo Comercial'),
  ('Gerente Agência / Plataforma PJ'),
  ('Gerente de Gestão Empresas'),
  ('Team Leader'),
  ('Gerente de Relacionamento'),
  ('Assistente');

CREATE TABLE `dAssuntos` (
  `id_assunto` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `assunto` VARCHAR(180) NOT NULL,
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_assunto`),
  UNIQUE KEY `uk_dAssuntos_assunto` (`assunto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `dAssuntos` (`assunto`) VALUES
  ('Orçamento'),
  ('Estratégia Comercial'),
  ('Gestão de Vencidos'),
  ('Smart Ações Comerciais'),
  ('POBJ Programa / POBJ Produção'),
  ('Sucesso de Equipe'),
  ('Produtividade Crédito'),
  ('Produtividade Grupo Segurador'),
  ('Produtividade Cash'),
  ('Produtividade Base de Clientes'),
  ('Produtividade Captação'),
  ('Giro de Carteira'),
  ('Conecta'),
  ('Open Finance'),
  ('EncantaBRA');

CREATE TABLE `dCalendario` (
  `data` DATE NOT NULL,
  `dia_semana` VARCHAR(14) NOT NULL,
  `mes_nome` VARCHAR(10) NOT NULL,
  `dia` TINYINT UNSIGNED NOT NULL,
  `mes` TINYINT UNSIGNED NOT NULL,
  `ano` SMALLINT UNSIGNED NOT NULL,
  `feriado` TINYINT(1) NOT NULL DEFAULT 0,
  `mes_ano` VARCHAR(12) NOT NULL,
  PRIMARY KEY (`data`),
  KEY `idx_dCalendario_mes_ano` (`mes_ano`),
  KEY `idx_dCalendario_ano_mes` (`ano`, `mes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DELIMITER $$

CREATE PROCEDURE `sp_popular_dCalendario`(
  IN p_data_inicio DATE,
  IN p_data_fim DATE
)
BEGIN
  DECLARE v_data DATE;

  SET v_data = p_data_inicio;

  WHILE v_data <= p_data_fim DO
    INSERT INTO `dCalendario` (
      `data`,
      `dia_semana`,
      `mes_nome`,
      `dia`,
      `mes`,
      `ano`,
      `feriado`,
      `mes_ano`
    ) VALUES (
      v_data,
      CASE DAYOFWEEK(v_data)
        WHEN 1 THEN 'Domingo'
        WHEN 2 THEN 'Segunda'
        WHEN 3 THEN 'Terça'
        WHEN 4 THEN 'Quarta'
        WHEN 5 THEN 'Quinta'
        WHEN 6 THEN 'Sexta'
        ELSE 'Sábado'
      END,
      CASE MONTH(v_data)
        WHEN 1 THEN 'Janeiro'
        WHEN 2 THEN 'Fevereiro'
        WHEN 3 THEN 'Março'
        WHEN 4 THEN 'Abril'
        WHEN 5 THEN 'Maio'
        WHEN 6 THEN 'Junho'
        WHEN 7 THEN 'Julho'
        WHEN 8 THEN 'Agosto'
        WHEN 9 THEN 'Setembro'
        WHEN 10 THEN 'Outubro'
        WHEN 11 THEN 'Novembro'
        ELSE 'Dezembro'
      END,
      DAY(v_data),
      MONTH(v_data),
      YEAR(v_data),
      0,
      CONCAT(
        CASE MONTH(v_data)
          WHEN 1 THEN 'Jan'
          WHEN 2 THEN 'Fev'
          WHEN 3 THEN 'Mar'
          WHEN 4 THEN 'Abr'
          WHEN 5 THEN 'Mai'
          WHEN 6 THEN 'Jun'
          WHEN 7 THEN 'Jul'
          WHEN 8 THEN 'Ago'
          WHEN 9 THEN 'Set'
          WHEN 10 THEN 'Out'
          WHEN 11 THEN 'Nov'
          ELSE 'Dez'
        END,
        ' - ',
        YEAR(v_data)
      )
    )
    ON DUPLICATE KEY UPDATE
      `dia_semana` = VALUES(`dia_semana`),
      `mes_nome` = VALUES(`mes_nome`),
      `dia` = VALUES(`dia`),
      `mes` = VALUES(`mes`),
      `ano` = VALUES(`ano`),
      `mes_ano` = VALUES(`mes_ano`);

    SET v_data = DATE_ADD(v_data, INTERVAL 1 DAY);
  END WHILE;
END $$

DELIMITER ;

CALL `sp_popular_dCalendario`('2024-01-01', '2035-12-31');
DROP PROCEDURE IF EXISTS `sp_popular_dCalendario`;

CREATE TABLE `fTratativas` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `data` DATETIME NOT NULL,
  `id_tratativa` TINYINT UNSIGNED NOT NULL,
  `id_usuario` INT UNSIGNED NOT NULL,
  `id_cargo` INT UNSIGNED NULL,
  `id_assunto` INT UNSIGNED NULL,
  `agencia` VARCHAR(200) NULL,
  `descricao` TEXT NULL,
  `contatos` TEXT NULL,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_fTratativas_data` (`data`),
  KEY `idx_fTratativas_usuario` (`id_usuario`),
  KEY `idx_fTratativas_tratativa` (`id_tratativa`),
  KEY `idx_fTratativas_cargo` (`id_cargo`),
  KEY `idx_fTratativas_assunto` (`id_assunto`),
  CONSTRAINT `fk_fTratativas_tipo` FOREIGN KEY (`id_tratativa`) REFERENCES `dTipoTratativa` (`id_tratativa`),
  CONSTRAINT `fk_fTratativas_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `dUsuarios` (`id_usuario`),
  CONSTRAINT `fk_fTratativas_cargo` FOREIGN KEY (`id_cargo`) REFERENCES `dCargos` (`id_cargo`),
  CONSTRAINT `fk_fTratativas_assunto` FOREIGN KEY (`id_assunto`) REFERENCES `dAssuntos` (`id_assunto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
