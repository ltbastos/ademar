-- ==========================================================
-- Migração: adiciona coluna livre `agencia` em fTratativas
-- Compatível com MySQL antigo (XAMPP)
-- ==========================================================

USE `GestaoSegmento`;

SET @db_name := DATABASE();

SET @agencia_col_exists := (
  SELECT COUNT(*)
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @db_name
    AND TABLE_NAME = 'fTratativas'
    AND COLUMN_NAME = 'agencia'
);

SET @sql_add_agencia := IF(
  @agencia_col_exists = 0,
  'ALTER TABLE `fTratativas` ADD COLUMN `agencia` VARCHAR(200) NULL AFTER `id_assunto`',
  'SELECT "Coluna agencia já existe." AS info'
);

PREPARE stmt_add_agencia FROM @sql_add_agencia;
EXECUTE stmt_add_agencia;
DEALLOCATE PREPARE stmt_add_agencia;

SET @agencia_idx_exists := (
  SELECT COUNT(*)
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = @db_name
    AND TABLE_NAME = 'fTratativas'
    AND INDEX_NAME = 'idx_fTratativas_agencia'
);

SET @sql_add_agencia_idx := IF(
  @agencia_idx_exists = 0,
  'CREATE INDEX `idx_fTratativas_agencia` ON `fTratativas` (`agencia`(120))',
  'SELECT "Índice idx_fTratativas_agencia já existe." AS info'
);

PREPARE stmt_add_agencia_idx FROM @sql_add_agencia_idx;
EXECUTE stmt_add_agencia_idx;
DEALLOCATE PREPARE stmt_add_agencia_idx;
