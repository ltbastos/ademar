﻿
(() => {
  const API_ROOT = "backend/api";
  const MONTHS_PT = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
  const ENABLE_ACCESS_VALIDATION = false;

  const state = {
    view: "dashboard",
    filtros: {
      meses: [currentMonthRef()],
      usuarioId: null,
      tipoTratativa: "all",
      cargoIds: [],
      assuntoIds: [],
      granularidade: "mes",
    },
    dimensoes: {
      usuarios: [],
      tiposTratativa: [],
      assuntos: [],
      cargos: [],
    },
    dashboard: null,
    analitico: {
      tratativas: [],
      total: 0,
      busca: "",
    },
    modalSelection: {
      cargos: [],
      assuntos: [],
    },
    charts: {},
    acesso: {
      autorizado: false,
      carregado: false,
    },
  };

  const dom = {};
  let feedbackTimer = null;
  let loadingCounter = 0;
  let loadingHideTimer = null;
  let autoRefreshTimer = null;
  let resizeTimer = null;
  let chartSyncTimer = null;
  let periodoDefaultInicializado = false;

  document.addEventListener("DOMContentLoaded", init);

  async function init() {
    cacheDom();
    bindEvents();
    applyTheme(loadTheme());
    const initialView = loadView();
    state.view = initialView;
    applyViewState(initialView);
    setDefaultDateInput();
    beginLoading("Inicializando painel...");

    try {
      if (ENABLE_ACCESS_VALIDATION) {
        const access = await loadAccessContext();
        if (!access.autorizado) {
          lockApplication(access);
          return;
        }
      } else {
        loadWindowsIdentityOnly();
      }

      unlockApplication();
      await loadDimensions();
      await refreshAllData();
      syncFilterInputs();
      if (state.view === "dashboard") {
        scheduleChartSync(120);
      }
      if (document.fonts && document.fonts.ready) {
        document.fonts.ready
          .then(() => {
            if (state.view === "dashboard") {
              scheduleChartSync(80);
            }
          })
          .catch(() => {});
      }
    } catch (error) {
      showFeedback(error.message || "Erro ao carregar aplicação.", "error");
    } finally {
      endLoading();
    }
  }

  function cacheDom() {
    dom.navButtons = Array.from(document.querySelectorAll(".nav-btn"));
    dom.views = Array.from(document.querySelectorAll(".view"));
    dom.viewTitle = document.getElementById("view-title");

    dom.feedback = document.getElementById("global-feedback");
    dom.periodEmptyMessage = document.getElementById("period-empty-message");
    dom.globalLoading = document.getElementById("global-loading");
    dom.globalLoadingText = document.getElementById("global-loading-text");

    dom.accessOverlay = document.getElementById("access-overlay");
    dom.accessOverlayTitle = document.getElementById("access-overlay-title");
    dom.accessOverlayMessage = document.getElementById("access-overlay-message");

    dom.windowsUserEmail = document.getElementById("windows-user-email");
    dom.sidebarSelectedUser = document.getElementById("sidebar-selected-user");

    dom.themeSwitchInput = document.getElementById("theme-switch-input");
    dom.btnOpenQuickAdd = document.getElementById("btn-open-quick-add");

    dom.filtroPeriodoDropdown = document.getElementById("filtro-periodo-dropdown");
    dom.btnPeriodoDropdown = document.getElementById("btn-periodo-dropdown");
    dom.btnPeriodoToggleAll = document.getElementById("btn-periodo-toggle-all");
    dom.periodoDropdownPanel = document.getElementById("periodo-dropdown-panel");
    dom.periodoMesesOptions = document.getElementById("periodo-meses-options");

    dom.filtroUsuarioGlobal = document.getElementById("filtro-usuario-global");
    dom.filtroTratativaGlobal = document.getElementById("filtro-tratativa-global");
    dom.filtroCargoDropdown = document.getElementById("filtro-cargo-dropdown");
    dom.btnCargoDropdown = document.getElementById("btn-cargo-dropdown");
    dom.btnCargoToggleAll = document.getElementById("btn-cargo-toggle-all");
    dom.cargoDropdownPanel = document.getElementById("cargo-dropdown-panel");
    dom.cargoOptions = document.getElementById("cargo-options");
    dom.filtroAssuntoDropdown = document.getElementById("filtro-assunto-dropdown");
    dom.btnAssuntoDropdown = document.getElementById("btn-assunto-dropdown");
    dom.btnAssuntoToggleAll = document.getElementById("btn-assunto-toggle-all");
    dom.assuntoDropdownPanel = document.getElementById("assunto-dropdown-panel");
    dom.assuntoOptions = document.getElementById("assunto-options");
    dom.evolucaoGranularidadeButtons = Array.from(document.querySelectorAll("[data-granularidade]"));

    dom.kpiTotalTratativas = document.getElementById("kpi-total-tratativas");
    dom.kpiTotalTeams = document.getElementById("kpi-total-teams");
    dom.kpiTotalVisitas = document.getElementById("kpi-total-visitas");
    dom.kpiTotalLigacoes = document.getElementById("kpi-total-ligacoes");
    dom.kpiTotalUsuarios = document.getElementById("kpi-total-usuarios");

    dom.chartEvolucaoScroll = document.getElementById("chart-evolucao-scroll");
    dom.chartEvolucao = document.getElementById("chart-evolucao");
    dom.chartTopVolume = document.getElementById("chart-top-volume");
    dom.chartInteracoesTipo = document.getElementById("chart-interacoes-tipo");
    dom.chartDemandasStatusScroll = document.getElementById("chart-demandas-status-scroll");
    dom.chartDemandasStatus = document.getElementById("chart-demandas-status");
    dom.chartWordCloud = document.getElementById("chart-wordcloud");
    dom.legendRosca = document.getElementById("legend-rosca");

    dom.listaAnalitico = document.getElementById("lista-analitico");
    dom.btnExportCsv = document.getElementById("btn-export-csv");
    dom.analiticoSearch = document.getElementById("analitico-search");

    dom.quickAddModal = document.getElementById("quick-add-modal");
    dom.btnCloseQuickAdd = document.getElementById("btn-close-quick-add");
    dom.formQuickAdd = document.getElementById("form-quick-add");
    dom.quickModalTitle = document.getElementById("quick-modal-title");
    dom.quickTratativaId = document.getElementById("quick-tratativa-id");
    dom.quickTratativaTipo = document.getElementById("quick-tratativa-tipo");
    dom.quickTratativaUsuario = document.getElementById("quick-tratativa-usuario");
    dom.quickCargoDropdown = document.getElementById("quick-cargo-dropdown");
    dom.btnQuickCargoDropdown = document.getElementById("btn-quick-cargo-dropdown");
    dom.quickCargoDropdownPanel = document.getElementById("quick-cargo-dropdown-panel");
    dom.quickCargoOptions = document.getElementById("quick-cargo-options");
    dom.quickAssuntoDropdown = document.getElementById("quick-assunto-dropdown");
    dom.btnQuickAssuntoDropdown = document.getElementById("btn-quick-assunto-dropdown");
    dom.quickAssuntoDropdownPanel = document.getElementById("quick-assunto-dropdown-panel");
    dom.quickAssuntoOptions = document.getElementById("quick-assunto-options");
    dom.quickTratativaAgencia = document.getElementById("quick-tratativa-agencia");
    dom.quickTratativaDescricao = document.getElementById("quick-tratativa-descricao");
    dom.quickTratativaContato = document.getElementById("quick-tratativa-contato");
    dom.quickTratativaData = document.getElementById("quick-tratativa-data");
  }

  function bindEvents() {
    dom.navButtons.forEach((button) => {
      button.addEventListener("click", () => switchView(button.dataset.view));
    });

    dom.btnPeriodoDropdown.addEventListener("click", (event) => {
      event.stopPropagation();
      togglePeriodoDropdown(dom.periodoDropdownPanel.classList.contains("is-hidden"));
    });

    dom.periodoMesesOptions.addEventListener("change", (event) => {
      if (!(event.target instanceof HTMLInputElement) || event.target.type !== "checkbox") {
        return;
      }

      const meses = getCheckedMonthsFromDropdown();
      state.filtros.meses = meses;
      updatePeriodoDropdownLabel();
      updateToggleAllLabel("periodo");
      if (meses.length === 0) {
        return;
      }
      scheduleAutoRefresh();
    });

    dom.btnPeriodoToggleAll?.addEventListener("click", (event) => {
      event.stopPropagation();
      toggleAllGlobalSelection("periodo");
    });

    dom.filtroUsuarioGlobal.addEventListener("change", () => {
      state.filtros.usuarioId = toIntOrNull(dom.filtroUsuarioGlobal.value);
      updateSidebarSelectedUser();
      scheduleAutoRefresh();
    });

    dom.filtroTratativaGlobal.addEventListener("change", () => {
      state.filtros.tipoTratativa = normalizeTipoTratativa(dom.filtroTratativaGlobal.value);
      scheduleAutoRefresh();
    });

    dom.btnCargoDropdown?.addEventListener("click", (event) => {
      event.stopPropagation();
      const open = dom.cargoDropdownPanel.classList.contains("is-hidden");
      toggleGlobalDropdown("cargo", open);
    });

    dom.btnAssuntoDropdown?.addEventListener("click", (event) => {
      event.stopPropagation();
      const open = dom.assuntoDropdownPanel.classList.contains("is-hidden");
      toggleGlobalDropdown("assunto", open);
    });

    dom.btnCargoToggleAll?.addEventListener("click", (event) => {
      event.stopPropagation();
      toggleAllGlobalSelection("cargo");
    });

    dom.btnAssuntoToggleAll?.addEventListener("click", (event) => {
      event.stopPropagation();
      toggleAllGlobalSelection("assunto");
    });

    dom.cargoOptions?.addEventListener("change", (event) => {
      if (!(event.target instanceof HTMLInputElement) || event.target.type !== "checkbox") {
        return;
      }
      state.filtros.cargoIds = getCheckedGlobalIds("cargo");
      updateGlobalMultiLabel("cargo");
      updateToggleAllLabel("cargo");
      scheduleAutoRefresh();
    });

    dom.assuntoOptions?.addEventListener("change", (event) => {
      if (!(event.target instanceof HTMLInputElement) || event.target.type !== "checkbox") {
        return;
      }
      state.filtros.assuntoIds = getCheckedGlobalIds("assunto");
      updateGlobalMultiLabel("assunto");
      updateToggleAllLabel("assunto");
      scheduleAutoRefresh();
    });

    dom.evolucaoGranularidadeButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const granularidade = button.getAttribute("data-granularidade") === "dia" ? "dia" : "mes";
        if (state.filtros.granularidade === granularidade) {
          return;
        }
        state.filtros.granularidade = granularidade;
        syncGranularidadeButtons();
        scheduleAutoRefresh();
      });
    });

    dom.btnQuickCargoDropdown?.addEventListener("click", (event) => {
      event.stopPropagation();
      const open = dom.quickCargoDropdownPanel.classList.contains("is-hidden");
      toggleModalMultiDropdown("cargo", open);
    });

    dom.btnQuickAssuntoDropdown?.addEventListener("click", (event) => {
      event.stopPropagation();
      const open = dom.quickAssuntoDropdownPanel.classList.contains("is-hidden");
      toggleModalMultiDropdown("assunto", open);
    });

    dom.quickCargoOptions?.addEventListener("change", (event) => {
      if (!(event.target instanceof HTMLInputElement) || event.target.type !== "checkbox") {
        return;
      }
      readModalMultiSelectionFromDom("cargo");
      updateModalMultiLabel("cargo");
    });

    dom.quickAssuntoOptions?.addEventListener("change", (event) => {
      if (!(event.target instanceof HTMLInputElement) || event.target.type !== "checkbox") {
        return;
      }
      readModalMultiSelectionFromDom("assunto");
      updateModalMultiLabel("assunto");
    });

    document.addEventListener("click", (event) => {
      if (!(event.target instanceof Node)) {
        return;
      }
      if (!dom.filtroPeriodoDropdown.contains(event.target)) {
        togglePeriodoDropdown(false);
      }
      if (dom.filtroCargoDropdown && !dom.filtroCargoDropdown.contains(event.target)) {
        toggleGlobalDropdown("cargo", false);
      }
      if (dom.filtroAssuntoDropdown && !dom.filtroAssuntoDropdown.contains(event.target)) {
        toggleGlobalDropdown("assunto", false);
      }
      if (dom.quickCargoDropdown && !dom.quickCargoDropdown.contains(event.target)) {
        toggleModalMultiDropdown("cargo", false);
      }
      if (dom.quickAssuntoDropdown && !dom.quickAssuntoDropdown.contains(event.target)) {
        toggleModalMultiDropdown("assunto", false);
      }
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        togglePeriodoDropdown(false);
        toggleGlobalDropdown("cargo", false);
        toggleGlobalDropdown("assunto", false);
        toggleModalMultiDropdown("cargo", false);
        toggleModalMultiDropdown("assunto", false);
        closeQuickAddModal();
      }
    });

    dom.themeSwitchInput.addEventListener("change", () => {
      applyTheme(dom.themeSwitchInput.checked ? "dark" : "light");
      scheduleChartSync(80);
    });

    dom.btnOpenQuickAdd.addEventListener("click", () => {
      openQuickAddModal();
    });

    dom.btnCloseQuickAdd.addEventListener("click", () => {
      closeQuickAddModal();
    });

    const btnCancelQuickAdd = document.getElementById("btn-cancel-quick-add");
    btnCancelQuickAdd?.addEventListener("click", () => {
      hideFeedback();
      closeQuickAddModal();
    });

    dom.formQuickAdd.addEventListener("submit", onSubmitQuickAdd);
    dom.btnExportCsv.addEventListener("click", exportAnaliticoCsv);
    dom.analiticoSearch.addEventListener("input", () => {
      state.analitico.busca = String(dom.analiticoSearch.value || "").trim();
      renderAnalitico();
    });

    dom.listaAnalitico.addEventListener("click", async (event) => {
      const button = event.target instanceof Element ? event.target.closest("[data-edit-id]") : null;
      if (!button) {
        return;
      }
      const id = toIntOrNull(button.getAttribute("data-edit-id"));
      if (!id) {
        return;
      }
      await openEditModal(id);
    });

    window.addEventListener("resize", () => {
      if (resizeTimer) {
        clearTimeout(resizeTimer);
      }
      resizeTimer = setTimeout(() => {
        scheduleChartSync(0);
      }, 140);
    });
  }

  function switchView(viewId) {
    const nextView = viewId === "analitico" ? "analitico" : "dashboard";
    beginLoading("Carregando página...");
    state.view = nextView;
    saveView(nextView);
    applyViewState(nextView);

    if (nextView === "dashboard") {
      scheduleChartSync(40);
      setTimeout(() => endLoading(), 120);
      return;
    }

    loadAnalitico()
      .catch((error) => {
        showFeedback(error.message || "Erro ao carregar página analítica.", "error");
      })
      .finally(() => {
        endLoading();
      });
  }

  function applyViewState(nextView) {
    dom.navButtons.forEach((button) => {
      button.classList.toggle("is-active", button.dataset.view === nextView);
    });

    dom.views.forEach((section) => {
      section.classList.toggle("is-active", section.id === `view-${nextView}`);
    });

    dom.viewTitle.textContent =
      nextView === "dashboard" ? "Ferramenta de Gestão dos Consultores de Segmento" : "Analítico de Tratativas";
  }

  async function refreshAllData(showSuccessMessage = false) {
    const keepPeriodoOpen = dom.periodoDropdownPanel && !dom.periodoDropdownPanel.classList.contains("is-hidden");
    const keepCargoOpen = dom.cargoDropdownPanel && !dom.cargoDropdownPanel.classList.contains("is-hidden");
    const keepAssuntoOpen = dom.assuntoDropdownPanel && !dom.assuntoDropdownPanel.classList.contains("is-hidden");
    readFiltersFromInputs();

    const [dashboardResult, analiticoResult] = await Promise.allSettled([loadDashboard(), loadAnalitico()]);

    if (dashboardResult.status === "rejected") {
      throw dashboardResult.reason;
    }

    if (analiticoResult.status === "rejected") {
      state.analitico.tratativas = [];
      state.analitico.total = 0;
      renderAnalitico();
      showFeedback("Não foi possível carregar a tabela analítica.", "error");
    }

    if (showSuccessMessage) {
      showFeedback("Dados atualizados.", "success");
    }

    if (keepPeriodoOpen) {
      togglePeriodoDropdown(true);
    }
    if (keepCargoOpen) {
      toggleGlobalDropdown("cargo", true);
    }
    if (keepAssuntoOpen) {
      toggleGlobalDropdown("assunto", true);
    }
  }

  async function loadDimensions() {
    const payload = await apiGet("dimensoes.php?tipo=all");
    const dados = payload.dados || {};

    state.dimensoes.usuarios = normalizeArray(dados.usuarios).map(normalizeUserName);
    state.dimensoes.tiposTratativa = normalizeArray(dados.tipos_interacao || dados.tipos_tratativa);
    state.dimensoes.assuntos = normalizeArray(dados.temas_visita || dados.assuntos);
    state.dimensoes.cargos = normalizeArray(dados.cargos);

    fillSelect(dom.filtroUsuarioGlobal, state.dimensoes.usuarios, {
      includeAll: true,
      allLabel: "Todos",
      valueKey: "id",
      labelKey: "nome",
    });

    const cargoSet = new Set(state.dimensoes.cargos.map((item) => toInt(item.id)));
    const assuntoSet = new Set(state.dimensoes.assuntos.map((item) => toInt(item.id)));
    state.filtros.cargoIds = normalizeIntArray(state.filtros.cargoIds).filter((id) => cargoSet.has(id));
    state.filtros.assuntoIds = normalizeIntArray(state.filtros.assuntoIds).filter((id) => assuntoSet.has(id));
    renderGlobalMultiOptions("cargo", state.dimensoes.cargos);
    renderGlobalMultiOptions("assunto", state.dimensoes.assuntos);

    fillSelect(dom.quickTratativaTipo, state.dimensoes.tiposTratativa, {
      valueKey: "id",
      labelKey: "nome",
    });

    fillSelect(dom.quickTratativaUsuario, state.dimensoes.usuarios, {
      valueKey: "id",
      labelKey: "nome",
    });

    renderModalMultiOptions("cargo", state.dimensoes.cargos);
    renderModalMultiOptions("assunto", state.dimensoes.assuntos);

    syncFilterInputs();
    syncGranularidadeButtons();
    updateSidebarSelectedUser();
  }

  async function loadDashboard(retryOnce = true) {
    const query = buildFiltersQuery();
    const payload = await apiGet(`dashboard.php?${query.toString()}`);
    state.dashboard = payload;

    const monthsChanged = populateMonthsSelect(payload.meses_disponiveis || []);
    renderDashboard();

    if (retryOnce && monthsChanged) {
      await loadDashboard(false);
    }
  }

  async function loadAnalitico() {
    const query = buildFiltersQuery();
    query.set("limit", "800");
    const payload = await apiGet(`tratativas.php?${query.toString()}`);
    state.analitico.tratativas = normalizeArray(payload.tratativas);
    state.analitico.total = toInt(payload.total);
    renderAnalitico();
    if (state.view === "dashboard") {
      renderWordCloud();
    }
  }

  function renderDashboard() {
    if (!state.dashboard) {
      return;
    }

    const kpis = state.dashboard.kpis || {};
    dom.kpiTotalTratativas.textContent = formatInt(kpis.total_tratativas);
    dom.kpiTotalTeams.textContent = formatInt(kpis.total_teams);
    dom.kpiTotalVisitas.textContent = formatInt(kpis.total_visitas);
    dom.kpiTotalLigacoes.textContent = formatInt(kpis.total_ligacoes);
    dom.kpiTotalUsuarios.textContent = formatInt(kpis.total_usuarios);
    updatePeriodEmptyMessage(toInt(kpis.total_tratativas) === 0);

    renderChartEvolucao();
    renderChartAssuntos();
    renderChartRosca();
    renderChartCargo();
    renderWordCloud();
    scheduleChartSync(120);
  }

  function renderAnalitico() {
    if (!dom.listaAnalitico) {
      return;
    }

    const rows = getFilteredAnaliticoRows();
    if (rows.length === 0) {
      dom.listaAnalitico.innerHTML = '<div class="empty-state">Nenhuma tratativa encontrada para os filtros atuais.</div>';
      return;
    }

    const html = rows
      .map((row) => {
        const cargoLabel = formatDimensionField(row.cargo, row.ids_cargos, state.dimensoes.cargos);
        const assuntoLabel = formatDimensionField(row.assunto, row.ids_assuntos, state.dimensoes.assuntos);
        return `
          <tr>
            <td>${escapeHtml(formatDateTime(row.data))}</td>
            <td>${escapeHtml(row.tipo_tratativa || "-")}</td>
            <td>${escapeHtml(row.usuario || "-")}</td>
            <td>${escapeHtml(cargoLabel || "-")}</td>
            <td>${escapeHtml(assuntoLabel || "-")}</td>
            <td>${escapeHtml(row.agencia || "-")}</td>
            <td>${escapeHtml(row.descricao || "-")}</td>
            <td>${escapeHtml(formatContato(row.contatos))}</td>
            <td class="table-actions">
              <button class="icon-btn" type="button" data-edit-id="${toInt(row.id)}" aria-label="Editar tratativa">&#9998;</button>
            </td>
          </tr>
        `;
      })
      .join("");

    dom.listaAnalitico.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th>Data</th>
            <th>Tipo</th>
            <th>Usuário</th>
            <th>Cargo</th>
            <th>Assunto</th>
            <th>Agência</th>
            <th>Descrição</th>
            <th>Contato</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>${html}</tbody>
      </table>
    `;
  }
  function renderChartEvolucao() {
    const data = state.dashboard || {};
    const colors = getChartCssColors();

    const granularidade = state.filtros.granularidade === "dia" ? "dia" : "mes";
    const isDiario = granularidade === "dia";
    const timelineTeams = toTimelineCountMap(normalizeArray(data.teams_timeline), granularidade);
    const timelineVisitas = toTimelineCountMap(normalizeArray(data.visitas_timeline), granularidade);
    const timelineLigacoes = toTimelineCountMap(normalizeArray(data.ligacoes_timeline), granularidade);

    const refs = isDiario ? resolveDayAxisRefs() : resolveMonthAxisRefs(data.meses_disponiveis || []);
    const labels = refs.map((ref) => (isDiario ? dayLabel(ref) : monthLabel(ref)));

    const teamsSeries = refs.map((ref) => timelineTeams[ref] || 0);
    const visitasSeries = refs.map((ref) => timelineVisitas[ref] || 0);
    const ligacoesSeries = refs.map((ref) => timelineLigacoes[ref] || 0);

    const tipo = state.filtros.tipoTratativa;
    const series = [];
    if (tipo === "all" || tipo === "teams") {
      series.push({ name: "Teams", data: teamsSeries });
    }
    if (tipo === "all" || tipo === "visitas") {
      series.push({ name: "Visitas", data: visitasSeries });
    }
    if (tipo === "all" || tipo === "ligacao") {
      series.push({ name: "Ligações", data: ligacoesSeries });
    }

    const maxValue = Math.max(1, ...series.flatMap((item) => item.data));
    const yScale = buildIntegerScale(maxValue);
    const viewportWidth = dom.chartEvolucaoScroll?.clientWidth || dom.chartEvolucao?.clientWidth || 680;
    const pointsWidth = isDiario ? 126 : 118;
    const dynamicWidth = Math.max(viewportWidth, refs.length * pointsWidth);

    const evolucaoOptions = {
      chart: {
        type: isDiario ? "bar" : "line",
        height: "100%",
        width: dynamicWidth,
        parentHeightOffset: 0,
        toolbar: { show: false },
        zoom: { enabled: false },
        stacked: isDiario,
        animations: { 
          enabled: true, 
          easing: "easeinout", 
          speed: 1300,
          animateGradually: {
            enabled: true,
            delay: 110
          },
          dynamicAnimation: {
            enabled: true,
            speed: 850
          }
        },
      },
      series,
      colors: [colors.teams, colors.visitas, colors.ligacoes],
      stroke: isDiario ? { width: 0 } : { curve: "smooth", width: 2.6 },
      markers: isDiario
        ? { size: 0 }
        : {
            size: 4.4,
            strokeWidth: 0,
            colors: [colors.teams, colors.visitas, colors.ligacoes],
            hover: { size: 6 },
          },
      dataLabels: {
        enabled: !isDiario,
        style: {
          fontSize: "11px",
          fontWeight: 700,
          colors: ["#ffffff"],
        },
        background: {
          enabled: true,
          borderRadius: 4,
          borderWidth: 0,
          foreColor: "#ffffff",
          opacity: 0.92,
        },
        formatter: (value) => formatInt(value),
      },
      grid: {
        borderColor: colors.grid,
        strokeDashArray: 4,
        padding: {
          bottom: 28,
          left: 8,
          right: 10,
          top: 4,
        },
      },
      xaxis: {
        categories: labels,
        labels: {
          style: { colors: colors.label, fontSize: isDiario ? "11px" : "12px" },
          trim: false,
          rotate: 0,
          offsetY: isDiario ? 4 : 2,
          hideOverlappingLabels: false,
          minHeight: isDiario ? 40 : 24,
          maxHeight: isDiario ? 52 : 28,
        },
        tickPlacement: "on",
      },
      yaxis: {
        min: yScale.min,
        max: yScale.max,
        tickAmount: yScale.tickAmount,
        decimalsInFloat: 0,
        forceNiceScale: true,
        title: { text: "" },
        labels: {
          style: { colors: colors.label, fontSize: "12px" },
          formatter: (value) => formatInt(Math.round(value)),
        },
      },
      legend: {
        show: true,
        position: "top",
        horizontalAlign: "left",
        labels: { colors: colors.label },
      },
      tooltip: {
        theme: document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light",
        x: {
          formatter: (_value, opts) => {
            const idx = toInt(opts?.dataPointIndex);
            const ref = refs[idx] || "";
            if (isDiario) {
              return dayLabelLong(ref);
            }
            return monthLabel(ref);
          },
        },
        y: { formatter: (value) => `${formatInt(value)} tratativa(s)` },
      },
    };

    if (isDiario) {
      evolucaoOptions.plotOptions = {
        bar: {
          horizontal: false,
          columnWidth: refs.length > 20 ? "62%" : "70%",
          borderRadius: 4,
          borderRadiusApplication: "end",
          borderRadiusWhenStacked: "last",
        },
      };
    }

    mountChart("evolucao", dom.chartEvolucao, evolucaoOptions);
  }

  function renderChartAssuntos() {
    const rows = normalizeArray(state.dashboard?.tratativas_por_assunto);
    const colors = getChartCssColors();

    if (rows.length === 0) {
      clearChart("volume");
      dom.chartTopVolume.innerHTML = '<div class="empty-state">Sem dados para o período selecionado.</div>';
      return;
    }

    const categories = rows.map((row) => String(row.assunto || "Sem assunto"));
    const teams = rows.map((row) => toInt(row.total_teams));
    const visitas = rows.map((row) => toInt(row.total_visitas));
    const ligacoes = rows.map((row) => toInt(row.total_ligacoes));
    const totalPorLinha = rows.map((row) => toInt(row.total_teams) + toInt(row.total_visitas) + toInt(row.total_ligacoes));
    const maxTotal = Math.max(1, ...totalPorLinha);
    const parentHeight = dom.chartTopVolume?.parentElement?.clientHeight || 300;
    const rowHeight = rows.length <= 5 ? 62 : rows.length <= 9 ? 52 : 44;
    const naturalHeight = rows.length * rowHeight + 78;
    const dynamicHeight = Math.max(220, Math.min(naturalHeight, Math.max(220, parentHeight - 8)));
    const barHeight = rows.length <= 4 ? "86%" : rows.length <= 7 ? "74%" : rows.length <= 10 ? "64%" : "56%";

    mountChart("volume", dom.chartTopVolume, {
      chart: {
        type: "bar",
        height: dynamicHeight,
        stacked: true,
        toolbar: { show: false },
        animations: { 
          enabled: true, 
          easing: "easeinout", 
          speed: 1300,
          animateGradually: {
            enabled: true,
            delay: 110
          },
          dynamicAnimation: {
            enabled: true,
            speed: 850
          }
        },
      },
      series: [
        { name: "Teams", data: teams },
        { name: "Visitas", data: visitas },
        { name: "Ligações", data: ligacoes },
      ],
      colors: [colors.teams, colors.visitas, colors.ligacoes],
      plotOptions: {
        bar: {
          horizontal: true,
          barHeight,
          borderRadius: 6,
          borderRadiusApplication: "end",
          borderRadiusWhenStacked: "last",
        },
      },
      dataLabels: {
        enabled: true,
        style: { fontSize: "11px", fontWeight: 700, colors: ["#ffffff"] },
        formatter: (value) => (value > 0 ? formatInt(value) : ""),
      },
      grid: {
        borderColor: colors.grid,
        strokeDashArray: 4,
      },
      xaxis: {
        categories,
        min: 0,
        max: maxTotal,
        tickAmount: Math.min(maxTotal, 6),
        labels: { show: false },
        axisBorder: { show: false },
        axisTicks: { show: false },
      },
      yaxis: {
        labels: {
          style: { colors: colors.label, fontSize: "12px" },
          maxWidth: 280,
        },
      },
      legend: {
        show: true,
        position: "top",
        horizontalAlign: "center",
        labels: { colors: colors.label },
      },
      tooltip: {
        theme: document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light",
      },
    });
  }

  function renderChartRosca() {
    const data = state.dashboard || {};
    const colors = getChartCssColors();

    const series = [
      toInt(data.kpis?.total_teams),
      toInt(data.kpis?.total_visitas),
      toInt(data.kpis?.total_ligacoes),
    ];

    mountChart("rosca", dom.chartInteracoesTipo, {
      chart: {
        type: "donut",
        height: 214,
        animations: { 
          enabled: true, 
          easing: "easeinout", 
          speed: 1300,
          animateGradually: {
            enabled: true,
            delay: 110
          },
          dynamicAnimation: {
            enabled: true,
            speed: 850
          }
        },
      },
      labels: ["Teams", "Visitas", "Ligações"],
      series,
      colors: [colors.teams, colors.visitas, colors.ligacoes],
      stroke: { width: 1.5, colors: [getComputedStyle(document.documentElement).getPropertyValue("--surface-strong").trim()] },
      legend: { show: false },
      dataLabels: {
        enabled: true,
        formatter: (value) => `${Math.round(value)}%`,
      },
      plotOptions: {
        pie: {
          donut: {
            size: "58%",
            labels: {
              show: true,
              name: { show: true, color: colors.label, fontSize: "13px" },
              value: {
                show: true,
                color: colors.label,
                fontSize: "34px",
                fontWeight: 700,
                formatter: (value) => formatInt(value),
              },
              total: {
                show: true,
                label: "Total",
                color: colors.label,
                formatter: () => formatInt(series.reduce((acc, item) => acc + item, 0)),
              },
            },
          },
        },
      },
      tooltip: {
        custom: ({ series, seriesIndex, w }) => {
          const label = String(w?.globals?.labels?.[seriesIndex] ?? "");
          const color = String(w?.globals?.colors?.[seriesIndex] ?? "#1b2563");
          const total = toInt(series?.[seriesIndex] ?? 0);
          return `
            <div class="chart-tooltip chart-tooltip-donut" style="--tooltip-bg:${color}">
              <strong>${escapeHtml(label)}</strong>
              <span>${formatInt(total)} tratativa(s)</span>
            </div>
          `;
        },
      },
    });

    if (dom.legendRosca) {
      dom.legendRosca.innerHTML = `
        <span class="chart-legend-item"><span class="chart-legend-dot" style="background:${colors.visitas}"></span>Visitas</span>
        <span class="chart-legend-item"><span class="chart-legend-dot" style="background:${colors.teams}"></span>Teams</span>
        <span class="chart-legend-item"><span class="chart-legend-dot" style="background:${colors.ligacoes}"></span>Ligações</span>
      `;
    }
  }

  function renderChartCargo() {
    const rows = normalizeArray(state.dashboard?.tratativas_por_cargo);
    const colors = getChartCssColors();

    if (rows.length === 0) {
      clearChart("cargo");
      dom.chartDemandasStatus.innerHTML = '<div class="empty-state">Sem dados de cargos para o período selecionado.</div>';
      return;
    }

    const categories = rows.map((row) => String(row.cargo || "Não informado"));
    const categoryLines = categories.map((label) => toCategoryLines(label, 18, 2));
    const teams = rows.map((row) => toInt(row.total_teams));
    const visitas = rows.map((row) => toInt(row.total_visitas));
    const ligacoes = rows.map((row) => toInt(row.total_ligacoes));
    const totalPorCargo = rows.map((row) => toInt(row.total_teams) + toInt(row.total_visitas) + toInt(row.total_ligacoes));
    const maxValue = Math.max(1, ...totalPorCargo);
    const yScale = buildIntegerScale(maxValue);
    const parentHeight = dom.chartDemandasStatusScroll?.clientHeight || dom.chartDemandasStatus?.parentElement?.clientHeight || 280;
    const dynamicHeight = Math.max(190, parentHeight - 8);
    const viewportWidth = dom.chartDemandasStatusScroll?.clientWidth || dom.chartDemandasStatus?.clientWidth || 520;
    const maxLabelSize = categories.reduce((acc, label) => Math.max(acc, String(label).length), 8);
    const perCategoryWidth = Math.max(105, Math.min(180, maxLabelSize * 4.8));
    const dynamicWidth =
      categories.length > 3
        ? Math.max(viewportWidth, categories.length * perCategoryWidth)
        : Math.max(viewportWidth, categories.length * perCategoryWidth);

    if (dom.chartDemandasStatus) {
      dom.chartDemandasStatus.style.minWidth = `${dynamicWidth}px`;
    }

    mountChart("cargo", dom.chartDemandasStatus, {
      chart: {
        type: "bar",
        height: dynamicHeight,
        width: dynamicWidth,
        stacked: true,
        toolbar: { show: false },
        animations: { 
          enabled: true, 
          easing: "easeinout", 
          speed: 1300,
          animateGradually: {
            enabled: true,
            delay: 110
          },
          dynamicAnimation: {
            enabled: true,
            speed: 850
          }
        },
      },
      series: [
        { name: "Teams", data: teams },
        { name: "Visitas", data: visitas },
        { name: "Ligações", data: ligacoes },
      ],
      colors: [colors.teams, colors.visitas, colors.ligacoes],
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "40%",
          borderRadius: 6,
          borderRadiusApplication: "end",
          borderRadiusWhenStacked: "last",
        },
      },
      dataLabels: {
        enabled: true,
        style: { fontSize: "11px", fontWeight: 700, colors: ["#ffffff"] },
        formatter: (value) => (value > 0 ? formatInt(value) : ""),
      },
      grid: {
        borderColor: colors.grid,
        strokeDashArray: 4,
        padding: {
          bottom: 18,
          left: 4,
          right: 8,
        },
      },
      xaxis: {
        categories: categoryLines,
        labels: {
          style: { colors: colors.label, fontSize: "11px" },
          rotate: 0,
          hideOverlappingLabels: false,
          trim: false,
          minHeight: 42,
          maxHeight: 58,
        },
      },
      yaxis: {
        min: yScale.min,
        max: yScale.max,
        tickAmount: yScale.tickAmount,
        labels: { show: false },
      },
      legend: {
        show: true,
        position: "top",
        horizontalAlign: "left",
        labels: { colors: colors.label },
      },
      tooltip: {
        theme: document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light",
        x: {
          formatter: (_value, opts) => categories[toInt(opts?.dataPointIndex)] || "",
        },
        y: { formatter: (value) => `${formatInt(value)} tratativa(s)` },
      },
    });
  }

  function renderWordCloud() {
    if (!dom.chartWordCloud) {
      return;
    }

    const rows = normalizeArray(state.analitico?.tratativas);
    if (rows.length === 0) {
      dom.chartWordCloud.innerHTML = '<div class="empty-state">Sem descrições para gerar a nuvem de palavras.</div>';
      return;
    }

    const stopWords = new Set([
      "a",
      "o",
      "os",
      "as",
      "um",
      "uma",
      "de",
      "da",
      "do",
      "das",
      "dos",
      "e",
      "em",
      "no",
      "na",
      "nos",
      "nas",
      "com",
      "sem",
      "para",
      "por",
      "que",
      "se",
      "ao",
      "aos",
      "à",
      "às",
      "ou",
      "mais",
      "menos",
      "sobre",
      "das",
      "dos",
      "delas",
      "deles",
      "ele",
      "ela",
      "eles",
      "elas",
      "isso",
      "esta",
      "este",
      "essa",
      "esse",
      "foi",
      "ser",
      "são",
      "não",
      "sim",
    ]);

    const counts = {};
    rows.forEach((row) => {
      const text = String(row.descricao || "");
      const tokens = text.match(/[A-Za-zÀ-ÖØ-öø-ÿ0-9]+/g) || [];
      tokens.forEach((token) => {
        const normalized = token.toLowerCase();
        if (normalized.length < 3 || stopWords.has(normalized) || /^\d+$/.test(normalized)) {
          return;
        }
        counts[normalized] = (counts[normalized] || 0) + 1;
      });
    });

    const words = Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 36);

    if (words.length === 0) {
      dom.chartWordCloud.innerHTML = '<div class="empty-state">Sem palavras relevantes nas descrições do período.</div>';
      return;
    }

    const maxCount = words[0][1];
    const minCount = words[words.length - 1][1];
    const spread = Math.max(1, maxCount - minCount);
    const palette = getChartCssColors();
    const baseColors = [palette.teams, palette.visitas, palette.ligacoes];

    const containerWidth = Math.max(240, dom.chartWordCloud.clientWidth || 780);
    const containerHeight = Math.max(120, dom.chartWordCloud.clientHeight || 150);
    const placed = [];
    const html = [];

    words.forEach(([word, count], index) => {
      const ratio = (count - minCount) / spread;
      const size = Math.round(12 + ratio * 26);
      const rotateOptions = [-24, -14, -7, 0, 7, 14, 24];
      const hash = hashString(`${word}-${count}-${index}`);
      const rotate = rotateOptions[hash % rotateOptions.length];
      const color = baseColors[index % baseColors.length];
      const boxW = Math.max(42, Math.round(size * (word.length * 0.48)));
      const boxH = Math.max(20, Math.round(size * 1.12));

      let chosen = null;
      for (let i = 0; i < 52; i += 1) {
        const x = Math.round((hash * (i + 3) * 37) % Math.max(1, containerWidth - boxW - 8));
        const y = Math.round((hash * (i + 5) * 23) % Math.max(1, containerHeight - boxH - 8));
        const collides = placed.some((item) => {
          return (
            x < item.x + item.w + 3 &&
            x + boxW + 3 > item.x &&
            y < item.y + item.h + 3 &&
            y + boxH + 3 > item.y
          );
        });
        if (!collides) {
          chosen = { x, y };
          break;
        }
      }

      if (!chosen) {
        chosen = {
          x: Math.max(0, (index * 47) % Math.max(1, containerWidth - boxW - 8)),
          y: Math.max(0, (index * 19) % Math.max(1, containerHeight - boxH - 8)),
        };
      }

      placed.push({ x: chosen.x, y: chosen.y, w: boxW, h: boxH });
      html.push(
        `<span class="wordcloud-item" style="--wc-size:${size}px;--wc-color:${color};left:${chosen.x}px;top:${chosen.y}px;transform:rotate(${rotate}deg)" title="${count} ocorrência(s)" data-count="${count} ocorrência(s)">
          ${escapeHtml(word)}
        </span>`
      );
    });

    dom.chartWordCloud.innerHTML = html.join("");
  }

  function openQuickAddModal() {
    dom.formQuickAdd.reset();
    dom.quickTratativaId.value = "";
    dom.quickModalTitle.textContent = "Nova tratativa";
    setModalSelection("cargo", []);
    setModalSelection("assunto", []);
    syncModalMultiOptions();
    toggleModalMultiDropdown("cargo", false);
    toggleModalMultiDropdown("assunto", false);
    setDefaultDateInput();

    if (state.filtros.usuarioId && hasOption(dom.quickTratativaUsuario, String(state.filtros.usuarioId))) {
      dom.quickTratativaUsuario.value = String(state.filtros.usuarioId);
    }

    const tipoDefault = tipoToId(state.filtros.tipoTratativa);
    if (tipoDefault && hasOption(dom.quickTratativaTipo, String(tipoDefault))) {
      dom.quickTratativaTipo.value = String(tipoDefault);
    }

    dom.quickAddModal.classList.remove("is-hidden");
    dom.quickAddModal.setAttribute("aria-hidden", "false");
  }

  async function openEditModal(id) {
    beginLoading("Carregando tratativa...");
    try {
      const payload = await apiGet(`tratativas.php?id=${id}`, { skipLoading: true });
      const row = payload.tratativa;
      if (!row) {
        throw new Error("Tratativa não encontrada.");
      }

      dom.quickModalTitle.textContent = "Editar tratativa";
      dom.quickTratativaId.value = String(toInt(row.id));
      dom.quickTratativaTipo.value = String(toInt(row.id_tratativa));
      dom.quickTratativaUsuario.value = String(toInt(row.id_usuario));
      const idsCargos = normalizeIntArray(row.ids_cargos || (row.id_cargo ? [row.id_cargo] : []));
      const idsAssuntos = normalizeIntArray(row.ids_assuntos || (row.id_assunto ? [row.id_assunto] : []));
      setModalSelection("cargo", idsCargos);
      setModalSelection("assunto", idsAssuntos);
      syncModalMultiOptions();
      dom.quickTratativaAgencia.value = row.agencia || "";
      dom.quickTratativaDescricao.value = row.descricao || "";
      dom.quickTratativaContato.value = formatContato(row.contatos, "");
      dom.quickTratativaData.value = toDateTimeLocalValue(row.data);

      dom.quickAddModal.classList.remove("is-hidden");
      dom.quickAddModal.setAttribute("aria-hidden", "false");
    } catch (error) {
      showFeedback(error.message || "Erro ao abrir tratativa.", "error");
    } finally {
      endLoading();
    }
  }

  function closeQuickAddModal() {
    toggleModalMultiDropdown("cargo", false);
    toggleModalMultiDropdown("assunto", false);
    dom.quickAddModal.classList.add("is-hidden");
    dom.quickAddModal.setAttribute("aria-hidden", "true");
  }

  async function onSubmitQuickAdd(event) {
    event.preventDefault();

    try {
      readModalMultiSelectionFromDom("cargo");
      readModalMultiSelectionFromDom("assunto");
      const idsCargos = getModalSelection("cargo");
      const idsAssuntos = getModalSelection("assunto");
      const payload = {
        data: normalizeDateTimeInput(dom.quickTratativaData.value),
        id_tratativa: toIntOrNull(dom.quickTratativaTipo.value),
        id_usuario: toIntOrNull(dom.quickTratativaUsuario.value),
        id_cargos: idsCargos,
        id_assuntos: idsAssuntos,
        id_cargo: idsCargos[0] ?? null,
        id_assunto: idsAssuntos[0] ?? null,
        agencia: nullableString(dom.quickTratativaAgencia.value),
        descricao: nonEmptyString(dom.quickTratativaDescricao.value),
        contatos: nullableString(dom.quickTratativaContato.value),
      };

      validateModalPayload(payload);

      const editId = toIntOrNull(dom.quickTratativaId.value);
      if (editId) {
        await apiPut("tratativas.php", { id: editId, ...payload });
      } else {
        await apiPost("tratativas.php", payload);
      }

      closeQuickAddModal();
      await refreshAllData();
      showFeedback("Tratativa salva com sucesso.", "success");
    } catch (error) {
      showFeedback(error.message || "Erro ao salvar tratativa.", "error");
    }
  }

  function validateModalPayload(payload) {
    if (!payload.data) {
      throw new Error("Informe a data da tratativa.");
    }
    if (!payload.id_tratativa) {
      throw new Error("Selecione o tipo de tratativa.");
    }
    if (!payload.id_usuario) {
      throw new Error("Selecione o usuário.");
    }
    if (!Array.isArray(payload.id_assuntos) || payload.id_assuntos.length === 0) {
      throw new Error("Selecione ao menos um assunto.");
    }
    if (!payload.descricao) {
      throw new Error("Preencha a descrição.");
    }
  }

  function renderModalMultiOptions(type, rows) {
    const list = type === "cargo" ? dom.quickCargoOptions : dom.quickAssuntoOptions;
    if (!list) {
      return;
    }

    const options = normalizeArray(rows);
    list.innerHTML = options
      .map((row) => {
        const id = toInt(row.id);
        const nome = escapeHtml(String(row.nome || ""));
        return `<label class="multi-option">
          <input type="checkbox" value="${id}" />
          <span>${nome}</span>
        </label>`;
      })
      .join("");

    updateModalMultiLabel(type);
  }

  function getModalSelection(type) {
    if (type === "cargo") {
      return normalizeIntArray(state.modalSelection.cargos);
    }
    return normalizeIntArray(state.modalSelection.assuntos);
  }

  function setModalSelection(type, ids) {
    const normalized = normalizeIntArray(ids);
    if (type === "cargo") {
      state.modalSelection.cargos = normalized;
      return;
    }
    state.modalSelection.assuntos = normalized;
  }

  function syncModalMultiOptions() {
    const cargoIds = getModalSelection("cargo").map(String);
    const assuntoIds = getModalSelection("assunto").map(String);

    Array.from(dom.quickCargoOptions?.querySelectorAll('input[type="checkbox"]') || []).forEach((input) => {
      input.checked = cargoIds.includes(input.value);
    });
    Array.from(dom.quickAssuntoOptions?.querySelectorAll('input[type="checkbox"]') || []).forEach((input) => {
      input.checked = assuntoIds.includes(input.value);
    });

    updateModalMultiLabel("cargo");
    updateModalMultiLabel("assunto");
  }

  function updateModalMultiLabel(type) {
    const isCargo = type === "cargo";
    const button = isCargo ? dom.btnQuickCargoDropdown : dom.btnQuickAssuntoDropdown;
    const rows = isCargo ? state.dimensoes.cargos : state.dimensoes.assuntos;
    const ids = getModalSelection(type);
    if (!button) {
      return;
    }

    if (ids.length === 0) {
      button.textContent = isCargo ? "Selecione cargo(s)" : "Selecione assunto(s)";
      return;
    }

    const names = ids
      .map((id) => rows.find((item) => toInt(item.id) === id)?.nome)
      .filter(Boolean);
    if (names.length <= 2) {
      button.textContent = names.join(", ");
      return;
    }
    button.textContent = `${names.slice(0, 2).join(", ")} +${names.length - 2}`;
  }

  function readModalMultiSelectionFromDom(type) {
    const list = type === "cargo" ? dom.quickCargoOptions : dom.quickAssuntoOptions;
    const selected = Array.from(list?.querySelectorAll('input[type="checkbox"]:checked') || []).map((item) => toInt(item.value));
    setModalSelection(type, selected);
  }

  function toggleModalMultiDropdown(type, open) {
    const isCargo = type === "cargo";
    const panel = isCargo ? dom.quickCargoDropdownPanel : dom.quickAssuntoDropdownPanel;
    const button = isCargo ? dom.btnQuickCargoDropdown : dom.btnQuickAssuntoDropdown;
    if (!panel || !button) {
      return;
    }
    const show = open === true;
    panel.classList.toggle("is-hidden", !show);
    button.setAttribute("aria-expanded", show ? "true" : "false");
  }

  function populateMonthsSelect(mesesDisponiveis) {
    const options = normalizeArray(mesesDisponiveis)
      .map((item) => ({
        mesRef: String(item.mes_ref || "").trim(),
        label: String(item.label || "").trim(),
      }))
      .filter((item) => /^\d{4}-(0[1-9]|1[0-2])$/.test(item.mesRef));

    const currentRef = currentMonthRef();
    if (!options.some((item) => item.mesRef === currentRef)) {
      options.unshift({ mesRef: currentRef, label: monthLabel(currentRef) });
    }

    if (options.length === 0) {
      options.push({ mesRef: currentRef, label: monthLabel(currentRef) });
    }

    const available = new Set(options.map((item) => item.mesRef));
    const before = state.filtros.meses.slice().sort().join(",");
    const fallbackMes = available.has(currentRef) ? currentRef : options[0].mesRef;

    if (!periodoDefaultInicializado) {
      state.filtros.meses = [fallbackMes];
      periodoDefaultInicializado = true;
    } else {
      const previousMonths = state.filtros.meses.slice();
      state.filtros.meses = state.filtros.meses.filter((ref) => available.has(ref));
      if (previousMonths.length > 0 && state.filtros.meses.length === 0) {
        state.filtros.meses = [fallbackMes];
      }
    }

    dom.periodoMesesOptions.innerHTML = options
      .map((item) => {
        const checked = state.filtros.meses.includes(item.mesRef) ? "checked" : "";
        const label = escapeHtml(item.label || monthLabel(item.mesRef));
        return `
          <label class="multi-option">
            <input type="checkbox" value="${escapeHtml(item.mesRef)}" ${checked} />
            <span>${label}</span>
          </label>
        `;
      })
      .join("");

    updatePeriodoDropdownLabel();
    updateToggleAllLabel("periodo");
    return before !== state.filtros.meses.slice().sort().join(",");
  }

  function updatePeriodoDropdownLabel() {
    const labels = state.filtros.meses.map((ref) => monthLabel(ref));
    if (labels.length === 0) {
      dom.btnPeriodoDropdown.textContent = "Todos os meses";
      return;
    }
    if (labels.length === 1) {
      dom.btnPeriodoDropdown.textContent = labels[0];
      return;
    }
    if (labels.length <= 2) {
      dom.btnPeriodoDropdown.textContent = labels.join(", ");
      return;
    }
    dom.btnPeriodoDropdown.textContent = `${labels.slice(0, 2).join(", ")} +${labels.length - 2}`;
  }

  function togglePeriodoDropdown(open) {
    const show = open === true;
    dom.periodoDropdownPanel.classList.toggle("is-hidden", !show);
    dom.btnPeriodoDropdown.setAttribute("aria-expanded", show ? "true" : "false");
  }

  function getCheckedMonthsFromDropdown() {
    return Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]:checked'))
      .map((item) => String(item.value || "").trim())
      .filter(Boolean);
  }

  function renderGlobalMultiOptions(type, rows) {
    const list = type === "cargo" ? dom.cargoOptions : dom.assuntoOptions;
    const selected = type === "cargo" ? state.filtros.cargoIds : state.filtros.assuntoIds;
    if (!list) {
      return;
    }

    const options = normalizeArray(rows);
    list.innerHTML = options
      .map((row) => {
        const id = toInt(row.id);
        const checked = selected.includes(id) ? "checked" : "";
        const nome = escapeHtml(String(row.nome || ""));
        return `<label class="multi-option">
          <input type="checkbox" value="${id}" ${checked} />
          <span>${nome}</span>
        </label>`;
      })
      .join("");

    updateGlobalMultiLabel(type);
    updateToggleAllLabel(type);
  }

  function syncGlobalMultiOptions(type) {
    const list = type === "cargo" ? dom.cargoOptions : dom.assuntoOptions;
    const selected = type === "cargo" ? state.filtros.cargoIds : state.filtros.assuntoIds;
    if (!list) {
      return;
    }
    const selectedStr = selected.map(String);
    Array.from(list.querySelectorAll('input[type="checkbox"]')).forEach((input) => {
      input.checked = selectedStr.includes(input.value);
    });
  }

  function getCheckedGlobalIds(type) {
    const list = type === "cargo" ? dom.cargoOptions : dom.assuntoOptions;
    return Array.from(list?.querySelectorAll('input[type="checkbox"]:checked') || [])
      .map((item) => toInt(item.value))
      .filter((id) => id > 0);
  }

  function updateGlobalMultiLabel(type) {
    const isCargo = type === "cargo";
    const rows = isCargo ? state.dimensoes.cargos : state.dimensoes.assuntos;
    const ids = isCargo ? state.filtros.cargoIds : state.filtros.assuntoIds;
    const button = isCargo ? dom.btnCargoDropdown : dom.btnAssuntoDropdown;
    if (!button) {
      return;
    }

    if (!ids || ids.length === 0) {
      button.textContent = "Todos";
      return;
    }

    const names = ids
      .map((id) => rows.find((item) => toInt(item.id) === id)?.nome)
      .filter(Boolean);
    if (names.length === 0) {
      button.textContent = "Todos";
      return;
    }
    if (names.length <= 2) {
      button.textContent = names.join(", ");
      return;
    }
    button.textContent = `${names.slice(0, 2).join(", ")} +${names.length - 2}`;
  }

  function toggleGlobalDropdown(type, open) {
    if (type === "periodo") {
      togglePeriodoDropdown(open);
      return;
    }
    const isCargo = type === "cargo";
    const panel = isCargo ? dom.cargoDropdownPanel : dom.assuntoDropdownPanel;
    const button = isCargo ? dom.btnCargoDropdown : dom.btnAssuntoDropdown;
    if (!panel || !button) {
      return;
    }
    const show = open === true;
    panel.classList.toggle("is-hidden", !show);
    button.setAttribute("aria-expanded", show ? "true" : "false");
  }

  function toggleAllGlobalSelection(type) {
    if (type === "periodo") {
      const checkboxes = Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]'));
      if (checkboxes.length === 0) {
        return;
      }
      const checkedCount = checkboxes.filter((input) => input.checked).length;
      const shouldSelectAll = checkedCount !== checkboxes.length;
      checkboxes.forEach((input) => {
        input.checked = shouldSelectAll;
      });
      state.filtros.meses = shouldSelectAll ? checkboxes.map((input) => String(input.value)) : [];
      updatePeriodoDropdownLabel();
      updateToggleAllLabel("periodo");
      if (state.filtros.meses.length > 0) {
        scheduleAutoRefresh();
      }
      return;
    }

    const isCargo = type === "cargo";
    const list = isCargo ? dom.cargoOptions : dom.assuntoOptions;
    const checkboxes = Array.from(list?.querySelectorAll('input[type="checkbox"]') || []);
    if (checkboxes.length === 0) {
      return;
    }

    const checkedCount = checkboxes.filter((input) => input.checked).length;
    const shouldSelectAll = checkedCount !== checkboxes.length;
    checkboxes.forEach((input) => {
      input.checked = shouldSelectAll;
    });

    const values = shouldSelectAll ? checkboxes.map((input) => toInt(input.value)).filter((id) => id > 0) : [];
    if (isCargo) {
      state.filtros.cargoIds = values;
      updateGlobalMultiLabel("cargo");
      updateToggleAllLabel("cargo");
    } else {
      state.filtros.assuntoIds = values;
      updateGlobalMultiLabel("assunto");
      updateToggleAllLabel("assunto");
    }
    scheduleAutoRefresh();
  }

  function updateToggleAllLabel(type) {
    if (type === "periodo") {
      if (!dom.btnPeriodoToggleAll) {
        return;
      }
      const checkboxes = Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]'));
      if (checkboxes.length === 0) {
        dom.btnPeriodoToggleAll.textContent = "Selecionar tudo";
        return;
      }
      const checkedCount = checkboxes.filter((input) => input.checked).length;
      dom.btnPeriodoToggleAll.textContent = checkedCount === checkboxes.length ? "Desmarcar tudo" : "Selecionar tudo";
      return;
    }

    const isCargo = type === "cargo";
    const button = isCargo ? dom.btnCargoToggleAll : dom.btnAssuntoToggleAll;
    const list = isCargo ? dom.cargoOptions : dom.assuntoOptions;
    if (!button || !list) {
      return;
    }
    const checkboxes = Array.from(list.querySelectorAll('input[type="checkbox"]'));
    if (checkboxes.length === 0) {
      button.textContent = "Selecionar tudo";
      return;
    }
    const checkedCount = checkboxes.filter((input) => input.checked).length;
    button.textContent = checkedCount === checkboxes.length ? "Desmarcar tudo" : "Selecionar tudo";
  }

  function scheduleAutoRefresh() {
    if (autoRefreshTimer) {
      clearTimeout(autoRefreshTimer);
    }
    autoRefreshTimer = setTimeout(() => {
      autoRefreshTimer = null;
      refreshAllData().catch((error) => {
        showFeedback(error.message || "Erro ao atualizar filtros.", "error");
      });
    }, 160);
  }

  function scheduleChartSync(delay = 80) {
    if (chartSyncTimer) {
      clearTimeout(chartSyncTimer);
    }
    chartSyncTimer = setTimeout(() => {
      chartSyncTimer = null;
      if (state.view !== "dashboard") {
        return;
      }
      [
        state.charts.evolucao,
        state.charts.volume,
        state.charts.rosca,
        state.charts.cargo,
      ].forEach((chart) => {
        if (chart && typeof chart.updateOptions === "function") {
          chart.updateOptions({}, false, true);
        }
      });
    }, delay);
  }

  function buildFiltersQuery() {
    const params = new URLSearchParams();
    if (state.filtros.usuarioId) {
      params.set("usuario_id", String(state.filtros.usuarioId));
    }
    if (state.filtros.cargoIds.length > 0) {
      params.set("cargo_ids", state.filtros.cargoIds.join(","));
    }
    if (state.filtros.assuntoIds.length > 0) {
      params.set("assunto_ids", state.filtros.assuntoIds.join(","));
    }
    params.set("tipo_tratativa", state.filtros.tipoTratativa);
    params.set("granularidade", state.filtros.granularidade === "dia" ? "dia" : "mes");
    if (state.filtros.meses.length > 0) {
      params.set("meses", state.filtros.meses.join(","));
    }
    return params;
  }

  function readFiltersFromInputs() {
    state.filtros.usuarioId = toIntOrNull(dom.filtroUsuarioGlobal.value);
    state.filtros.tipoTratativa = normalizeTipoTratativa(dom.filtroTratativaGlobal.value);
    state.filtros.cargoIds = getCheckedGlobalIds("cargo");
    state.filtros.assuntoIds = getCheckedGlobalIds("assunto");
    const meses = getCheckedMonthsFromDropdown();
    state.filtros.meses = meses;
    updateSidebarSelectedUser();
    updatePeriodoDropdownLabel();
    updateGlobalMultiLabel("cargo");
    updateGlobalMultiLabel("assunto");
    updateToggleAllLabel("periodo");
    updateToggleAllLabel("cargo");
    updateToggleAllLabel("assunto");
  }

  function syncFilterInputs() {
    dom.filtroUsuarioGlobal.value = state.filtros.usuarioId ? String(state.filtros.usuarioId) : "all";
    dom.filtroTratativaGlobal.value = normalizeTipoTratativa(state.filtros.tipoTratativa);
    Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]')).forEach((input) => {
      input.checked = state.filtros.meses.includes(input.value);
    });
    syncGlobalMultiOptions("cargo");
    syncGlobalMultiOptions("assunto");
    updatePeriodoDropdownLabel();
    updateGlobalMultiLabel("cargo");
    updateGlobalMultiLabel("assunto");
    updateToggleAllLabel("periodo");
    updateToggleAllLabel("cargo");
    updateToggleAllLabel("assunto");
    syncGranularidadeButtons();
    updateSidebarSelectedUser();
  }

  function syncGranularidadeButtons() {
    dom.evolucaoGranularidadeButtons.forEach((button) => {
      const isDia = button.getAttribute("data-granularidade") === "dia";
      button.classList.toggle("is-active", isDia ? state.filtros.granularidade === "dia" : state.filtros.granularidade !== "dia");
    });
  }

  function updateSidebarSelectedUser() {
    if (!dom.sidebarSelectedUser) {
      return;
    }

    if (!state.filtros.usuarioId) {
      dom.sidebarSelectedUser.textContent = "TODOS";
      return;
    }

    const user = state.dimensoes.usuarios.find((item) => toInt(item.id) === toInt(state.filtros.usuarioId));
    dom.sidebarSelectedUser.textContent = (user?.nome || "TODOS").toUpperCase();
  }

  function setDefaultDateInput() {
    if (!dom.quickTratativaData) {
      return;
    }
    if (dom.quickTratativaData.value) {
      return;
    }
    dom.quickTratativaData.value = toDateTimeLocalValue(new Date());
  }

  function normalizeArray(value) {
    return Array.isArray(value) ? value : [];
  }

  function updatePeriodEmptyMessage(show) {
    if (!dom.periodEmptyMessage) {
      return;
    }
    dom.periodEmptyMessage.classList.toggle("is-hidden", !show);
  }

  function normalizeUserName(row) {
    const original = String(row?.nome || "").trim();
    const normalized = original.toLowerCase();
    if (normalized === "ademar") {
      return { ...row, nome: "Ademar Liberato" };
    }
    if (normalized === "aline") {
      return { ...row, nome: "Aline Rosa" };
    }
    return row;
  }

  function fillSelect(select, rows, options = {}) {
    if (!select) {
      return;
    }

    const includeAll = options.includeAll === true;
    const allLabel = options.allLabel || "Todos";
    const optional = options.optional === true;
    const optionalLabel = options.optionalLabel || "Não informado";
    const valueKey = options.valueKey || "id";
    const labelKey = options.labelKey || "nome";

    const currentValue = select.value;
    const fragment = document.createDocumentFragment();

    if (includeAll) {
      fragment.appendChild(new Option(allLabel, "all"));
    }
    if (optional) {
      fragment.appendChild(new Option(optionalLabel, ""));
    }

    rows.forEach((row) => {
      const label = String(row[labelKey] ?? "");
      const value = String(row[valueKey] ?? "");
      fragment.appendChild(new Option(label, value));
    });

    select.innerHTML = "";
    select.appendChild(fragment);

    if (currentValue && hasOption(select, currentValue)) {
      select.value = currentValue;
    } else if (select.options.length > 0 && includeAll) {
      select.value = "all";
    }
  }

  function hasOption(select, value) {
    return Array.from(select.options).some((item) => item.value === value);
  }

  function resolveMonthAxisRefs(mesesDisponiveis) {
    const fromFilters = state.filtros.meses.slice();
    if (fromFilters.length > 0) {
      return fromFilters.slice().sort();
    }

    const refs = normalizeArray(mesesDisponiveis)
      .map((item) => String(item.mes_ref || "").trim())
      .filter((item) => /^\d{4}-(0[1-9]|1[0-2])$/.test(item))
      .sort();

    if (refs.length > 0) {
      return refs;
    }
    return [currentMonthRef()];
  }

  function resolveDayAxisRefs() {
    const fromFilters = state.filtros.meses.slice().sort();
    if (fromFilters.length === 0) {
      const today = new Date();
      return [formatDateRef(today)];
    }

    const refs = [];
    fromFilters.forEach((mesRef) => {
      const [yearText, monthText] = String(mesRef).split("-");
      const year = Number(yearText);
      const month = Number(monthText);
      if (!Number.isFinite(year) || !Number.isFinite(month)) {
        return;
      }
      const cursor = new Date(year, month - 1, 1, 0, 0, 0, 0);
      const targetMonth = month - 1;
      const now = new Date();
      const isCurrentMonth = year === now.getFullYear() && targetMonth === now.getMonth();
      const lastDay = isCurrentMonth ? now.getDate() : new Date(year, month, 0).getDate();
      while (cursor.getMonth() === targetMonth && cursor.getDate() <= lastDay) {
        refs.push(formatDateRef(cursor));
        cursor.setDate(cursor.getDate() + 1);
      }
    });

    return refs;
  }

  function toTimelineCountMap(rows, granularidade = "mes") {
    return rows.reduce((acc, row) => {
      const ref = granularidade === "dia" ? dayRefFromDate(row.data) : monthRefFromDate(row.data);
      if (!ref) {
        return acc;
      }
      acc[ref] = (acc[ref] || 0) + toInt(row.quantidade);
      return acc;
    }, {});
  }

  function dayRefFromDate(value) {
    if (!value) {
      return null;
    }

    const text = String(value);
    if (/^\d{4}-(0[1-9]|1[0-2])-\d{2}/.test(text)) {
      return text.slice(0, 10);
    }

    const date = new Date(text.replace(" ", "T"));
    if (Number.isNaN(date.getTime())) {
      return null;
    }
    return formatDateRef(date);
  }

  function monthRefFromDate(value) {
    if (!value) {
      return null;
    }

    const text = String(value);
    if (/^\d{4}-(0[1-9]|1[0-2])/.test(text)) {
      return text.slice(0, 7);
    }

    const date = new Date(text.replace(" ", "T"));
    if (Number.isNaN(date.getTime())) {
      return null;
    }

    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
  }

  function formatDateRef(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }

  function dayLabel(dayRef) {
    const date = new Date(`${dayRef}T00:00:00`);
    if (Number.isNaN(date.getTime())) {
      return dayRef;
    }
    const week = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
    return `${week[date.getDay()]} ${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}`;
  }

  function dayLabelLong(dayRef) {
    const date = new Date(`${dayRef}T00:00:00`);
    if (Number.isNaN(date.getTime())) {
      return dayRef;
    }
    const week = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
    return `${week[date.getDay()]} - ${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`;
  }

  function mountChart(key, element, options) {
    if (!window.ApexCharts || !element) {
      return;
    }

    clearChart(key);
    const chart = new ApexCharts(element, options);
    state.charts[key] = chart;
    chart.render();
  }

  function clearChart(key) {
    if (state.charts[key]) {
      state.charts[key].destroy();
      state.charts[key] = null;
    }
  }

  function getChartCssColors() {
    const styles = getComputedStyle(document.documentElement);
    return {
      visitas: styles.getPropertyValue("--chart-visitas").trim(),
      teams: styles.getPropertyValue("--chart-interacoes").trim(),
      ligacoes: styles.getPropertyValue("--chart-ligacao").trim(),
      grid: styles.getPropertyValue("--chart-grid").trim(),
      label: styles.getPropertyValue("--chart-label").trim(),
    };
  }

  function buildIntegerScale(maxValue) {
    const max = Math.max(1, Math.ceil(maxValue));
    if (max <= 12) {
      return { min: 0, max, tickAmount: max };
    }
    const rounded = Math.ceil(max / 5) * 5;
    return { min: 0, max: rounded, tickAmount: 5 };
  }
  function normalizeTipoTratativa(value) {
    const normalized = String(value || "").toLowerCase().trim();
    if (normalized === "teams") {
      return "teams";
    }
    if (normalized === "visitas") {
      return "visitas";
    }
    if (normalized === "ligacao") {
      return "ligacao";
    }
    return "all";
  }

  function tipoToId(tipo) {
    if (tipo === "teams") {
      return 1;
    }
    if (tipo === "visitas") {
      return 2;
    }
    if (tipo === "ligacao") {
      return 3;
    }
    return null;
  }

  function applyTheme(theme) {
    const finalTheme = theme === "dark" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", finalTheme);
    dom.themeSwitchInput.checked = finalTheme === "dark";
    localStorage.setItem("alidemar-theme", finalTheme);
  }

  function loadTheme() {
    return localStorage.getItem("alidemar-theme") || "light";
  }

  function saveView(view) {
    localStorage.setItem("alidemar-view", view === "analitico" ? "analitico" : "dashboard");
  }

  function loadView() {
    const stored = localStorage.getItem("alidemar-view");
    return stored === "analitico" ? "analitico" : "dashboard";
  }

  async function loadAccessContext() {
    if (dom.windowsUserEmail) {
      dom.windowsUserEmail.textContent = "Windows: validando acesso...";
    }

    const payload = await apiGet("acesso.php");
    state.acesso.autorizado = payload.autorizado === true;
    state.acesso.carregado = true;
    updateWindowsIdentityLabel(payload.identidade || null);
    return payload;
  }

  async function loadWindowsIdentityOnly() {
    if (dom.windowsUserEmail) {
      dom.windowsUserEmail.textContent = "Windows: carregando...";
    }

    try {
      const payload = await apiGet("sistema_usuario.php", { skipLoading: true });
      updateWindowsIdentityLabel(payload);
    } catch (error) {
      if (dom.windowsUserEmail) {
        dom.windowsUserEmail.textContent = "Windows: indisponível";
      }
    }
  }

  function updateWindowsIdentityLabel(identity) {
    if (!dom.windowsUserEmail) {
      return;
    }

    const email = nullableString(identity?.email);
    const usuario = nullableString(identity?.usuario);
    const funcional = nullableString(identity?.funcional);

    if (email && funcional) {
      dom.windowsUserEmail.textContent = `Windows: ${email} (${funcional})`;
      return;
    }
    if (email) {
      dom.windowsUserEmail.textContent = `Windows: ${email}`;
      return;
    }
    if (funcional) {
      dom.windowsUserEmail.textContent = `Windows: ${funcional}`;
      return;
    }
    if (usuario) {
      dom.windowsUserEmail.textContent = `Windows: ${usuario}`;
      return;
    }
    dom.windowsUserEmail.textContent = "Windows: não identificado";
  }

  function lockApplication(accessPayload) {
    if (!dom.accessOverlay) {
      return;
    }

    const funcional = nullableString(accessPayload?.funcional_login);
    const mensagemApi = nullableString(accessPayload?.mensagem);
    const titulo = "Acesso não autorizado";
    let mensagem = "Seu usuário não possui acesso a esta aplicação.";

    if (funcional) {
      mensagem = `Seu login Windows (${funcional}) não possui acesso a esta aplicação.`;
    } else if (mensagemApi) {
      mensagem = mensagemApi;
    }

    dom.accessOverlayTitle.textContent = titulo;
    dom.accessOverlayMessage.textContent = mensagem;
    dom.accessOverlay.classList.remove("is-hidden");
    dom.accessOverlay.setAttribute("aria-hidden", "false");
    document.body.classList.add("is-access-locked");
  }

  function unlockApplication() {
    if (!dom.accessOverlay) {
      return;
    }
    dom.accessOverlay.classList.add("is-hidden");
    dom.accessOverlay.setAttribute("aria-hidden", "true");
    document.body.classList.remove("is-access-locked");
  }

  function showFeedback(message, type = "success") {
    if (!dom.feedback) {
      return;
    }

    dom.feedback.textContent = message;
    dom.feedback.classList.add("is-visible");
    dom.feedback.classList.remove("success", "error");
    dom.feedback.classList.add(type === "error" ? "error" : "success");

    if (feedbackTimer) {
      clearTimeout(feedbackTimer);
    }
    feedbackTimer = setTimeout(() => {
      dom.feedback.classList.remove("is-visible");
    }, 3200);
  }

  function hideFeedback() {
    if (!dom.feedback) {
      return;
    }
    if (feedbackTimer) {
      clearTimeout(feedbackTimer);
      feedbackTimer = null;
    }
    dom.feedback.classList.remove("is-visible");
  }

  function beginLoading(message = "Carregando...") {
    loadingCounter += 1;
    setLoadingState(true, message);
  }

  function endLoading() {
    loadingCounter = Math.max(0, loadingCounter - 1);
    if (loadingCounter === 0) {
      setLoadingState(false);
    }
  }

  function setLoadingState(show, message = "Carregando...") {
    if (!dom.globalLoading) {
      return;
    }

    if (loadingHideTimer) {
      clearTimeout(loadingHideTimer);
      loadingHideTimer = null;
    }

    if (show) {
      if (dom.globalLoadingText) {
        dom.globalLoadingText.textContent = message;
      }
      dom.globalLoading.classList.remove("is-hidden");
      dom.globalLoading.setAttribute("aria-hidden", "false");
      return;
    }

    loadingHideTimer = setTimeout(() => {
      dom.globalLoading.classList.add("is-hidden");
      dom.globalLoading.setAttribute("aria-hidden", "true");
    }, 120);
  }

  async function apiGet(path, requestOptions = {}) {
    return apiRequest(path, { method: "GET" }, requestOptions);
  }

  async function apiPost(path, payload, requestOptions = {}) {
    return apiRequest(
      path,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      },
      requestOptions
    );
  }

  async function apiPut(path, payload, requestOptions = {}) {
    return apiRequest(
      path,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      },
      requestOptions
    );
  }

  async function apiRequest(path, options, requestOptions = {}) {
    const skipLoading = requestOptions.skipLoading === true;
    if (!skipLoading) {
      beginLoading("Carregando dados...");
    }

    try {
      const response = await fetch(`${API_ROOT}/${path}`, options);
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(payload.erro || `Erro ${response.status}`);
      }
      return payload;
    } finally {
      if (!skipLoading) {
        endLoading();
      }
    }
  }

  function currentMonthRef() {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  }

  function monthLabel(mesRef) {
    const [year, month] = String(mesRef).split("-");
    const monthIndex = Number(month) - 1;
    const monthName = MONTHS_PT[monthIndex] || month;
    return `${monthName} - ${year}`;
  }

  function normalizeDateTimeInput(value) {
    if (!value) {
      return null;
    }
    const normalized = value.replace("T", " ");
    return normalized.length === 16 ? `${normalized}:00` : normalized;
  }

  function toDateTimeLocalValue(value) {
    if (value instanceof Date) {
      const year = value.getFullYear();
      const month = String(value.getMonth() + 1).padStart(2, "0");
      const day = String(value.getDate()).padStart(2, "0");
      const hour = String(value.getHours()).padStart(2, "0");
      const minute = String(value.getMinutes()).padStart(2, "0");
      return `${year}-${month}-${day}T${hour}:${minute}`;
    }

    if (!value) {
      return "";
    }

    const parsed = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(parsed.getTime())) {
      return "";
    }
    return toDateTimeLocalValue(parsed);
  }

  function formatDateTime(value) {
    if (!value) {
      return "-";
    }
    const date = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(date.getTime())) {
      return String(value);
    }
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    const hour = String(date.getHours()).padStart(2, "0");
    const minute = String(date.getMinutes()).padStart(2, "0");
    return `${day}/${month}/${year} ${hour}:${minute}`;
  }

  function formatInt(value) {
    return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 }).format(toInt(value));
  }

  function toCategoryLines(text, maxChars = 16, maxLines = 3) {
    const clean = String(text || "").trim();
    if (!clean) {
      return [""];
    }
    if (clean.length <= maxChars) {
      return [clean];
    }

    const words = clean.split(/\s+/);
    const lines = [];
    let current = "";
    words.forEach((word) => {
      const next = current ? `${current} ${word}` : word;
      if (next.length > maxChars && current) {
        lines.push(current);
        current = word;
      } else {
        current = next;
      }
    });
    if (current) {
      lines.push(current);
    }

    return lines.slice(0, maxLines);
  }

  function toInt(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) {
      return 0;
    }
    return Math.trunc(number);
  }

  function hashString(input) {
    let hash = 0;
    const text = String(input || "");
    for (let i = 0; i < text.length; i += 1) {
      hash = (hash << 5) - hash + text.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash);
  }

  function toIntOrNull(value) {
    if (value === null || value === undefined) {
      return null;
    }
    const text = String(value).trim();
    if (text === "" || text.toLowerCase() === "all") {
      return null;
    }
    const number = Number(text);
    if (!Number.isFinite(number)) {
      return null;
    }
    return Math.trunc(number);
  }

  function normalizeIntArray(values) {
    if (!Array.isArray(values)) {
      return [];
    }
    const out = [];
    values.forEach((value) => {
      const intValue = toIntOrNull(value);
      if (intValue !== null && intValue > 0 && !out.includes(intValue)) {
        out.push(intValue);
      }
    });
    return out;
  }

  function nullableString(value) {
    if (value === null || value === undefined) {
      return null;
    }
    const text = String(value).trim();
    return text === "" ? null : text;
  }

  function nonEmptyString(value) {
    const text = nullableString(value);
    if (!text) {
      throw new Error("Preencha os campos obrigatórios.");
    }
    return text;
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function exportAnaliticoCsv() {
    const rows = getFilteredAnaliticoRows();
    if (rows.length === 0) {
      showFeedback("Não há dados para exportar.", "error");
      return;
    }

    const headers = ["data", "tipo_tratativa", "usuario", "cargo", "assunto", "agencia", "descricao", "contatos"];
    const lines = [headers.join(";")];

    rows.forEach((row) => {
      const cargoLabel = formatDimensionField(row.cargo, row.ids_cargos, state.dimensoes.cargos);
      const assuntoLabel = formatDimensionField(row.assunto, row.ids_assuntos, state.dimensoes.assuntos);
      const values = [
        row.data,
        row.tipo_tratativa,
        row.usuario,
        cargoLabel,
        assuntoLabel,
        row.agencia,
        row.descricao,
        formatContato(row.contatos),
      ].map((value) => `"${String(value ?? "").replaceAll('"', '""')}"`);
      lines.push(values.join(";"));
    });

    const csv = "\uFEFF" + lines.join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `tratativas_analitico_${currentMonthRef()}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function formatContato(value, emptyValue = "-") {
    const text = nullableString(value);
    if (!text) {
      return emptyValue;
    }

    try {
      const decoded = JSON.parse(text);
      if (Array.isArray(decoded)) {
        const parts = decoded
          .map((item) => {
            if (!item || typeof item !== "object") {
              return "";
            }
            const nome = nullableString(item.nome);
            const subsecao = nullableString(item.subsecao);
            if (nome && subsecao) {
              return `${nome} - ${subsecao}`;
            }
            return nome || subsecao || "";
          })
          .filter(Boolean);
        if (parts.length > 0) {
          return parts.join("; ");
        }
      }
    } catch (error) {
      return text;
    }

    return text;
  }

  function formatDimensionField(rawValue, rawIds, dimensionRows) {
    const text = nullableString(rawValue);
    if (text) {
      return text
        .split(/\s*[|,;]\s*/)
        .filter(Boolean)
        .join(" | ");
    }

    const ids = normalizeIntArray(rawIds);
    if (ids.length === 0) {
      return "-";
    }
    return ids
      .map((id) => dimensionRows.find((item) => toInt(item.id) === id)?.nome)
      .filter(Boolean)
      .join(" | ");
  }

  function getFilteredAnaliticoRows() {
    const rows = state.analitico.tratativas || [];
    const term = String(state.analitico.busca || "").trim().toLowerCase();
    if (!term) {
      return rows;
    }

    return rows.filter((row) => {
      const cargoLabel = formatDimensionField(row.cargo, row.ids_cargos, state.dimensoes.cargos);
      const assuntoLabel = formatDimensionField(row.assunto, row.ids_assuntos, state.dimensoes.assuntos);
      const all = [
        formatDateTime(row.data),
        row.tipo_tratativa,
        row.usuario,
        cargoLabel,
        assuntoLabel,
        row.agencia,
        row.descricao,
        formatContato(row.contatos),
      ]
        .map((value) => String(value || "").toLowerCase())
        .join(" | ");
      return all.includes(term);
    });
  }

})();
