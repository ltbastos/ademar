﻿<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/db.php';

init_api();

try {
    $db = db_connect();
    ensure_relation_tables($db);
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        handle_get($db);
    }
    if ($method === 'POST') {
        handle_post($db);
    }
    if ($method === 'PUT') {
        handle_put($db);
    }
    if ($method === 'DELETE') {
        handle_delete($db);
    }

    json_error('Metodo nao permitido.', 405);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}

function handle_get(mysqli $db): void
{
    $hasAgencia = has_agencia_column($db);
    $hasCargosRel = has_tratativas_cargos_table($db);
    $hasAssuntosRel = has_tratativas_assuntos_table($db);
    $agenciaSelect = $hasAgencia ? 't.agencia' : 'NULL AS agencia';
    $cargoNameSelect = $hasCargosRel
        ? '(SELECT GROUP_CONCAT(DISTINCT c2.cargo ORDER BY c2.cargo SEPARATOR " | ")
            FROM fTratativasCargos tc2
            JOIN dCargos c2 ON c2.id_cargo = tc2.id_cargo
            WHERE tc2.id_tratativa = t.id) AS cargo'
        : 'c.cargo AS cargo';
    $assuntoNameSelect = $hasAssuntosRel
        ? '(SELECT GROUP_CONCAT(DISTINCT a2.assunto ORDER BY a2.assunto SEPARATOR " | ")
            FROM fTratativasAssuntos ta2
            JOIN dAssuntos a2 ON a2.id_assunto = ta2.id_assunto
            WHERE ta2.id_tratativa = t.id) AS assunto'
        : 'a.assunto AS assunto';

    $id = to_int_or_null($_GET['id'] ?? null);
    if ($id !== null && $id > 0) {
        $row = get_tratativa($db, $id, $agenciaSelect, $cargoNameSelect, $assuntoNameSelect);
        if ($row === null) {
            json_error('Tratativa nao encontrada.', 404);
        }
        json_response(['tratativa' => $row]);
    }

    $filters = build_filters($db, $_GET);
    $whereSql = $filters['where_sql'];
    $types = $filters['types'];
    $params = $filters['params'];

    $limit = to_int_or_null($_GET['limit'] ?? 200) ?? 200;
    $limit = max(1, min(1000, $limit));

    $offset = to_int_or_null($_GET['offset'] ?? 0) ?? 0;
    $offset = max(0, $offset);

    $rows = db_query_all(
        $db,
        'SELECT
            t.id,
            t.`data`,
            t.id_tratativa,
            tt.tipo_tratativa,
            t.id_usuario,
            u.usuario,
            t.id_cargo,
            ' . $cargoNameSelect . ',
            t.id_assunto,
            ' . $assuntoNameSelect . ',
            ' . $agenciaSelect . ',
            t.descricao,
            t.contatos,
            t.criado_em,
            t.atualizado_em
         FROM fTratativas t
         JOIN dTipoTratativa tt ON tt.id_tratativa = t.id_tratativa
         JOIN dUsuarios u ON u.id_usuario = t.id_usuario
         LEFT JOIN dCargos c ON c.id_cargo = t.id_cargo
         LEFT JOIN dAssuntos a ON a.id_assunto = t.id_assunto
         WHERE ' . $whereSql . '
         ORDER BY t.`data` DESC, t.id DESC
         LIMIT ' . $limit . ' OFFSET ' . $offset,
        $types,
        $params
    );
    $rows = array_map('map_tratativa_row', $rows);

    $count = db_query_one(
        $db,
        'SELECT COUNT(*) AS total FROM fTratativas t WHERE ' . $whereSql,
        $types,
        $params
    );

    json_response([
        'tratativas' => $rows,
        'total' => (int) ($count['total'] ?? 0),
        'limit' => $limit,
        'offset' => $offset,
    ]);
}

function handle_post(mysqli $db): void
{
    $hasAgencia = has_agencia_column($db);
    $payload = json_input();
    require_fields($payload, ['data', 'id_tratativa', 'id_usuario', 'descricao']);

    $data = parse_datetime_or_null($payload['data']);
    $idTratativa = to_int_or_null($payload['id_tratativa']);
    $idUsuario = to_int_or_null($payload['id_usuario']);
    $idCargo = to_int_or_null($payload['id_cargo'] ?? null);
    $idAssunto = to_int_or_null($payload['id_assunto'] ?? null);
    $idsCargos = normalize_int_list($payload['id_cargos'] ?? ($idCargo !== null ? [$idCargo] : []));
    $idsAssuntos = normalize_int_list($payload['id_assuntos'] ?? ($idAssunto !== null ? [$idAssunto] : []));
    $idCargo = $idsCargos[0] ?? $idCargo;
    $idAssunto = $idsAssuntos[0] ?? $idAssunto;
    $agencia = to_string_or_null($payload['agencia'] ?? null);
    $descricao = to_string_or_null($payload['descricao']);
    $contatos = normalize_contatos_text($payload['contatos'] ?? null);

    validate_required_ids($idTratativa, $idUsuario, $idsAssuntos, $descricao);

    if ($hasAgencia) {
        $res = db_execute(
            $db,
            'INSERT INTO fTratativas (`data`, id_tratativa, id_usuario, id_cargo, id_assunto, agencia, descricao, contatos)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            'siiiisss',
            [$data, $idTratativa, $idUsuario, $idCargo, $idAssunto, $agencia, $descricao, $contatos]
        );
    } else {
        $res = db_execute(
            $db,
            'INSERT INTO fTratativas (`data`, id_tratativa, id_usuario, id_cargo, id_assunto, descricao, contatos)
             VALUES (?, ?, ?, ?, ?, ?, ?)',
            'siiiiss',
            [$data, $idTratativa, $idUsuario, $idCargo, $idAssunto, $descricao, $contatos]
        );
    }

    $insertId = (int) $res['insert_id'];
    sync_tratativa_relations($db, $insertId, $idsCargos, $idsAssuntos);

    $agenciaSelect = $hasAgencia ? 't.agencia' : 'NULL AS agencia';
    $cargoNameSelect = has_tratativas_cargos_table($db)
        ? '(SELECT GROUP_CONCAT(DISTINCT c2.cargo ORDER BY c2.cargo SEPARATOR " | ")
            FROM fTratativasCargos tc2
            JOIN dCargos c2 ON c2.id_cargo = tc2.id_cargo
            WHERE tc2.id_tratativa = t.id) AS cargo'
        : 'c.cargo AS cargo';
    $assuntoNameSelect = has_tratativas_assuntos_table($db)
        ? '(SELECT GROUP_CONCAT(DISTINCT a2.assunto ORDER BY a2.assunto SEPARATOR " | ")
            FROM fTratativasAssuntos ta2
            JOIN dAssuntos a2 ON a2.id_assunto = ta2.id_assunto
            WHERE ta2.id_tratativa = t.id) AS assunto'
        : 'a.assunto AS assunto';
    $row = get_tratativa($db, $insertId, $agenciaSelect, $cargoNameSelect, $assuntoNameSelect);
    json_response(['sucesso' => true, 'tratativa' => $row], 201);
}

function handle_put(mysqli $db): void
{
    $hasAgencia = has_agencia_column($db);
    $payload = json_input();
    require_fields($payload, ['id']);

    $id = to_int_or_null($payload['id']);
    if ($id === null || $id <= 0) {
        json_error('ID invalido.', 422);
    }

    $agenciaSelect = $hasAgencia ? 't.agencia' : 'NULL AS agencia';
    $cargoNameSelect = has_tratativas_cargos_table($db)
        ? '(SELECT GROUP_CONCAT(DISTINCT c2.cargo ORDER BY c2.cargo SEPARATOR " | ")
            FROM fTratativasCargos tc2
            JOIN dCargos c2 ON c2.id_cargo = tc2.id_cargo
            WHERE tc2.id_tratativa = t.id) AS cargo'
        : 'c.cargo AS cargo';
    $assuntoNameSelect = has_tratativas_assuntos_table($db)
        ? '(SELECT GROUP_CONCAT(DISTINCT a2.assunto ORDER BY a2.assunto SEPARATOR " | ")
            FROM fTratativasAssuntos ta2
            JOIN dAssuntos a2 ON a2.id_assunto = ta2.id_assunto
            WHERE ta2.id_tratativa = t.id) AS assunto'
        : 'a.assunto AS assunto';
    if (get_tratativa($db, $id, $agenciaSelect, $cargoNameSelect, $assuntoNameSelect) === null) {
        json_error('Tratativa nao encontrada.', 404);
    }

    $fields = [];
    $types = '';
    $params = [];
    $idsCargosUpdate = null;
    $idsAssuntosUpdate = null;

    if (array_key_exists('data', $payload)) {
        $fields[] = '`data` = ?';
        $types .= 's';
        $params[] = parse_datetime_or_null($payload['data']);
    }

    if (array_key_exists('id_tratativa', $payload)) {
        $idTratativa = to_int_or_null($payload['id_tratativa']);
        if ($idTratativa === null || !in_array($idTratativa, [1, 2, 3], true)) {
            json_error('id_tratativa invalido.', 422);
        }
        $fields[] = 'id_tratativa = ?';
        $types .= 'i';
        $params[] = $idTratativa;
    }

    if (array_key_exists('id_usuario', $payload)) {
        $idUsuario = to_int_or_null($payload['id_usuario']);
        if ($idUsuario === null || $idUsuario <= 0) {
            json_error('id_usuario invalido.', 422);
        }
        $fields[] = 'id_usuario = ?';
        $types .= 'i';
        $params[] = $idUsuario;
    }

    if (array_key_exists('id_cargo', $payload)) {
        $fields[] = 'id_cargo = ?';
        $types .= 'i';
        $params[] = to_int_or_null($payload['id_cargo']);
    }

    if (array_key_exists('id_cargos', $payload)) {
        $idsCargosUpdate = normalize_int_list($payload['id_cargos']);
        $fields[] = 'id_cargo = ?';
        $types .= 'i';
        $params[] = $idsCargosUpdate[0] ?? null;
    }

    if (array_key_exists('id_assunto', $payload)) {
        $idAssunto = to_int_or_null($payload['id_assunto']);
        if ($idAssunto === null || $idAssunto <= 0) {
            json_error('id_assunto invalido.', 422);
        }
        $fields[] = 'id_assunto = ?';
        $types .= 'i';
        $params[] = $idAssunto;
    }

    if (array_key_exists('id_assuntos', $payload)) {
        $idsAssuntosUpdate = normalize_int_list($payload['id_assuntos']);
        if (count($idsAssuntosUpdate) === 0) {
            json_error('id_assuntos invalido.', 422);
        }
        $fields[] = 'id_assunto = ?';
        $types .= 'i';
        $params[] = $idsAssuntosUpdate[0];
    }

    if ($hasAgencia && array_key_exists('agencia', $payload)) {
        $fields[] = 'agencia = ?';
        $types .= 's';
        $params[] = to_string_or_null($payload['agencia']);
    }

    if (array_key_exists('descricao', $payload)) {
        $descricao = to_string_or_null($payload['descricao']);
        if ($descricao === null) {
            json_error('descricao nao pode ser vazia.', 422);
        }
        $fields[] = 'descricao = ?';
        $types .= 's';
        $params[] = $descricao;
    }

    if (array_key_exists('contatos', $payload)) {
        $fields[] = 'contatos = ?';
        $types .= 's';
        $params[] = normalize_contatos_text($payload['contatos']);
    }

    if (count($fields) === 0) {
        json_error('Nenhum campo para atualizar.', 422);
    }

    $params[] = $id;
    $types .= 'i';

    db_execute(
        $db,
        'UPDATE fTratativas SET ' . implode(', ', $fields) . ' WHERE id = ?',
        $types,
        $params
    );

    sync_tratativa_relations($db, $id, $idsCargosUpdate, $idsAssuntosUpdate);
    $row = get_tratativa($db, $id, $agenciaSelect, $cargoNameSelect, $assuntoNameSelect);
    json_response(['sucesso' => true, 'tratativa' => $row]);
}

function handle_delete(mysqli $db): void
{
    $payload = json_input();
    $id = to_int_or_null($payload['id'] ?? ($_GET['id'] ?? null));

    if ($id === null || $id <= 0) {
        json_error('ID invalido para exclusao.', 422);
    }

    $res = db_execute($db, 'DELETE FROM fTratativas WHERE id = ?', 'i', [$id]);
    if ($res['affected_rows'] < 1) {
        json_error('Tratativa nao encontrada para exclusao.', 404);
    }

    json_response(['sucesso' => true, 'id' => $id]);
}

function build_filters(mysqli $db, array $source): array
{
    $where = ['1=1'];
    $types = '';
    $params = [];

    $usuarioId = to_int_or_null($source['usuario_id'] ?? null);
    if ($usuarioId !== null && $usuarioId > 0) {
        $where[] = 't.id_usuario = ?';
        $types .= 'i';
        $params[] = $usuarioId;
    }

    $tipo = to_string_or_null($source['tipo_tratativa'] ?? null);
    if ($tipo !== null && $tipo !== 'all') {
        if ($tipo === 'teams') {
            $where[] = 't.id_tratativa = 1';
        } elseif ($tipo === 'visitas') {
            $where[] = 't.id_tratativa = 2';
        } elseif ($tipo === 'ligacao') {
            $where[] = 't.id_tratativa = 3';
        }
    }

    $cargoIds = parse_int_refs($source['cargo_ids'] ?? null);
    if (count($cargoIds) === 0) {
        $singleCargo = to_int_or_null($source['cargo_id'] ?? null);
        if ($singleCargo !== null && $singleCargo > 0) {
            $cargoIds = [$singleCargo];
        }
    }
    if (count($cargoIds) > 0) {
        if (has_tratativas_cargos_table($db)) {
            $placeholders = implode(', ', array_fill(0, count($cargoIds), '?'));
            $where[] = 'EXISTS (
                SELECT 1
                FROM fTratativasCargos tc
                WHERE tc.id_tratativa = t.id
                  AND tc.id_cargo IN (' . $placeholders . ')
            )';
        } else {
            $placeholders = implode(', ', array_fill(0, count($cargoIds), '?'));
            $where[] = 't.id_cargo IN (' . $placeholders . ')';
        }
        $types .= str_repeat('i', count($cargoIds));
        $params = array_merge($params, $cargoIds);
    }

    $assuntoIds = parse_int_refs($source['assunto_ids'] ?? null);
    if (count($assuntoIds) === 0) {
        $singleAssunto = to_int_or_null($source['assunto_id'] ?? null);
        if ($singleAssunto !== null && $singleAssunto > 0) {
            $assuntoIds = [$singleAssunto];
        }
    }
    if (count($assuntoIds) > 0) {
        if (has_tratativas_assuntos_table($db)) {
            $placeholders = implode(', ', array_fill(0, count($assuntoIds), '?'));
            $where[] = 'EXISTS (
                SELECT 1
                FROM fTratativasAssuntos ta
                WHERE ta.id_tratativa = t.id
                  AND ta.id_assunto IN (' . $placeholders . ')
            )';
        } else {
            $placeholders = implode(', ', array_fill(0, count($assuntoIds), '?'));
            $where[] = 't.id_assunto IN (' . $placeholders . ')';
        }
        $types .= str_repeat('i', count($assuntoIds));
        $params = array_merge($params, $assuntoIds);
    }

    $meses = parse_month_refs($source['meses'] ?? null);
    if (count($meses) === 0) {
        $meses = [date('Y-m')];
    }
    if (count($meses) > 0) {
        $placeholders = implode(', ', array_fill(0, count($meses), '?'));
        $where[] = 'DATE_FORMAT(t.`data`, "%Y-%m") IN (' . $placeholders . ')';
        $types .= str_repeat('s', count($meses));
        $params = array_merge($params, $meses);
    }

    return [
        'where_sql' => implode(' AND ', $where),
        'types' => $types,
        'params' => $params,
    ];
}

function parse_month_refs($raw): array
{
    $text = to_string_or_null($raw);
    if ($text === null) {
        return [];
    }

    $parts = preg_split('/\s*,\s*/', $text) ?: [];
    $valid = [];

    foreach ($parts as $part) {
        if (preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $part) === 1) {
            $valid[$part] = true;
        }
    }

    return array_keys($valid);
}

function parse_int_refs($raw): array
{
    $text = to_string_or_null($raw);
    if ($text === null) {
        return [];
    }

    $parts = preg_split('/\s*,\s*/', $text) ?: [];
    $valid = [];
    foreach ($parts as $part) {
        if (preg_match('/^\d+$/', $part) !== 1) {
            continue;
        }
        $intVal = (int) $part;
        if ($intVal > 0) {
            $valid[$intVal] = true;
        }
    }
    return array_keys($valid);
}

function validate_required_ids(?int $idTratativa, ?int $idUsuario, array $idsAssuntos, ?string $descricao): void
{
    if ($idTratativa === null || !in_array($idTratativa, [1, 2, 3], true)) {
        json_error('id_tratativa invalido.', 422);
    }

    if ($idUsuario === null || $idUsuario <= 0) {
        json_error('id_usuario invalido.', 422);
    }

    if (count($idsAssuntos) === 0) {
        json_error('id_assuntos invalido.', 422);
    }

    if ($descricao === null) {
        json_error('descricao nao pode ser vazia.', 422);
    }
}

function get_tratativa(mysqli $db, int $id, string $agenciaSelect, string $cargoNameSelect, string $assuntoNameSelect): ?array
{
    $row = db_query_one(
        $db,
        'SELECT
            t.id,
            t.`data`,
            t.id_tratativa,
            tt.tipo_tratativa,
            t.id_usuario,
            u.usuario,
            t.id_cargo,
            ' . $cargoNameSelect . ',
            t.id_assunto,
            ' . $assuntoNameSelect . ',
            ' . $agenciaSelect . ',
            t.descricao,
            t.contatos,
            t.criado_em,
            t.atualizado_em
         FROM fTratativas t
         JOIN dTipoTratativa tt ON tt.id_tratativa = t.id_tratativa
         JOIN dUsuarios u ON u.id_usuario = t.id_usuario
         LEFT JOIN dCargos c ON c.id_cargo = t.id_cargo
         LEFT JOIN dAssuntos a ON a.id_assunto = t.id_assunto
         WHERE t.id = ?
         LIMIT 1',
        'i',
        [$id]
    );
    $row = map_tratativa_row($row);
    if ($row === null) {
        return null;
    }
    $row['ids_cargos'] = fetch_related_ids($db, $id, 'fTratativasCargos', 'id_cargo', $row['id_cargo'] ?? null);
    $row['ids_assuntos'] = fetch_related_ids($db, $id, 'fTratativasAssuntos', 'id_assunto', $row['id_assunto'] ?? null);
    return $row;
}

function fetch_related_ids(mysqli $db, int $idTratativa, string $tableName, string $columnName, $fallback): array
{
    if (!has_table($db, $tableName)) {
        $single = to_int_or_null($fallback);
        return $single !== null ? [$single] : [];
    }

    $rows = db_query_all(
        $db,
        'SELECT ' . $columnName . ' AS id
         FROM ' . $tableName . '
         WHERE id_tratativa = ?
         ORDER BY id',
        'i',
        [$idTratativa]
    );

    $ids = [];
    foreach ($rows as $row) {
        $id = to_int_or_null($row['id'] ?? null);
        if ($id !== null) {
            $ids[] = $id;
        }
    }
    return $ids;
}

function sync_tratativa_relations(mysqli $db, int $idTratativa, ?array $idsCargos, ?array $idsAssuntos): void
{
    if ($idsCargos !== null && has_tratativas_cargos_table($db)) {
        db_execute($db, 'DELETE FROM fTratativasCargos WHERE id_tratativa = ?', 'i', [$idTratativa]);
        foreach (normalize_int_list($idsCargos) as $idCargo) {
            db_execute(
                $db,
                'INSERT INTO fTratativasCargos (id_tratativa, id_cargo) VALUES (?, ?)',
                'ii',
                [$idTratativa, $idCargo]
            );
        }
    }

    if ($idsAssuntos !== null && has_tratativas_assuntos_table($db)) {
        db_execute($db, 'DELETE FROM fTratativasAssuntos WHERE id_tratativa = ?', 'i', [$idTratativa]);
        foreach (normalize_int_list($idsAssuntos) as $idAssunto) {
            db_execute(
                $db,
                'INSERT INTO fTratativasAssuntos (id_tratativa, id_assunto) VALUES (?, ?)',
                'ii',
                [$idTratativa, $idAssunto]
            );
        }
    }
}

function ensure_relation_tables(mysqli $db): void
{
    db_execute(
        $db,
        'CREATE TABLE IF NOT EXISTS fTratativasCargos (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            id_tratativa BIGINT UNSIGNED NOT NULL,
            id_cargo INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uk_fTratativasCargos (id_tratativa, id_cargo),
            KEY idx_fTratativasCargos_cargo (id_cargo),
            CONSTRAINT fk_fTratativasCargos_tratativa FOREIGN KEY (id_tratativa) REFERENCES fTratativas(id) ON DELETE CASCADE,
            CONSTRAINT fk_fTratativasCargos_cargo FOREIGN KEY (id_cargo) REFERENCES dCargos(id_cargo) ON DELETE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );

    db_execute(
        $db,
        'CREATE TABLE IF NOT EXISTS fTratativasAssuntos (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            id_tratativa BIGINT UNSIGNED NOT NULL,
            id_assunto INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uk_fTratativasAssuntos (id_tratativa, id_assunto),
            KEY idx_fTratativasAssuntos_assunto (id_assunto),
            CONSTRAINT fk_fTratativasAssuntos_tratativa FOREIGN KEY (id_tratativa) REFERENCES fTratativas(id) ON DELETE CASCADE,
            CONSTRAINT fk_fTratativasAssuntos_assunto FOREIGN KEY (id_assunto) REFERENCES dAssuntos(id_assunto) ON DELETE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );

    db_execute(
        $db,
        'INSERT IGNORE INTO fTratativasCargos (id_tratativa, id_cargo)
         SELECT t.id, t.id_cargo
         FROM fTratativas t
         WHERE t.id_cargo IS NOT NULL'
    );

    db_execute(
        $db,
        'INSERT IGNORE INTO fTratativasAssuntos (id_tratativa, id_assunto)
         SELECT t.id, t.id_assunto
         FROM fTratativas t
         WHERE t.id_assunto IS NOT NULL'
    );
}

function has_agencia_column(mysqli $db): bool
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }

    $row = db_query_one(
        $db,
        'SELECT 1 AS existe
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = "fTratativas"
           AND COLUMN_NAME = "agencia"
         LIMIT 1'
    );

    $cached = $row !== null;
    return $cached;
}

function has_table(mysqli $db, string $tableName): bool
{
    $row = db_query_one(
        $db,
        'SELECT 1 AS existe
         FROM INFORMATION_SCHEMA.TABLES
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
         LIMIT 1',
        's',
        [$tableName]
    );
    return $row !== null;
}

function has_tratativas_cargos_table(mysqli $db): bool
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $cached = has_table($db, 'fTratativasCargos');
    return $cached;
}

function has_tratativas_assuntos_table(mysqli $db): bool
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $cached = has_table($db, 'fTratativasAssuntos');
    return $cached;
}

function map_tratativa_row(?array $row): ?array
{
    if ($row === null) {
        return null;
    }
    $row['contatos'] = normalize_contatos_text($row['contatos'] ?? null);
    return $row;
}

function normalize_contatos_text($raw): ?string
{
    $text = to_string_or_null($raw);
    if ($text === null) {
        return null;
    }

    $decoded = json_decode($text, true);
    if (!is_array($decoded)) {
        return $text;
    }

    $parts = [];
    foreach ($decoded as $item) {
        if (is_array($item)) {
            $nome = to_string_or_null($item['nome'] ?? null);
            $subsecao = to_string_or_null($item['subsecao'] ?? null);
            if ($nome !== null && $subsecao !== null) {
                $parts[] = $nome . ' - ' . $subsecao;
            } elseif ($nome !== null) {
                $parts[] = $nome;
            }
        } elseif (is_string($item) && trim($item) !== '') {
            $parts[] = trim($item);
        }
    }

    if (count($parts) > 0) {
        return implode('; ', $parts);
    }

    return $text;
}

function normalize_int_list($raw): array
{
    if (!is_array($raw)) {
        return [];
    }

    $ids = [];
    foreach ($raw as $value) {
        $id = to_int_or_null($value);
        if ($id !== null && $id > 0 && !in_array($id, $ids, true)) {
            $ids[] = $id;
        }
    }
    return $ids;
}
