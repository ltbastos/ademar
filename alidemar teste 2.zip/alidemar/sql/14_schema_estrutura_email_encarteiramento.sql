CREATE DATABASE IF NOT EXISTS `estrutura`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `estrutura`;

SET @tem_colaboradores := (
  SELECT COUNT(*)
  FROM information_schema.tables
  WHERE table_schema = DATABASE()
    AND table_name = 'colaboradores'
);

SET @tem_email := (
  SELECT COUNT(*)
  FROM information_schema.tables
  WHERE table_schema = DATABASE()
    AND table_name = 'email'
);

SET @sql := IF(
  @tem_colaboradores = 1 AND @tem_email = 0,
  'RENAME TABLE `colaboradores` TO `email`',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS `email` (
  `id_colaborador` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `juncao` INT UNSIGNED NULL,
  `juncao_sup` INT UNSIGNED NULL,
  `posto` INT UNSIGNED NULL,
  `funcional` VARCHAR(16) NOT NULL,
  `cod_funcional` VARCHAR(16) NULL,
  `email` VARCHAR(191) NULL,
  `usuario_ad` VARCHAR(120) NULL,
  `upn_ad` VARCHAR(191) NULL,
  `dominio_ad` VARCHAR(120) NULL,
  `nome` VARCHAR(200) NOT NULL,
  `funcao` VARCHAR(120) NULL,
  `nivel` VARCHAR(20) NULL,
  `cargo` VARCHAR(200) NULL,
  `departamento` VARCHAR(200) NULL,
  `area` VARCHAR(200) NULL,
  `modificado_em` DATETIME NULL,
  `aprovador` VARCHAR(120) NULL,
  `juncoes_extras` TEXT NULL,
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_colaborador`),
  UNIQUE KEY `uk_colaboradores_funcional` (`funcional`),
  UNIQUE KEY `uk_colaboradores_cod_funcional` (`cod_funcional`),
  UNIQUE KEY `uk_colaboradores_email` (`email`),
  UNIQUE KEY `uk_email_usuario_ad` (`usuario_ad`),
  UNIQUE KEY `uk_email_upn_ad` (`upn_ad`),
  KEY `idx_email_dominio_ad` (`dominio_ad`),
  KEY `idx_colaboradores_juncao` (`juncao`),
  KEY `idx_colaboradores_juncao_sup` (`juncao_sup`),
  KEY `idx_colaboradores_funcao` (`funcao`),
  KEY `idx_colaboradores_nivel` (`nivel`),
  KEY `idx_colaboradores_departamento` (`departamento`(191)),
  KEY `idx_colaboradores_area` (`area`(191)),
  KEY `idx_colaboradores_ativo` (`ativo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @tem_usuario_ad := (
  SELECT COUNT(*)
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'email'
    AND column_name = 'usuario_ad'
);
SET @sql := IF(
  @tem_usuario_ad = 0,
  'ALTER TABLE `email` ADD COLUMN `usuario_ad` VARCHAR(120) NULL AFTER `email`',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @tem_upn_ad := (
  SELECT COUNT(*)
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'email'
    AND column_name = 'upn_ad'
);
SET @sql := IF(
  @tem_upn_ad = 0,
  'ALTER TABLE `email` ADD COLUMN `upn_ad` VARCHAR(191) NULL AFTER `usuario_ad`',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @tem_dominio_ad := (
  SELECT COUNT(*)
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'email'
    AND column_name = 'dominio_ad'
);
SET @sql := IF(
  @tem_dominio_ad = 0,
  'ALTER TABLE `email` ADD COLUMN `dominio_ad` VARCHAR(120) NULL AFTER `upn_ad`',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @tem_idx_usuario_ad := (
  SELECT COUNT(*)
  FROM information_schema.statistics
  WHERE table_schema = DATABASE()
    AND table_name = 'email'
    AND index_name = 'uk_email_usuario_ad'
);
SET @sql := IF(
  @tem_idx_usuario_ad = 0,
  'ALTER TABLE `email` ADD UNIQUE KEY `uk_email_usuario_ad` (`usuario_ad`)',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @tem_idx_upn_ad := (
  SELECT COUNT(*)
  FROM information_schema.statistics
  WHERE table_schema = DATABASE()
    AND table_name = 'email'
    AND index_name = 'uk_email_upn_ad'
);
SET @sql := IF(
  @tem_idx_upn_ad = 0,
  'ALTER TABLE `email` ADD UNIQUE KEY `uk_email_upn_ad` (`upn_ad`)',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @tem_idx_dominio_ad := (
  SELECT COUNT(*)
  FROM information_schema.statistics
  WHERE table_schema = DATABASE()
    AND table_name = 'email'
    AND index_name = 'idx_email_dominio_ad'
);
SET @sql := IF(
  @tem_idx_dominio_ad = 0,
  'ALTER TABLE `email` ADD KEY `idx_email_dominio_ad` (`dominio_ad`)',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS `encarteiramento` (
  `id_encarteiramento` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `referencia_mes` DATE NOT NULL,
  `cnpj` CHAR(14) NOT NULL,
  `cnpj_raiz` CHAR(8) NULL,
  `cliente` VARCHAR(200) NULL,
  `segmento` VARCHAR(120) NULL,
  `juncao` INT UNSIGNED NULL,
  `juncao_agencia` INT UNSIGNED NULL,
  `juncao_regional` INT UNSIGNED NULL,
  `juncao_diretoria` INT UNSIGNED NULL,
  `agencia` VARCHAR(120) NULL,
  `regional` VARCHAR(120) NULL,
  `diretoria` VARCHAR(120) NULL,
  `funcional_gerente` VARCHAR(16) NULL,
  `funcional_superior_1` VARCHAR(16) NULL,
  `funcional_superior_2` VARCHAR(16) NULL,
  `funcional_superior_3` VARCHAR(16) NULL,
  `funcional_superior_4` VARCHAR(16) NULL,
  `funcional_superior_5` VARCHAR(16) NULL,
  `origem_carga` VARCHAR(120) NULL,
  `ativo` TINYINT(1) NOT NULL DEFAULT 1,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_encarteiramento`),
  UNIQUE KEY `uk_encarteiramento_referencia_cnpj` (`referencia_mes`, `cnpj`),
  KEY `idx_encarteiramento_cnpj` (`cnpj`),
  KEY `idx_encarteiramento_cnpj_raiz` (`cnpj_raiz`),
  KEY `idx_encarteiramento_juncao` (`juncao`),
  KEY `idx_encarteiramento_juncao_agencia` (`juncao_agencia`),
  KEY `idx_encarteiramento_juncao_regional` (`juncao_regional`),
  KEY `idx_encarteiramento_juncao_diretoria` (`juncao_diretoria`),
  KEY `idx_encarteiramento_funcional_gerente` (`funcional_gerente`),
  KEY `idx_encarteiramento_funcional_superior_1` (`funcional_superior_1`),
  KEY `idx_encarteiramento_funcional_superior_2` (`funcional_superior_2`),
  KEY `idx_encarteiramento_funcional_superior_3` (`funcional_superior_3`),
  KEY `idx_encarteiramento_funcional_superior_4` (`funcional_superior_4`),
  KEY `idx_encarteiramento_funcional_superior_5` (`funcional_superior_5`),
  KEY `idx_encarteiramento_ativo` (`ativo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
