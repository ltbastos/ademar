CREATE DATABASE IF NOT EXISTS `estrutura`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `estrutura`;

INSERT INTO `email` (
  `juncao`,
  `juncao_sup`,
  `posto`,
  `funcional`,
  `cod_funcional`,
  `email`,
  `nome`,
  `funcao`,
  `nivel`,
  `cargo`,
  `departamento`,
  `area`,
  `modificado_em`,
  `aprovador`,
  `juncoes_extras`,
  `ativo`
)
VALUES (
  0,
  0,
  NULL,
  'ADMIN',
  '0000000',
  'admin@conseg.local',
  'ADMIN CONSEG PJ',
  'DP',
  'DP',
  'ADMINISTRADOR',
  'ADMINISTRACAO',
  'CONSEG PJ',
  NOW(),
  NULL,
  NULL,
  1
)
ON DUPLICATE KEY UPDATE
  `juncao` = VALUES(`juncao`),
  `juncao_sup` = VALUES(`juncao_sup`),
  `email` = VALUES(`email`),
  `nome` = VALUES(`nome`),
  `funcao` = VALUES(`funcao`),
  `nivel` = VALUES(`nivel`),
  `cargo` = VALUES(`cargo`),
  `departamento` = VALUES(`departamento`),
  `area` = VALUES(`area`),
  `modificado_em` = VALUES(`modificado_em`),
  `ativo` = VALUES(`ativo`);

SET @id_colaborador_admin := (
  SELECT id_colaborador
  FROM email
  WHERE funcional = 'ADMIN'
  LIMIT 1
);

SET @senha_hash_admin := '$2y$10$a9xQtTJZ1tkizeGvauZ28OCIzEi7Fe5/ltsqYg7ns9eJJRdAB3ro6';

INSERT INTO `auth_usuarios` (
  `id_colaborador`,
  `senha_hash`,
  `precisa_trocar_senha`,
  `ativo`
)
VALUES (
  @id_colaborador_admin,
  @senha_hash_admin,
  0,
  1
)
ON DUPLICATE KEY UPDATE
  `senha_hash` = VALUES(`senha_hash`),
  `precisa_trocar_senha` = 0,
  `ativo` = 1;

SET @id_auth_usuario_admin := (
  SELECT id_auth_usuario
  FROM auth_usuarios
  WHERE id_colaborador = @id_colaborador_admin
  LIMIT 1
);

SET @id_aplicacao_alidemar := (
  SELECT id_aplicacao
  FROM auth_aplicacoes
  WHERE codigo = 'alidemar'
  LIMIT 1
);

INSERT INTO `auth_usuario_aplicacoes` (
  `id_auth_usuario`,
  `id_aplicacao`,
  `perfil`,
  `ativo`
)
VALUES (
  @id_auth_usuario_admin,
  @id_aplicacao_alidemar,
  'admin',
  1
)
ON DUPLICATE KEY UPDATE
  `perfil` = 'admin',
  `ativo` = 1;
