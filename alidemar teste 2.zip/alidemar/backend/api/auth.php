<?php

require_once __DIR__ . '/../lib/http.php';
require_once __DIR__ . '/../lib/auth.php';

init_api();

try {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $action = to_string_or_null($_GET['action'] ?? ($_GET['acao'] ?? null)) ?? '';

    if ($method === 'GET') {
        handle_me();
    }

    if ($method === 'POST') {
        if ($action === 'primeiro-acesso') {
            handle_first_access();
        }

        if ($action === 'login' || $action === '') {
            handle_login();
        }
    }

    if ($method === 'DELETE') {
        handle_logout();
    }

    json_error('Metodo nao permitido.', 405);
} catch (Throwable $e) {
    json_error('Erro interno no servidor.', 500, ['detalhe' => $e->getMessage()]);
}

function handle_me(): void
{
    $user = auth_current_user();
    json_response([
        'autenticado' => $user !== null,
        'usuario' => $user,
        'modo_auth' => auth_mode(),
    ]);
}

function handle_login(): void
{
    $payload = json_input();
    $funcional = to_string_or_null($payload['funcional'] ?? null);
    $senha = (string) ($payload['senha'] ?? '');
    $user = auth_login((string) $funcional, $senha);

    json_response([
        'sucesso' => true,
        'mensagem' => 'Login realizado com sucesso.',
        'usuario' => $user,
    ]);
}

function handle_first_access(): void
{
    $payload = json_input();
    $funcional = to_string_or_null($payload['funcional'] ?? null);
    $email = to_string_or_null($payload['email'] ?? null);
    $senha = (string) ($payload['senha'] ?? '');
    $confirmacao = (string) ($payload['confirmacao_senha'] ?? '');

    if ($senha !== $confirmacao) {
        json_error('A confirmação da senha não confere.', 422);
    }

    $user = auth_first_access((string) $funcional, (string) $email, $senha);

    json_response([
        'sucesso' => true,
        'mensagem' => 'Primeiro acesso concluído com sucesso.',
        'usuario' => $user,
    ], 201);
}

function handle_logout(): void
{
    auth_logout();
    json_response([
        'sucesso' => true,
        'mensagem' => 'Logout realizado com sucesso.',
    ]);
}
