<?php

require_once __DIR__ . '/http.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

function app_scope_context(mysqli $dbApp, array $authUser): array
{
    static $cache = [];

    $cacheKey = (int) ($authUser['id_auth_usuario'] ?? 0);
    if ($cacheKey > 0 && isset($cache[$cacheKey])) {
        return $cache[$cacheKey];
    }

    $localUsers = db_query_all(
        $dbApp,
        'SELECT id_usuario, usuario
         FROM dUsuarios
         WHERE ativo = 1
         ORDER BY usuario ASC'
    );

    if (app_scope_has_full_access($authUser)) {
        $context = [
            'full_access' => true,
            'allowed_user_ids' => array_values(
                array_map(
                    static function (array $row): int {
                        return (int) $row['id_usuario'];
                    },
                    $localUsers
                )
            ),
            'mapped_users' => [],
            'visible_colaboradores' => [],
        ];

        if ($cacheKey > 0) {
            $cache[$cacheKey] = $context;
        }

        return $context;
    }

    $dbAuth = db_auth_connect();
    $visibleColaboradores = app_scope_visible_colaboradores($dbAuth, $authUser);
    $collaboratorsById = [];
    $normalizedNameMap = [];

    foreach ($visibleColaboradores as $row) {
        $idColaborador = (int) ($row['id_colaborador'] ?? 0);
        if ($idColaborador <= 0) {
            continue;
        }

        $normalized = app_scope_normalize_name($row['nome'] ?? '');
        $tokens = app_scope_name_tokens($row['nome'] ?? '');

        $row['_normalized_name'] = $normalized;
        $row['_tokens'] = $tokens;
        $collaboratorsById[$idColaborador] = $row;

        if ($normalized !== '') {
            if (!isset($normalizedNameMap[$normalized])) {
                $normalizedNameMap[$normalized] = [];
            }
            $normalizedNameMap[$normalized][] = $idColaborador;
        }
    }

    $aliasMap = app_scope_alias_map($dbAuth, auth_config()['app_code']);
    $allowedUserIds = [];
    $mappedUsers = [];

    foreach ($localUsers as $row) {
        $localUserId = (int) ($row['id_usuario'] ?? 0);
        if ($localUserId <= 0) {
            continue;
        }

        $matchedId = app_scope_match_local_user(
            (string) ($row['usuario'] ?? ''),
            $aliasMap,
            $collaboratorsById,
            $normalizedNameMap
        );

        if ($matchedId === null || !isset($collaboratorsById[$matchedId])) {
            continue;
        }

        $allowedUserIds[] = $localUserId;
        $mappedUsers[$localUserId] = [
            'id_colaborador' => $matchedId,
            'usuario_local' => (string) ($row['usuario'] ?? ''),
            'nome_central' => (string) ($collaboratorsById[$matchedId]['nome'] ?? ''),
        ];
    }

    $context = [
        'full_access' => false,
        'allowed_user_ids' => array_values(array_unique($allowedUserIds)),
        'mapped_users' => $mappedUsers,
        'visible_colaboradores' => array_values($collaboratorsById),
    ];

    if ($cacheKey > 0) {
        $cache[$cacheKey] = $context;
    }

    return $context;
}

function app_scope_has_full_access(array $authUser): bool
{
    $perfil = strtolower(trim((string) ($authUser['perfil_acesso'] ?? '')));

    return !empty($authUser['is_departamento'])
        || in_array($perfil, ['departamento', 'global', 'admin'], true);
}

function app_scope_effective_user_ids(array $requestedUserIds, array $scope): array
{
    if (!empty($scope['full_access'])) {
        return array_values(array_unique(array_map('intval', $requestedUserIds)));
    }

    $allowed = array_values(
        array_filter(
            array_map('intval', $scope['allowed_user_ids'] ?? []),
            static function (int $id): bool {
                return $id > 0;
            }
        )
    );

    if (count($requestedUserIds) === 0) {
        return $allowed;
    }

    $requested = array_values(
        array_filter(
            array_map('intval', $requestedUserIds),
            static function (int $id): bool {
                return $id > 0;
            }
        )
    );

    return array_values(array_intersect($requested, $allowed));
}

function app_scope_force_no_results(array $requestedUserIds, array $scope): bool
{
    if (!empty($scope['full_access'])) {
        return false;
    }

    $allowed = array_values(
        array_filter(
            array_map('intval', $scope['allowed_user_ids'] ?? []),
            static function (int $id): bool {
                return $id > 0;
            }
        )
    );

    if (count($allowed) === 0) {
        return true;
    }

    if (count($requestedUserIds) === 0) {
        return false;
    }

    return count(array_intersect($requestedUserIds, $allowed)) === 0;
}

function app_scope_assert_user_allowed(int $idUsuario, array $scope): void
{
    if (!empty($scope['full_access'])) {
        return;
    }

    $allowed = array_map('intval', $scope['allowed_user_ids'] ?? []);
    if (!in_array($idUsuario, $allowed, true)) {
        json_error('Usuario fora do escopo hierarquico.', 403);
    }
}

function app_scope_visible_colaboradores(mysqli $dbAuth, array $authUser): array
{
    $rows = db_query_all(
        $dbAuth,
        'SELECT
            id_colaborador,
            funcional,
            email,
            nome,
            funcao,
            nivel,
            cargo,
            juncao,
            juncao_sup,
            juncoes_extras,
            ativo
         FROM email
         WHERE ativo = 1
         ORDER BY nome ASC'
    );

    $viewerId = (int) ($authUser['id_colaborador'] ?? 0);
    if ($viewerId <= 0) {
        return [];
    }

    $viewerRank = app_scope_role_rank([
        'funcao' => $authUser['funcao'] ?? null,
        'nivel' => $authUser['nivel'] ?? null,
        'cargo' => $authUser['cargo'] ?? null,
    ]);

    if ($viewerRank >= 999) {
        return array_values(
            array_filter(
                $rows,
                static function (array $row) use ($viewerId): bool {
                    return (int) ($row['id_colaborador'] ?? 0) === $viewerId;
                }
            )
        );
    }

    $rowsByParentJuncao = [];
    $rowsById = [];
    foreach ($rows as $row) {
        $rowId = (int) ($row['id_colaborador'] ?? 0);
        if ($rowId <= 0) {
            continue;
        }

        $rowsById[$rowId] = $row;
        $parent = to_int_or_null($row['juncao_sup'] ?? null);
        if ($parent !== null && $parent > 0) {
            if (!isset($rowsByParentJuncao[$parent])) {
                $rowsByParentJuncao[$parent] = [];
            }
            $rowsByParentJuncao[$parent][] = $row;
        }
    }

    $visibleRows = [];
    if (isset($rowsById[$viewerId])) {
        $visibleRows[$viewerId] = $rowsById[$viewerId];
    }

    $visibleJuncoes = [];
    $queue = [];
    foreach (app_scope_collect_juncoes($authUser) as $juncao) {
        $visibleJuncoes[$juncao] = true;
        $queue[] = $juncao;
    }

    while (count($queue) > 0) {
        $parentJuncao = array_shift($queue);
        foreach ($rowsByParentJuncao[$parentJuncao] ?? [] as $row) {
            $rowId = (int) ($row['id_colaborador'] ?? 0);
            $rowRank = app_scope_role_rank($row);

            if ($rowId <= 0 || $rowId === $viewerId || $rowRank <= $viewerRank) {
                continue;
            }

            $visibleRows[$rowId] = $row;

            foreach (app_scope_collect_juncoes($row) as $juncao) {
                if (!isset($visibleJuncoes[$juncao])) {
                    $visibleJuncoes[$juncao] = true;
                    $queue[] = $juncao;
                }
            }
        }
    }

    foreach ($rows as $row) {
        $rowId = (int) ($row['id_colaborador'] ?? 0);
        if ($rowId <= 0 || isset($visibleRows[$rowId])) {
            continue;
        }

        if ($rowId === $viewerId) {
            $visibleRows[$rowId] = $row;
            continue;
        }

        $rowRank = app_scope_role_rank($row);
        if ($rowRank <= $viewerRank) {
            continue;
        }

        $rowJuncoes = app_scope_collect_juncoes($row);
        $parent = to_int_or_null($row['juncao_sup'] ?? null);

        foreach ($rowJuncoes as $juncao) {
            if (isset($visibleJuncoes[$juncao])) {
                $visibleRows[$rowId] = $row;
                continue 2;
            }
        }

        if ($parent !== null && $parent > 0 && isset($visibleJuncoes[$parent])) {
            $visibleRows[$rowId] = $row;
        }
    }

    return array_values($visibleRows);
}

function app_scope_collect_juncoes(array $row): array
{
    $juncoes = [];

    $juncao = to_int_or_null($row['juncao'] ?? null);
    if ($juncao !== null && $juncao > 0) {
        $juncoes[$juncao] = true;
    }

    $extras = $row['juncoes_extras'] ?? [];
    if (!is_array($extras)) {
        $extras = auth_parse_juncoes_extras($extras);
    }

    foreach ($extras as $extra) {
        $juncaoExtra = to_int_or_null($extra);
        if ($juncaoExtra !== null && $juncaoExtra > 0) {
            $juncoes[$juncaoExtra] = true;
        }
    }

    return array_keys($juncoes);
}

function app_scope_role_rank(array $row): int
{
    if (auth_is_departamento($row)) {
        return 0;
    }

    $texts = [
        strtolower(trim((string) ($row['funcao'] ?? ''))),
        strtolower(trim((string) ($row['cargo'] ?? ''))),
        strtolower(trim((string) ($row['nivel'] ?? ''))),
    ];

    foreach ($texts as $text) {
        $normalized = app_scope_normalize_role_text($text);
        if ($normalized === '') {
            continue;
        }

        if ($normalized === 'gc' || strpos($normalized, 'gerente de contas') !== false) {
            return 9;
        }
        if (strpos($normalized, 'diretor regional') !== false) {
            return 1;
        }
        if (strpos($normalized, 'superintendente') !== false) {
            return 2;
        }
        if (strpos($normalized, 'gerente regional') !== false) {
            return 3;
        }
        if (strpos($normalized, 'gerente executivo comercial') !== false || strpos($normalized, 'gerente executivo') !== false) {
            return 4;
        }
        if (strpos($normalized, 'gerente de agencia') !== false) {
            return 5;
        }
        if (strpos($normalized, 'gerente de plataforma') !== false) {
            return 6;
        }
        if (strpos($normalized, 'team leader') !== false) {
            return 7;
        }
        if (strpos($normalized, 'gerente de gestao') !== false) {
            return 8;
        }
        if (strpos($normalized, 'gerente de relacionamento') !== false) {
            return 9;
        }
        if (strpos($normalized, 'assistente') !== false) {
            return 10;
        }
        if (strpos($normalized, 'consultor segmento') !== false || strpos($normalized, 'consultor de segmento') !== false) {
            return 11;
        }
    }

    return 999;
}

function app_scope_alias_map(mysqli $dbAuth, string $appCode): array
{
    $rows = db_query_all(
        $dbAuth,
        'SELECT
            origem,
            alias_nome,
            id_colaborador
         FROM auth_colaborador_aliases
         WHERE ativo = 1
           AND origem IN (?, "global")
         ORDER BY CASE WHEN origem = ? THEN 0 ELSE 1 END, alias_nome ASC',
        'ss',
        [$appCode, $appCode]
    );

    $map = [];
    foreach ($rows as $row) {
        $normalized = app_scope_normalize_name($row['alias_nome'] ?? '');
        $idColaborador = (int) ($row['id_colaborador'] ?? 0);
        if ($normalized === '' || $idColaborador <= 0 || isset($map[$normalized])) {
            continue;
        }
        $map[$normalized] = $idColaborador;
    }

    return $map;
}

function app_scope_match_local_user(
    string $localName,
    array $aliasMap,
    array $collaboratorsById,
    array $normalizedNameMap
): ?int {
    $normalizedLocal = app_scope_normalize_name($localName);
    if ($normalizedLocal === '') {
        return null;
    }

    if (isset($aliasMap[$normalizedLocal]) && isset($collaboratorsById[$aliasMap[$normalizedLocal]])) {
        return (int) $aliasMap[$normalizedLocal];
    }

    $exact = $normalizedNameMap[$normalizedLocal] ?? [];
    if (count($exact) === 1) {
        return (int) $exact[0];
    }

    $localTokens = app_scope_name_tokens($localName);
    if (count($localTokens) === 0) {
        return null;
    }

    $candidates = [];
    foreach ($collaboratorsById as $idColaborador => $row) {
        $tokens = $row['_tokens'] ?? [];
        if (count(array_diff($localTokens, $tokens)) === 0) {
            $candidates[] = (int) $idColaborador;
        }
    }

    return count($candidates) === 1 ? $candidates[0] : null;
}

function app_scope_normalize_name($value): string
{
    $text = trim((string) $value);
    if ($text === '') {
        return '';
    }

    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
        if ($converted !== false) {
            $text = $converted;
        }
    }

    $text = strtoupper($text);
    $text = preg_replace('/[^A-Z0-9 ]+/', ' ', $text) ?? $text;
    $text = preg_replace('/\s+/', ' ', $text) ?? $text;
    return trim($text);
}

function app_scope_name_tokens($value): array
{
    $normalized = app_scope_normalize_name($value);
    if ($normalized === '') {
        return [];
    }

    $parts = explode(' ', $normalized);
    $ignored = ['DA', 'DE', 'DI', 'DO', 'DU', 'DAS', 'DOS', 'E'];
    $tokens = [];

    foreach ($parts as $part) {
        $token = trim($part);
        if ($token === '' || in_array($token, $ignored, true)) {
            continue;
        }
        $tokens[$token] = true;
    }

    return array_keys($tokens);
}

function app_scope_normalize_role_text(string $value): string
{
    return strtolower(app_scope_normalize_name($value));
}
