<?php

require_once __DIR__ . '/http.php';
require_once __DIR__ . '/db.php';

function auth_config(): array
{
    static $config = null;

    if (is_array($config)) {
        return $config;
    }

    $config = require __DIR__ . '/../config/auth.php';
    return $config;
}

function auth_mode(): string
{
    $mode = strtolower(trim((string) (auth_config()['mode'] ?? 'login')));
    return in_array($mode, ['login', 'disabled'], true) ? $mode : 'login';
}

function auth_is_disabled(): bool
{
    return auth_mode() === 'disabled';
}

function auth_disabled_user(): array
{
    $config = auth_config();

    return [
        'id_auth_usuario' => 0,
        'id_colaborador' => 0,
        'funcional' => null,
        'cod_funcional' => null,
        'email' => null,
        'nome' => 'Acesso direto',
        'funcao' => null,
        'nivel' => null,
        'cargo' => null,
        'departamento' => null,
        'area' => null,
        'juncao' => null,
        'juncao_sup' => null,
        'juncoes_extras' => [],
        'perfil_acesso' => 'global',
        'precisa_trocar_senha' => false,
        'ultimo_login_em' => null,
        'app_codigo' => $config['app_code'],
        'app_nome' => $config['app_name'],
        'is_departamento' => true,
        'modo_auth' => auth_mode(),
    ];
}

function auth_start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    $config = auth_config();
    $isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

    session_name($config['session_name']);
    session_set_cookie_params(0, '/', '', $isHttps, true);

    session_start();
}

function auth_current_app(mysqli $dbAuth): array
{
    static $app = null;

    if (is_array($app)) {
        return $app;
    }

    $config = auth_config();
    $app = db_query_one(
        $dbAuth,
        'SELECT id_aplicacao, codigo, nome, descricao, ativo
         FROM auth_aplicacoes
         WHERE codigo = ?
         LIMIT 1',
        's',
        [$config['app_code']]
    );

    if (!$app || (int) ($app['ativo'] ?? 0) !== 1) {
        throw new RuntimeException('Aplicacao de autenticacao nao configurada: ' . $config['app_code']);
    }

    $app['id_aplicacao'] = (int) $app['id_aplicacao'];
    $app['ativo'] = (int) $app['ativo'];
    return $app;
}

function auth_normalize_funcional($value): ?string
{
    $text = to_string_or_null($value);
    if ($text === null) {
        return null;
    }

    $clean = preg_replace('/\s+/', '', $text);
    if ($clean === null || $clean === '') {
        return null;
    }

    return strtoupper($clean);
}

function auth_normalize_email($value): ?string
{
    $text = to_string_or_null($value);
    if ($text === null) {
        return null;
    }

    return strtolower($text);
}

function auth_password_validate(string $password): void
{
    if (strlen($password) < 6) {
        json_error('A senha deve ter pelo menos 6 caracteres.', 422);
    }
}

function auth_parse_juncoes_extras($raw): array
{
    $text = to_string_or_null($raw);
    if ($text === null) {
        return [];
    }

    $parts = array_filter(array_map('trim', explode('|', $text)), static function ($value) {
        return $value !== '';
    });

    return array_values($parts);
}

function auth_is_departamento(array $row): bool
{
    return strtoupper(trim((string) ($row['funcao'] ?? ''))) === 'DP';
}

function auth_default_profile(array $row): string
{
    return auth_is_departamento($row) ? 'departamento' : 'rede';
}

function auth_client_ip(): ?string
{
    $ip = to_string_or_null($_SERVER['REMOTE_ADDR'] ?? null);
    return $ip !== null ? substr($ip, 0, 45) : null;
}

function auth_user_agent(): ?string
{
    $agent = to_string_or_null($_SERVER['HTTP_USER_AGENT'] ?? null);
    return $agent !== null ? substr($agent, 0, 255) : null;
}

function auth_record_event(mysqli $dbAuth, string $tipoEvento, array $context = []): void
{
    $app = auth_current_app($dbAuth);
    $idAuthUsuario = to_int_or_null($context['id_auth_usuario'] ?? null);
    $funcional = auth_normalize_funcional($context['funcional'] ?? null);
    $detalhe = to_string_or_null($context['detalhe'] ?? null);

    db_execute(
        $dbAuth,
        'INSERT INTO auth_eventos_login (
            id_auth_usuario,
            id_aplicacao,
            tipo_evento,
            funcional_informado,
            ip,
            user_agent,
            detalhe
         ) VALUES (?, ?, ?, ?, ?, ?, ?)',
        'iisssss',
        [
            $idAuthUsuario,
            $app['id_aplicacao'],
            $tipoEvento,
            $funcional,
            auth_client_ip(),
            auth_user_agent(),
            $detalhe,
        ]
    );
}

function auth_session_user_id(): ?int
{
    auth_start_session();
    $id = to_int_or_null($_SESSION['auth_user_id'] ?? null);
    return $id !== null && $id > 0 ? $id : null;
}

function auth_store_session(array $user): void
{
    if (auth_is_disabled()) {
        return;
    }

    auth_start_session();
    session_regenerate_id(true);
    $_SESSION['auth_user_id'] = (int) $user['id_auth_usuario'];
    $_SESSION['auth_app_code'] = auth_config()['app_code'];
    $_SESSION['auth_login_at'] = date('Y-m-d H:i:s');
}

function auth_clear_session(): void
{
    if (auth_is_disabled()) {
        return;
    }

    auth_start_session();
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
}

function auth_fetch_user_by_id(mysqli $dbAuth, int $idAuthUsuario): ?array
{
    $app = auth_current_app($dbAuth);

    $row = db_query_one(
        $dbAuth,
        'SELECT
            au.id_auth_usuario,
            au.id_colaborador,
            au.precisa_trocar_senha,
            au.ultimo_login_em,
            au.ativo AS auth_ativo,
            aua.perfil AS perfil_acesso,
            aua.ativo AS acesso_ativo,
            app.codigo AS app_codigo,
            app.nome AS app_nome,
            app.ativo AS app_ativo,
            c.funcional,
            c.cod_funcional,
            c.email,
            c.nome,
            c.funcao,
            c.nivel,
            c.cargo,
            c.departamento,
            c.area,
            c.juncao,
            c.juncao_sup,
            c.juncoes_extras,
            c.ativo AS colaborador_ativo
         FROM auth_usuarios au
         JOIN email c ON c.id_colaborador = au.id_colaborador
         JOIN auth_usuario_aplicacoes aua ON aua.id_auth_usuario = au.id_auth_usuario
         JOIN auth_aplicacoes app ON app.id_aplicacao = aua.id_aplicacao
         WHERE au.id_auth_usuario = ?
           AND app.codigo = ?
         LIMIT 1',
        'is',
        [$idAuthUsuario, $app['codigo']]
    );

    if (!$row) {
        return null;
    }

    if (
        (int) ($row['auth_ativo'] ?? 0) !== 1
        || (int) ($row['acesso_ativo'] ?? 0) !== 1
        || (int) ($row['colaborador_ativo'] ?? 0) !== 1
        || (int) ($row['app_ativo'] ?? 0) !== 1
    ) {
        return null;
    }

    return auth_public_user($row);
}

function auth_public_user(array $row): array
{
    return [
        'id_auth_usuario' => (int) $row['id_auth_usuario'],
        'id_colaborador' => (int) $row['id_colaborador'],
        'funcional' => (string) $row['funcional'],
        'cod_funcional' => to_string_or_null($row['cod_funcional'] ?? null),
        'email' => to_string_or_null($row['email'] ?? null),
        'nome' => (string) $row['nome'],
        'funcao' => to_string_or_null($row['funcao'] ?? null),
        'nivel' => to_string_or_null($row['nivel'] ?? null),
        'cargo' => to_string_or_null($row['cargo'] ?? null),
        'departamento' => to_string_or_null($row['departamento'] ?? null),
        'area' => to_string_or_null($row['area'] ?? null),
        'juncao' => to_int_or_null($row['juncao'] ?? null),
        'juncao_sup' => to_int_or_null($row['juncao_sup'] ?? null),
        'juncoes_extras' => auth_parse_juncoes_extras($row['juncoes_extras'] ?? null),
        'perfil_acesso' => to_string_or_null($row['perfil_acesso'] ?? null) ?? 'usuario',
        'precisa_trocar_senha' => (int) ($row['precisa_trocar_senha'] ?? 0) === 1,
        'ultimo_login_em' => to_string_or_null($row['ultimo_login_em'] ?? null),
        'app_codigo' => to_string_or_null($row['app_codigo'] ?? null),
        'app_nome' => to_string_or_null($row['app_nome'] ?? null),
        'is_departamento' => auth_is_departamento($row),
        'modo_auth' => auth_mode(),
    ];
}

function auth_current_user(): ?array
{
    if (auth_is_disabled()) {
        return auth_disabled_user();
    }

    auth_start_session();
    $userId = auth_session_user_id();
    $appCode = to_string_or_null($_SESSION['auth_app_code'] ?? null);

    if ($userId === null || $appCode !== auth_config()['app_code']) {
        return null;
    }

    $dbAuth = db_auth_connect();
    $user = auth_fetch_user_by_id($dbAuth, $userId);
    if ($user === null) {
        auth_clear_session();
        return null;
    }

    return $user;
}

function auth_require_user(): array
{
    $user = auth_current_user();
    if ($user === null) {
        json_error('Autenticacao necessaria.', 401);
    }

    return $user;
}

function auth_find_colaborador_by_funcional(mysqli $dbAuth, string $funcional): ?array
{
    return db_query_one(
        $dbAuth,
        'SELECT
            id_colaborador,
            funcional,
            cod_funcional,
            email,
            nome,
            funcao,
            nivel,
            cargo,
            departamento,
            area,
            juncao,
            juncao_sup,
            juncoes_extras,
            ativo
         FROM email
         WHERE funcional = ?
         LIMIT 1',
        's',
        [$funcional]
    );
}

function auth_login(string $funcional, string $senha): array
{
    if (auth_is_disabled()) {
        json_error('Login manual desativado nesta aplicação.', 403);
    }

    $dbAuth = db_auth_connect();
    $app = auth_current_app($dbAuth);
    $funcional = auth_normalize_funcional($funcional);

    if ($funcional === null || $senha === '') {
        json_error('Informe a funcional e a senha.', 422);
    }

    $row = db_query_one(
        $dbAuth,
        'SELECT
            c.id_colaborador,
            c.ativo AS colaborador_ativo,
            c.funcao,
            au.id_auth_usuario,
            au.senha_hash,
            au.ativo AS auth_ativo,
            aua.ativo AS acesso_ativo
         FROM email c
         LEFT JOIN auth_usuarios au ON au.id_colaborador = c.id_colaborador
         LEFT JOIN auth_usuario_aplicacoes aua
           ON aua.id_auth_usuario = au.id_auth_usuario
          AND aua.id_aplicacao = ?
         WHERE c.funcional = ?
         LIMIT 1',
        'is',
        [$app['id_aplicacao'], $funcional]
    );

    if (!$row || (int) ($row['colaborador_ativo'] ?? 0) !== 1) {
        auth_record_event($dbAuth, 'login_erro', [
            'funcional' => $funcional,
            'detalhe' => 'funcional_nao_encontrada',
        ]);
        json_error('Funcional ou senha inválida.', 401);
    }

    if (!isset($row['id_auth_usuario']) || to_int_or_null($row['id_auth_usuario']) === null) {
        auth_record_event($dbAuth, 'login_erro', [
            'funcional' => $funcional,
            'detalhe' => 'usuario_sem_primeiro_acesso',
        ]);
        json_error('Primeiro acesso ainda não concluído para esta funcional.', 403);
    }

    if ((int) ($row['auth_ativo'] ?? 0) !== 1) {
        auth_record_event($dbAuth, 'login_erro', [
            'id_auth_usuario' => $row['id_auth_usuario'],
            'funcional' => $funcional,
            'detalhe' => 'usuario_inativo',
        ]);
        json_error('Acesso inativo para esta funcional.', 403);
    }

    if (!password_verify($senha, (string) $row['senha_hash'])) {
        auth_record_event($dbAuth, 'login_erro', [
            'id_auth_usuario' => $row['id_auth_usuario'],
            'funcional' => $funcional,
            'detalhe' => 'senha_invalida',
        ]);
        json_error('Funcional ou senha inválida.', 401);
    }

    $acessoAtivo = to_int_or_null($row['acesso_ativo'] ?? null);
    if ($acessoAtivo === 0) {
        auth_record_event($dbAuth, 'login_erro', [
            'id_auth_usuario' => $row['id_auth_usuario'],
            'funcional' => $funcional,
            'detalhe' => 'acesso_aplicacao_inativo',
        ]);
        json_error('Acesso desativado para esta aplicação.', 403);
    }

    if ($acessoAtivo === null) {
        db_execute(
            $dbAuth,
            'INSERT INTO auth_usuario_aplicacoes (id_auth_usuario, id_aplicacao, perfil, ativo)
             VALUES (?, ?, ?, 1)
             ON DUPLICATE KEY UPDATE
               perfil = VALUES(perfil),
               ativo = 1',
            'iis',
            [(int) $row['id_auth_usuario'], $app['id_aplicacao'], auth_default_profile($row)]
        );
    }

    db_execute(
        $dbAuth,
        'UPDATE auth_usuarios
         SET ultimo_login_em = NOW(), ultimo_login_ip = ?
         WHERE id_auth_usuario = ?',
        'si',
        [auth_client_ip(), (int) $row['id_auth_usuario']]
    );

    $user = auth_fetch_user_by_id($dbAuth, (int) $row['id_auth_usuario']);
    if ($user === null) {
        json_error('Falha ao carregar o perfil autenticado.', 500);
    }

    auth_store_session($user);
    auth_record_event($dbAuth, 'login_ok', [
        'id_auth_usuario' => $user['id_auth_usuario'],
        'funcional' => $user['funcional'],
    ]);

    return $user;
}

function auth_first_access(string $funcional, string $email, string $senha): array
{
    if (auth_is_disabled()) {
        json_error('Login manual desativado nesta aplicação.', 403);
    }

    $dbAuth = db_auth_connect();
    $app = auth_current_app($dbAuth);
    $funcional = auth_normalize_funcional($funcional);
    $email = auth_normalize_email($email);

    if ($funcional === null || $email === null || $senha === '') {
        json_error('Informe funcional, e-mail e senha.', 422);
    }

    auth_password_validate($senha);

    $colaborador = db_query_one(
        $dbAuth,
        'SELECT
            id_colaborador,
            funcional,
            email,
            funcao,
            ativo
         FROM email
         WHERE funcional = ?
           AND email = ?
         LIMIT 1',
        'ss',
        [$funcional, $email]
    );

    if (!$colaborador || (int) ($colaborador['ativo'] ?? 0) !== 1) {
        auth_record_event($dbAuth, 'primeiro_acesso_erro', [
            'funcional' => $funcional,
            'detalhe' => 'colaborador_nao_encontrado',
        ]);
        json_error('Funcional e e-mail não conferem com a base central.', 404);
    }

    $existing = db_query_one(
        $dbAuth,
        'SELECT id_auth_usuario
         FROM auth_usuarios
         WHERE id_colaborador = ?
         LIMIT 1',
        'i',
        [(int) $colaborador['id_colaborador']]
    );

    $passwordHash = password_hash($senha, PASSWORD_DEFAULT);
    if ($passwordHash === false) {
        json_error('Não foi possível gerar a senha segura.', 500);
    }

    if ($existing) {
        auth_record_event($dbAuth, 'primeiro_acesso_erro', [
            'id_auth_usuario' => $existing['id_auth_usuario'],
            'funcional' => $funcional,
            'detalhe' => 'senha_ja_cadastrada',
        ]);
        json_error('Esta funcional já possui senha cadastrada. Use o login normal.', 409);
    }

    $created = db_execute(
        $dbAuth,
        'INSERT INTO auth_usuarios (id_colaborador, senha_hash, precisa_trocar_senha, ativo)
         VALUES (?, ?, 0, 1)',
        'is',
        [(int) $colaborador['id_colaborador'], $passwordHash]
    );
    $idAuthUsuario = (int) $created['insert_id'];

    db_execute(
        $dbAuth,
        'INSERT INTO auth_usuario_aplicacoes (id_auth_usuario, id_aplicacao, perfil, ativo)
         VALUES (?, ?, ?, 1)
         ON DUPLICATE KEY UPDATE
           perfil = VALUES(perfil),
           ativo = 1',
        'iis',
        [$idAuthUsuario, $app['id_aplicacao'], auth_default_profile($colaborador)]
    );

    auth_record_event($dbAuth, 'primeiro_acesso_ok', [
        'id_auth_usuario' => $idAuthUsuario,
        'funcional' => $funcional,
    ]);

    return auth_login($funcional, $senha);
}

function auth_logout(): void
{
    if (auth_is_disabled()) {
        return;
    }

    $dbAuth = db_auth_connect();
    $user = auth_current_user();
    if ($user !== null) {
        auth_record_event($dbAuth, 'logout', [
            'id_auth_usuario' => $user['id_auth_usuario'],
            'funcional' => $user['funcional'],
        ]);
    }

    auth_clear_session();
}
