<?php

$config = require __DIR__ . '/database.php';

$config['database'] = 'estrutura';
$config['app_code'] = 'alidemar';
$config['app_name'] = 'Conseg PJ';
$config['session_name'] = 'ALIDEMARSESSID';
$config['mode'] = 'disabled';

return $config;
