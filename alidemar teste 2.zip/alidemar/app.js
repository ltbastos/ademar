﻿
(() => {
  const API_ROOT = "backend/api";
  const MONTHS_PT = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
  const MOBILE_FILTER_BREAKPOINT = 760;

  const state = {
    auth: {
      user: null,
      mode: "login",
    },
    identity: null,
    view: "dashboard",
    filtros: {
      meses: [currentMonthRef()],
      usuarioIds: [],
      tipoTratativaIds: [],
      cargoIds: [],
      assuntoIds: [],
      granularidade: "dia",
      evolucaoModo: "tratativas",
    },
    dimensoes: {
      usuarios: [],
      tiposTratativa: [],
      assuntos: [],
      cargos: [],
    },
    dashboard: null,
    analitico: {
      tratativas: [],
      total: 0,
      busca: "",
    },
    modalSelection: {
      cargos: [],
      assuntos: [],
    },
    charts: {},
  };

  const dom = {};
  let feedbackTimer = null;
  let loadingCounter = 0;
  let loadingHideTimer = null;
  let autoRefreshTimer = null;
  let resizeTimer = null;
  let chartSyncTimer = null;
  let themeRefreshTimer = null;
  let periodoDefaultInicializado = false;
  let confirmResolver = null;
  let appInitialized = false;
  let authSubmitting = false;

  document.addEventListener("DOMContentLoaded", init);

  async function init() {
    cacheDom();
    bindEvents();
    applyTheme(loadTheme());
    setAuthMode("login");

    try {
      const payload = await apiGet("auth.php", { skipLoading: true, allowUnauthorized: true });
      if (payload?.autenticado && payload.usuario) {
        state.auth.user = payload.usuario;
        renderAuthenticatedUser();
        await initializeApplication();
        return;
      }
    } catch (error) {
      showAuthFeedback(error.message || "Não foi possível validar sua sessão.", "error");
    }

    showAuthScreen();
  }

  async function initializeApplication() {
    showAppShell();
    renderAuthenticatedUser();

    if (appInitialized) {
      return;
    }

    appInitialized = true;
    syncResponsiveLayout();
    const initialView = loadView();
    state.view = initialView;
    applyViewState(initialView);
    setDefaultDateInput();
    beginLoading("Inicializando painel...");

    try {
      try {
        await loadSystemIdentity();
      } catch (_error) {
        state.identity = null;
        renderSystemIdentity();
      }
      await loadDimensions();
      await refreshAllData();
      syncFilterInputs();
      if (state.view === "dashboard") {
        scheduleChartSync(120);
      }
      if (document.fonts && document.fonts.ready) {
        document.fonts.ready
          .then(() => {
            if (state.view === "dashboard") {
              scheduleChartSync(80);
            }
          })
          .catch(() => {});
      }
    } catch (error) {
      showFeedback(error.message || "Erro ao carregar aplicação.", "error");
    } finally {
      endLoading();
    }
  }

  function cacheDom() {
    dom.authScreen = document.getElementById("auth-screen");
    dom.authFeedback = document.getElementById("auth-feedback");
    dom.btnAuthModeLogin = document.getElementById("btn-auth-mode-login");
    dom.btnAuthModeSetup = document.getElementById("btn-auth-mode-setup");
    dom.formLogin = document.getElementById("form-login");
    dom.formSetup = document.getElementById("form-setup");
    dom.loginFuncional = document.getElementById("login-funcional");
    dom.loginSenha = document.getElementById("login-senha");
    dom.btnAuthLogin = document.getElementById("btn-auth-login");
    dom.setupFuncional = document.getElementById("setup-funcional");
    dom.setupEmail = document.getElementById("setup-email");
    dom.setupSenha = document.getElementById("setup-senha");
    dom.setupConfirmacaoSenha = document.getElementById("setup-confirmacao-senha");
    dom.btnAuthSetup = document.getElementById("btn-auth-setup");

    dom.appLayout = document.getElementById("app-layout");
    dom.navButtons = Array.from(document.querySelectorAll(".nav-btn"));
    dom.views = Array.from(document.querySelectorAll(".view"));
    dom.viewTitle = document.getElementById("view-title");
    dom.sidebar = document.querySelector(".sidebar");
    dom.sidebarBrand = dom.sidebar?.querySelector(".brand");
    dom.sidebarPages = dom.sidebar?.querySelector(".sidebar-pages");
    dom.sidebarFilters = dom.sidebar?.querySelector(".sidebar-filters");
    dom.sidebarIdentity = dom.sidebar?.querySelector(".sidebar-identity");
    dom.mobileFiltersHost = document.getElementById("mobile-filters-host");

    dom.feedback = document.getElementById("global-feedback");
    dom.periodEmptyMessage = document.getElementById("period-empty-message");
    dom.globalLoading = document.getElementById("global-loading");
    dom.globalLoadingText = document.getElementById("global-loading-text");

    dom.sidebarSelectedUser = document.getElementById("sidebar-selected-user");
    dom.authUserChip = document.getElementById("auth-user-chip");
    dom.authUserName = document.getElementById("auth-user-name");
    dom.authUserMeta = document.getElementById("auth-user-meta");
    dom.identityNote = document.getElementById("identity-note");
    dom.identityUser = document.getElementById("identity-user");
    dom.identityUsername = document.getElementById("identity-username");
    dom.identityGroupsCount = document.getElementById("identity-groups-count");
    dom.identityComputer = document.getElementById("identity-computer");
    dom.identityDomain = document.getElementById("identity-domain");
    dom.identityLogonserver = document.getElementById("identity-logonserver");
    dom.identityGroups = document.getElementById("identity-groups");

    dom.themeSwitchInput = document.getElementById("theme-switch-input");
    dom.btnOpenQuickAdd = document.getElementById("btn-open-quick-add");
    dom.btnLogout = document.getElementById("btn-logout");

    dom.filtroPeriodoDropdown = document.getElementById("filtro-periodo-dropdown");
    dom.btnPeriodoDropdown = document.getElementById("btn-periodo-dropdown");
    dom.btnPeriodoToggleAll = document.getElementById("btn-periodo-toggle-all");
    dom.periodoDropdownPanel = document.getElementById("periodo-dropdown-panel");
    dom.periodoMesesOptions = document.getElementById("periodo-meses-options");

    dom.filtroUsuarioDropdown = document.getElementById("filtro-usuario-dropdown");
    dom.btnUsuarioDropdown = document.getElementById("btn-usuario-dropdown");
    dom.btnUsuarioToggleAll = document.getElementById("btn-usuario-toggle-all");
    dom.usuarioDropdownPanel = document.getElementById("usuario-dropdown-panel");
    dom.usuarioOptions = document.getElementById("usuario-options");
    dom.filtroTratativaDropdown = document.getElementById("filtro-tratativa-dropdown");
    dom.btnTratativaDropdown = document.getElementById("btn-tratativa-dropdown");
    dom.btnTratativaToggleAll = document.getElementById("btn-tratativa-toggle-all");
    dom.tratativaDropdownPanel = document.getElementById("tratativa-dropdown-panel");
    dom.tratativaOptions = document.getElementById("tratativa-options");
    dom.filtroCargoDropdown = document.getElementById("filtro-cargo-dropdown");
    dom.btnCargoDropdown = document.getElementById("btn-cargo-dropdown");
    dom.btnCargoToggleAll = document.getElementById("btn-cargo-toggle-all");
    dom.cargoDropdownPanel = document.getElementById("cargo-dropdown-panel");
    dom.cargoOptions = document.getElementById("cargo-options");
    dom.filtroAssuntoDropdown = document.getElementById("filtro-assunto-dropdown");
    dom.btnAssuntoDropdown = document.getElementById("btn-assunto-dropdown");
    dom.btnAssuntoToggleAll = document.getElementById("btn-assunto-toggle-all");
    dom.assuntoDropdownPanel = document.getElementById("assunto-dropdown-panel");
    dom.assuntoOptions = document.getElementById("assunto-options");
    dom.evolucaoGranularidadeButtons = Array.from(document.querySelectorAll("[data-granularidade]"));
    dom.evolucaoModoButtons = Array.from(document.querySelectorAll("[data-evolucao-modo]"));
    dom.chartEvolucaoTitle = document.getElementById("chart-evolucao-title");

    dom.kpiTotalTratativas = document.getElementById("kpi-total-tratativas");
    dom.kpiTotalTeams = document.getElementById("kpi-total-teams");
    dom.kpiTotalVisitas = document.getElementById("kpi-total-visitas");
    dom.kpiTotalLigacoes = document.getElementById("kpi-total-ligacoes");
    dom.kpiTotalEvento = document.getElementById("kpi-total-evento");
    dom.kpiTotalLive = document.getElementById("kpi-total-live");
    dom.kpiTotalAlcance = document.getElementById("kpi-total-alcance");

    dom.chartEvolucaoScroll = document.getElementById("chart-evolucao-scroll");
    dom.chartEvolucao = document.getElementById("chart-evolucao");
    dom.chartTopVolume = document.getElementById("chart-top-volume");
    dom.chartInteracoesTipo = document.getElementById("chart-interacoes-tipo");
    dom.chartDemandasStatusScroll = document.getElementById("chart-demandas-status-scroll");
    dom.chartDemandasStatus = document.getElementById("chart-demandas-status");
    dom.chartWordCloud = document.getElementById("chart-wordcloud");
    dom.listaAnalitico = document.getElementById("lista-analitico");
    dom.btnExportCsv = document.getElementById("btn-export-csv");
    dom.analiticoSearch = document.getElementById("analitico-search");

    dom.quickAddModal = document.getElementById("quick-add-modal");
    dom.btnCloseQuickAdd = document.getElementById("btn-close-quick-add");
    dom.formQuickAdd = document.getElementById("form-quick-add");
    dom.quickModalTitle = document.getElementById("quick-modal-title");
    dom.quickTratativaId = document.getElementById("quick-tratativa-id");
    dom.quickTratativaTipo = document.getElementById("quick-tratativa-tipo");
    dom.quickTratativaUsuario = document.getElementById("quick-tratativa-usuario");
    dom.quickCargoDropdown = document.getElementById("quick-cargo-dropdown");
    dom.btnQuickCargoDropdown = document.getElementById("btn-quick-cargo-dropdown");
    dom.quickCargoDropdownPanel = document.getElementById("quick-cargo-dropdown-panel");
    dom.quickCargoOptions = document.getElementById("quick-cargo-options");
    dom.quickAssuntoDropdown = document.getElementById("quick-assunto-dropdown");
    dom.btnQuickAssuntoDropdown = document.getElementById("btn-quick-assunto-dropdown");
    dom.quickAssuntoDropdownPanel = document.getElementById("quick-assunto-dropdown-panel");
    dom.quickAssuntoOptions = document.getElementById("quick-assunto-options");
    dom.quickTratativaAgencia = document.getElementById("quick-tratativa-agencia");
    dom.quickTratativaDescricao = document.getElementById("quick-tratativa-descricao");
    dom.quickTratativaContato = document.getElementById("quick-tratativa-contato");
    dom.quickTratativaAlcance = document.getElementById("quick-tratativa-alcance");
    dom.quickTratativaData = document.getElementById("quick-tratativa-data");

    dom.confirmModal = document.getElementById("confirm-modal");
    dom.confirmTitle = document.getElementById("confirm-title");
    dom.confirmMessage = document.getElementById("confirm-message");
    dom.btnConfirmCancel = document.getElementById("btn-confirm-cancel");
    dom.btnConfirmOk = document.getElementById("btn-confirm-ok");
  }

  function bindEvents() {
    dom.btnAuthModeLogin?.addEventListener("click", () => setAuthMode("login"));
    dom.btnAuthModeSetup?.addEventListener("click", () => setAuthMode("setup"));
    dom.formLogin?.addEventListener("submit", handleLoginSubmit);
    dom.formSetup?.addEventListener("submit", handleFirstAccessSubmit);
    dom.btnLogout?.addEventListener("click", handleLogout);

    dom.navButtons.forEach((button) => {
      button.addEventListener("click", () => switchView(button.dataset.view));
    });

    dom.btnPeriodoDropdown.addEventListener("click", (event) => {
      event.stopPropagation();
      togglePeriodoDropdown(dom.periodoDropdownPanel.classList.contains("is-hidden"));
    });

    dom.periodoMesesOptions.addEventListener("change", (event) => {
      if (!(event.target instanceof HTMLInputElement) || event.target.type !== "checkbox") {
        return;
      }

      const meses = getCheckedMonthsFromDropdown();
      state.filtros.meses = meses;
      updatePeriodoDropdownLabel();
      updateToggleAllLabel("periodo");
      if (meses.length === 0) {
        return;
      }
      scheduleAutoRefresh();
    });

    dom.btnPeriodoToggleAll?.addEventListener("click", (event) => {
      event.stopPropagation();
      toggleAllGlobalSelection("periodo");
    });

    ["usuario", "tratativa", "cargo", "assunto"].forEach((type) => {
      const button = getGlobalMultiButton(type);
      const list = getGlobalMultiList(type);
      const toggleAllButton = getGlobalMultiToggleAllButton(type);

      button?.addEventListener("click", (event) => {
        event.stopPropagation();
        const panel = getGlobalMultiPanel(type);
        const open = panel?.classList.contains("is-hidden") === true;
        toggleGlobalDropdown(type, open);
      });

      toggleAllButton?.addEventListener("click", (event) => {
        event.stopPropagation();
        toggleAllGlobalSelection(type);
      });

      list?.addEventListener("change", (event) => {
        if (!(event.target instanceof HTMLInputElement) || event.target.type !== "checkbox") {
          return;
        }
        setGlobalMultiSelected(type, getCheckedGlobalIds(type));
        if (type === "usuario") {
          updateSidebarSelectedUser();
        }
        updateGlobalMultiLabel(type);
        updateToggleAllLabel(type);
        scheduleAutoRefresh();
      });
    });

    dom.evolucaoGranularidadeButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const granularidade = button.getAttribute("data-granularidade") === "dia" ? "dia" : "mes";
        if (state.filtros.granularidade === granularidade) {
          return;
        }
        state.filtros.granularidade = granularidade;
        syncGranularidadeButtons();
        scheduleAutoRefresh();
      });
    });

    dom.evolucaoModoButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const modo = button.getAttribute("data-evolucao-modo") === "alcance" ? "alcance" : "tratativas";
        if (state.filtros.evolucaoModo === modo) {
          return;
        }
        state.filtros.evolucaoModo = modo;
        syncEvolucaoModoButtons();
        renderChartEvolucao();
        scheduleChartSync(40);
      });
    });

    dom.btnQuickCargoDropdown?.addEventListener("click", (event) => {
      event.stopPropagation();
      const open = dom.quickCargoDropdownPanel.classList.contains("is-hidden");
      toggleModalMultiDropdown("cargo", open);
    });

    dom.btnQuickAssuntoDropdown?.addEventListener("click", (event) => {
      event.stopPropagation();
      const open = dom.quickAssuntoDropdownPanel.classList.contains("is-hidden");
      toggleModalMultiDropdown("assunto", open);
    });

    dom.quickCargoOptions?.addEventListener("change", (event) => {
      if (!(event.target instanceof HTMLInputElement) || event.target.type !== "checkbox") {
        return;
      }
      readModalMultiSelectionFromDom("cargo");
      updateModalMultiLabel("cargo");
    });

    dom.quickAssuntoOptions?.addEventListener("change", (event) => {
      if (!(event.target instanceof HTMLInputElement) || event.target.type !== "checkbox") {
        return;
      }
      readModalMultiSelectionFromDom("assunto");
      updateModalMultiLabel("assunto");
    });

    document.addEventListener("click", (event) => {
      if (!(event.target instanceof Node)) {
        return;
      }
      if (!dom.filtroPeriodoDropdown.contains(event.target)) {
        togglePeriodoDropdown(false);
      }
      ["usuario", "tratativa", "cargo", "assunto"].forEach((type) => {
        const dropdown = getGlobalMultiDropdown(type);
        if (dropdown && !dropdown.contains(event.target)) {
          toggleGlobalDropdown(type, false);
        }
      });
      if (dom.quickCargoDropdown && !dom.quickCargoDropdown.contains(event.target)) {
        toggleModalMultiDropdown("cargo", false);
      }
      if (dom.quickAssuntoDropdown && !dom.quickAssuntoDropdown.contains(event.target)) {
        toggleModalMultiDropdown("assunto", false);
      }
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        togglePeriodoDropdown(false);
        ["usuario", "tratativa", "cargo", "assunto"].forEach((type) => toggleGlobalDropdown(type, false));
        toggleModalMultiDropdown("cargo", false);
        toggleModalMultiDropdown("assunto", false);
        closeQuickAddModal();
        closeConfirmModal(false);
      }
    });

    dom.themeSwitchInput.addEventListener("change", () => {
      applyTheme(dom.themeSwitchInput.checked ? "dark" : "light");
    });

    dom.btnOpenQuickAdd.addEventListener("click", () => {
      openQuickAddModal();
    });

    dom.btnCloseQuickAdd.addEventListener("click", () => {
      closeQuickAddModal();
    });

    dom.btnConfirmCancel?.addEventListener("click", () => {
      closeConfirmModal(false);
    });

    dom.btnConfirmOk?.addEventListener("click", () => {
      closeConfirmModal(true);
    });

    dom.confirmModal?.addEventListener("click", (event) => {
      if (event.target === dom.confirmModal) {
        closeConfirmModal(false);
      }
    });

    const btnCancelQuickAdd = document.getElementById("btn-cancel-quick-add");
    btnCancelQuickAdd?.addEventListener("click", () => {
      hideFeedback();
      closeQuickAddModal();
    });

    dom.formQuickAdd.addEventListener("submit", onSubmitQuickAdd);
    dom.btnExportCsv.addEventListener("click", exportAnaliticoCsv);
    dom.analiticoSearch.addEventListener("input", () => {
      state.analitico.busca = String(dom.analiticoSearch.value || "").trim();
      renderAnalitico();
    });

    dom.listaAnalitico.addEventListener("click", async (event) => {
      const deleteButton = event.target instanceof Element ? event.target.closest("[data-delete-id]") : null;
      if (deleteButton) {
        const deleteId = toIntOrNull(deleteButton.getAttribute("data-delete-id"));
        if (!deleteId) {
          return;
        }
        await onDeleteTratativa(deleteId);
        return;
      }

      const button = event.target instanceof Element ? event.target.closest("[data-edit-id]") : null;
      if (!button) {
        return;
      }
      const id = toIntOrNull(button.getAttribute("data-edit-id"));
      if (!id) {
        return;
      }
      await openEditModal(id);
    });

    window.addEventListener("resize", () => {
      if (resizeTimer) {
        clearTimeout(resizeTimer);
      }
      resizeTimer = setTimeout(() => {
        syncResponsiveLayout();
        scheduleChartSync(0);
      }, 140);
    });
  }

  async function loadSystemIdentity() {
    const payload = await apiGet("system_identity.php");
    state.identity = payload?.identidade || null;
    renderSystemIdentity();
  }

  function renderSystemIdentity() {
    const identity = state.identity || {};
    const windowsInfo = identity.windows || {};
    const groups = Array.isArray(windowsInfo.grupos) ? windowsInfo.grupos : [];

    if (dom.identityNote) {
      dom.identityNote.textContent = identity.observacao || "Sem dados de identidade disponíveis.";
    }
    if (dom.identityUser) {
      dom.identityUser.textContent = windowsInfo.usuario_rede || windowsInfo.whoami || "-";
    }
    if (dom.identityUsername) {
      dom.identityUsername.textContent = windowsInfo.usuario_windows || "-";
    }
    if (dom.identityGroupsCount) {
      dom.identityGroupsCount.textContent = groups.length > 0 ? `${groups.length} grupo(s)` : "-";
    }
    if (dom.identityComputer) {
      dom.identityComputer.textContent = windowsInfo.computador || "-";
    }
    if (dom.identityDomain) {
      dom.identityDomain.textContent = windowsInfo.dominio || (windowsInfo.part_of_domain ? "Domínio detectado" : "Sem domínio");
    }
    if (dom.identityLogonserver) {
      dom.identityLogonserver.textContent = windowsInfo.logonserver || "-";
    }
    if (dom.identityGroups) {
      if (groups.length === 0) {
        dom.identityGroups.innerHTML = '<span class="identity-group-pill">Nenhum grupo retornado</span>';
        return;
      }

      dom.identityGroups.innerHTML = groups
        .slice(0, 24)
        .map((group) => `<span class="identity-group-pill">${escapeHtml(group.nome || "-")}</span>`)
        .join("");
    }
  }

  function switchView(viewId) {
    const nextView = viewId === "analitico" ? "analitico" : "dashboard";
    beginLoading("Carregando página...");
    state.view = nextView;
    saveView(nextView);
    applyViewState(nextView);

    if (nextView === "dashboard") {
      scheduleChartSync(40);
      setTimeout(() => endLoading(), 120);
      return;
    }

    loadAnalitico()
      .catch((error) => {
        showFeedback(error.message || "Erro ao carregar página analítica.", "error");
      })
      .finally(() => {
        endLoading();
      });
  }

  function applyViewState(nextView) {
    dom.navButtons.forEach((button) => {
      button.classList.toggle("is-active", button.dataset.view === nextView);
    });

    dom.views.forEach((section) => {
      section.classList.toggle("is-active", section.id === `view-${nextView}`);
    });

    dom.viewTitle.textContent =
      nextView === "dashboard" ? "Conseg PJ" : "Analítico de Tratativas";
  }

  async function refreshAllData(showSuccessMessage = false) {
    const keepPeriodoOpen = dom.periodoDropdownPanel && !dom.periodoDropdownPanel.classList.contains("is-hidden");
    const keepCargoOpen = dom.cargoDropdownPanel && !dom.cargoDropdownPanel.classList.contains("is-hidden");
    const keepAssuntoOpen = dom.assuntoDropdownPanel && !dom.assuntoDropdownPanel.classList.contains("is-hidden");
    readFiltersFromInputs();

    const [dashboardResult, analiticoResult] = await Promise.allSettled([loadDashboard(), loadAnalitico()]);

    if (dashboardResult.status === "rejected") {
      throw dashboardResult.reason;
    }

    if (analiticoResult.status === "rejected") {
      state.analitico.tratativas = [];
      state.analitico.total = 0;
      renderAnalitico();
      showFeedback("Não foi possível carregar a tabela analítica.", "error");
    }

    if (showSuccessMessage) {
      showFeedback("Dados atualizados.", "success");
    }

    if (keepPeriodoOpen) {
      togglePeriodoDropdown(true);
    }
    if (keepCargoOpen) {
      toggleGlobalDropdown("cargo", true);
    }
    if (keepAssuntoOpen) {
      toggleGlobalDropdown("assunto", true);
    }
  }

  async function loadDimensions() {
    const payload = await apiGet("dimensoes.php?tipo=all");
    const dados = payload.dados || {};

    state.dimensoes.usuarios = normalizeArray(dados.usuarios).map(normalizeUserName);
    state.dimensoes.tiposTratativa = normalizeArray(dados.tipos_interacao || dados.tipos_tratativa).map(normalizeTipoTratativaRow);
    state.dimensoes.assuntos = normalizeArray(dados.temas_visita || dados.assuntos);
    state.dimensoes.cargos = normalizeArray(dados.cargos);

    const usuarioSet = new Set(state.dimensoes.usuarios.map((item) => toInt(item.id)));
    const tipoSet = new Set(buildTipoFilterRows().map((item) => toInt(item.id)));
    const cargoSet = new Set(state.dimensoes.cargos.map((item) => toInt(item.id)));
    const assuntoSet = new Set(state.dimensoes.assuntos.map((item) => toInt(item.id)));
    state.filtros.usuarioIds = normalizeIntArray(state.filtros.usuarioIds).filter((id) => usuarioSet.has(id));
    state.filtros.tipoTratativaIds = normalizeIntArray(state.filtros.tipoTratativaIds).filter((id) => tipoSet.has(id));
    state.filtros.cargoIds = normalizeIntArray(state.filtros.cargoIds).filter((id) => cargoSet.has(id));
    state.filtros.assuntoIds = normalizeIntArray(state.filtros.assuntoIds).filter((id) => assuntoSet.has(id));

    renderGlobalMultiOptions("usuario", state.dimensoes.usuarios);
    renderGlobalMultiOptions("tratativa", buildTipoFilterRows());
    renderGlobalMultiOptions("cargo", state.dimensoes.cargos);
    renderGlobalMultiOptions("assunto", state.dimensoes.assuntos);

    fillSelect(dom.quickTratativaTipo, state.dimensoes.tiposTratativa, {
      valueKey: "id",
      labelKey: "nome",
    });

    fillSelect(dom.quickTratativaUsuario, state.dimensoes.usuarios, {
      valueKey: "id",
      labelKey: "nome",
    });

    renderModalMultiOptions("cargo", state.dimensoes.cargos);
    renderModalMultiOptions("assunto", state.dimensoes.assuntos);

    syncFilterInputs();
    syncGranularidadeButtons();
    syncEvolucaoModoButtons();
    updateSidebarSelectedUser();
  }

  async function loadDashboard(retryOnce = true) {
    const query = buildFiltersQuery();
    const payload = await apiGet(`dashboard.php?${query.toString()}`);
    state.dashboard = payload;

    const monthsChanged = populateMonthsSelect(payload.meses_disponiveis || []);
    renderDashboard();

    if (retryOnce && monthsChanged) {
      await loadDashboard(false);
    }
  }

  async function loadAnalitico() {
    const query = buildFiltersQuery();
    query.set("limit", "800");
    const payload = await apiGet(`tratativas.php?${query.toString()}`);
    state.analitico.tratativas = normalizeArray(payload.tratativas);
    state.analitico.total = toInt(payload.total);
    renderAnalitico();
  }

  function renderDashboard() {
    if (!state.dashboard) {
      return;
    }

    const kpis = state.dashboard.kpis || {};
    dom.kpiTotalTratativas.textContent = formatInt(kpis.total_tratativas);
    dom.kpiTotalTeams.textContent = formatInt(kpis.total_teams);
    dom.kpiTotalVisitas.textContent = formatInt(kpis.total_visitas);
    dom.kpiTotalLigacoes.textContent = formatInt(kpis.total_ligacoes);
    dom.kpiTotalEvento.textContent = formatInt(kpis.total_evento);
    dom.kpiTotalLive.textContent = formatInt(kpis.total_live);
    dom.kpiTotalAlcance.textContent = formatInt(kpis.total_alcance);
    updatePeriodEmptyMessage(toInt(kpis.total_tratativas) === 0);

    renderChartEvolucao();
    renderChartAssuntos();
    renderChartRosca();
    renderChartCargo();
    scheduleChartSync(120);
  }

  function renderAnalitico() {
    if (!dom.listaAnalitico) {
      return;
    }

    const rows = getFilteredAnaliticoRows();
    if (rows.length === 0) {
      dom.listaAnalitico.innerHTML = '<div class="empty-state">Nenhuma tratativa encontrada para os filtros atuais.</div>';
      return;
    }

    const html = rows
      .map((row) => {
        const cargoLabel = formatDimensionField(row.cargo, row.ids_cargos, state.dimensoes.cargos);
        const assuntoLabel = formatDimensionField(row.assunto, row.ids_assuntos, state.dimensoes.assuntos);
        return `
          <tr>
            <td class="table-cell-wrap">${escapeHtml(formatDate(row.data))}</td>
            <td class="table-cell-wrap">${escapeHtml(row.tipo_tratativa || "-")}</td>
            <td class="table-cell-wrap">${escapeHtml(row.usuario || "-")}</td>
            <td>${escapeHtml(formatInt(row.alcance_total || 0))}</td>
            <td class="table-cell-wrap">${escapeHtml(cargoLabel || "-")}</td>
            <td class="table-cell-wrap">${escapeHtml(assuntoLabel || "-")}</td>
            <td class="table-cell-wrap">${escapeHtml(row.juncao || row.agencia || "-")}</td>
            <td class="table-cell-wrap table-cell-descricao">${escapeHtml(row.descricao || "-")}</td>
            <td class="table-cell-wrap">${escapeHtml(formatContato(row.contatos))}</td>
            <td class="table-actions-cell">
              <div class="table-actions">
                <button class="icon-btn" type="button" data-edit-id="${toInt(row.id)}" aria-label="Editar tratativa">&#9998;</button>
                <button class="icon-btn icon-btn-danger" type="button" data-delete-id="${toInt(row.id)}" aria-label="Excluir tratativa">&#128465;</button>
              </div>
            </td>
          </tr>
        `;
      })
      .join("");

    dom.listaAnalitico.innerHTML = `
      <table class="data-table data-table-analitico">
        <colgroup>
          <col class="col-data" />
          <col class="col-tipo" />
          <col class="col-usuario" />
          <col class="col-alcance" />
          <col class="col-cargo" />
          <col class="col-assunto" />
          <col class="col-juncao" />
          <col class="col-descricao" />
          <col class="col-contato" />
          <col class="col-acoes" />
        </colgroup>
        <thead>
          <tr>
            <th>Data</th>
            <th>Tipo</th>
            <th>Usuário</th>
            <th>Alcance</th>
            <th>Cargo</th>
            <th>Assunto</th>
            <th>Junção</th>
            <th class="table-cell-descricao">Descrição</th>
            <th>Contato</th>
            <th class="table-actions-head">Ações</th>
          </tr>
        </thead>
        <tbody>${html}</tbody>
      </table>
    `;
  }
  function renderChartEvolucao() {
    const data = state.dashboard || {};
    const chartColors = getChartCssColors();
    const visibleTipos = buildTipoCatalog();
    const filteredTipoIds = getSelectedTipoTratativaIds();
    const evolucaoModo = state.filtros.evolucaoModo === "alcance" ? "alcance" : "tratativas";
    const timelineKey = evolucaoModo === "alcance" ? "alcance_timeline_por_tipo" : "timeline_por_tipo";
    const unitLabel = evolucaoModo === "alcance" ? "pessoa(s) alcançada(s)" : "tratativa(s)";
    const granularidade = state.filtros.granularidade === "dia" ? "dia" : "mes";
    const isDiario = granularidade === "dia";
    const refs = isDiario ? resolveDayAxisRefs() : resolveMonthAxisRefs(data.meses_disponiveis || []);
    const labels = refs.map((ref) => (isDiario ? dayLabel(ref) : monthLabel(ref)));
    const tiposBase = filteredTipoIds.length > 0 ? visibleTipos.filter((tipo) => filteredTipoIds.includes(tipo.id)) : visibleTipos;
    const seriesDraft = tiposBase.map((tipo) => {
      const timelineMap = toTimelineCountMap(getTipoTimelineRows(data, tipo.id, timelineKey), granularidade);
      return {
        name: tipo.nome,
        color: tipo.color,
        data: refs.map((ref) => timelineMap[ref] || 0),
      };
    });
    const seriesData = filteredTipoIds.length > 0 ? seriesDraft : seriesDraft.filter((item) => item.data.some((value) => value > 0));
    if (seriesData.length === 0) {
      clearChart("evolucao");
      dom.chartEvolucao.innerHTML = '<div class="empty-state">Sem dados para o período selecionado.</div>';
      if (dom.chartEvolucaoTitle) {
        dom.chartEvolucaoTitle.textContent = evolucaoModo === "alcance" ? "Evolução de alcance" : "Evolução de tratativas";
      }
      return;
    }

    if (dom.chartEvolucaoTitle) {
      dom.chartEvolucaoTitle.textContent = evolucaoModo === "alcance" ? "Evolução de alcance" : "Evolução de tratativas";
    }

    const maxValue = isDiario
      ? Math.max(
          1,
          ...refs.map((_ref, index) => seriesData.reduce((acc, item) => acc + toInt(item.data[index]), 0))
        )
      : Math.max(1, ...seriesData.flatMap((item) => item.data));
    const yScale = buildIntegerScale(maxValue);
    const viewportWidth = dom.chartEvolucaoScroll?.clientWidth || dom.chartEvolucao?.clientWidth || 680;
    const pointsWidth = isDiario ? 126 : 118;
    const dynamicWidth = Math.max(viewportWidth, refs.length * pointsWidth);

    const evolucaoOptions = {
      chart: {
        type: isDiario ? "bar" : "line",
        height: "100%",
        width: dynamicWidth,
        parentHeightOffset: 0,
        toolbar: { show: false },
        zoom: { enabled: false },
        stacked: isDiario,
        animations: { 
          enabled: true, 
          easing: "easeinout", 
          speed: 1300,
          animateGradually: {
            enabled: true,
            delay: 110
          },
          dynamicAnimation: {
            enabled: true,
            speed: 850
          }
        },
      },
      series: seriesData.map((item) => ({ name: item.name, data: item.data })),
      colors: seriesData.map((item) => item.color),
      stroke: isDiario ? { width: 0 } : { curve: "smooth", width: 2.6 },
      markers: isDiario
        ? { size: 0 }
        : {
            size: 4.4,
            strokeWidth: 0,
            colors: seriesData.map((item) => item.color),
            hover: { size: 6 },
          },
      dataLabels: {
        enabled: true,
        offsetY: 0,
        style: {
          fontSize: "11px",
          fontWeight: 700,
          colors: ["#ffffff"],
        },
        background: {
          enabled: !isDiario,
          borderRadius: 4,
          borderWidth: 0,
          foreColor: "#ffffff",
          opacity: 0.92,
        },
        formatter: (value) => {
          const amount = toInt(value);
          return amount > 0 ? formatInt(amount) : "";
        },
      },
      grid: {
        borderColor: chartColors.grid,
        strokeDashArray: 4,
        padding: {
          bottom: 28,
          left: 8,
          right: 10,
          top: 4,
        },
      },
      xaxis: {
        categories: labels,
        labels: {
          style: { colors: chartColors.label, fontSize: isDiario ? "11px" : "12px" },
          trim: false,
          rotate: 0,
          offsetY: isDiario ? 4 : 2,
          hideOverlappingLabels: false,
          minHeight: isDiario ? 40 : 24,
          maxHeight: isDiario ? 52 : 28,
        },
        tickPlacement: "on",
      },
      yaxis: {
        min: yScale.min,
        max: yScale.max,
        tickAmount: yScale.tickAmount,
        decimalsInFloat: 0,
        forceNiceScale: true,
        title: { text: "" },
        labels: {
          style: { colors: chartColors.label, fontSize: "12px" },
          formatter: (value) => formatInt(Math.round(value)),
        },
      },
      legend: {
        show: true,
        position: "top",
        horizontalAlign: "left",
        labels: { colors: chartColors.label },
      },
      tooltip: {
        theme: document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light",
        x: {
          formatter: (_value, opts) => {
            const idx = toInt(opts?.dataPointIndex);
            const ref = refs[idx] || "";
            if (isDiario) {
              return dayLabelLong(ref);
            }
            return monthLabel(ref);
          },
        },
        y: { formatter: (value) => `${formatInt(value)} ${unitLabel}` },
      },
    };

    if (isDiario) {
      evolucaoOptions.plotOptions = {
        bar: {
          horizontal: false,
          columnWidth: refs.length > 20 ? "32%" : "40%",
          borderRadius: 6,
          borderRadiusApplication: "end",
          borderRadiusWhenStacked: "last",
        },
      };
    }

    mountChart("evolucao", dom.chartEvolucao, evolucaoOptions);
  }

  function renderChartAssuntos() {
    const rows = normalizeArray(state.dashboard?.tratativas_por_assunto);
    const visibleTipos = buildTipoCatalog();
    const filteredTipoIds = getSelectedTipoTratativaIds();
    const tiposBase = filteredTipoIds.length > 0 ? visibleTipos.filter((tipo) => filteredTipoIds.includes(tipo.id)) : visibleTipos;
    const tiposAtivos = filteredTipoIds.length > 0
      ? tiposBase
      : tiposBase.filter((tipo) => rows.some((row) => getGroupedTipoCount(row, tipo.id) > 0));

    if (rows.length === 0 || tiposAtivos.length === 0) {
      clearChart("volume");
      dom.chartTopVolume.innerHTML = '<div class="empty-state">Sem dados para o período selecionado.</div>';
      return;
    }

    const categories = rows.map((row) => String(row.assunto || "Sem assunto"));
    const totalPorLinha = rows.map((row) => tiposAtivos.reduce((acc, tipo) => acc + getGroupedTipoCount(row, tipo.id), 0));
    const maxTotal = Math.max(1, ...totalPorLinha);
    const parentHeight = dom.chartTopVolume?.parentElement?.clientHeight || 300;
    const availableHeight = Math.max(220, parentHeight - 8);
    const rowHeight = rows.length <= 5 ? 62 : rows.length <= 9 ? 52 : 44;
    const naturalHeight = rows.length * rowHeight + 78;
    const dynamicHeight = Math.max(availableHeight, naturalHeight);
    const barHeight = rows.length <= 4 ? "94%" : rows.length <= 7 ? "84%" : rows.length <= 10 ? "72%" : "60%";
    const chartColors = getChartCssColors();

    mountChart("volume", dom.chartTopVolume, {
      chart: {
        type: "bar",
        height: dynamicHeight,
        stacked: true,
        toolbar: { show: false },
        animations: { 
          enabled: true, 
          easing: "easeinout", 
          speed: 1300,
          animateGradually: {
            enabled: true,
            delay: 110
          },
          dynamicAnimation: {
            enabled: true,
            speed: 850
          }
        },
      },
      series: tiposAtivos.map((tipo) => ({
        name: tipo.nome,
        data: rows.map((row) => getGroupedTipoCount(row, tipo.id)),
      })),
      colors: tiposAtivos.map((tipo) => tipo.color),
      plotOptions: {
        bar: {
          horizontal: true,
          barHeight,
          borderRadius: 6,
          borderRadiusApplication: "end",
          borderRadiusWhenStacked: "last",
        },
      },
      dataLabels: {
        enabled: true,
        style: { fontSize: "11px", fontWeight: 700, colors: ["#ffffff"] },
        formatter: (value) => (value > 0 ? formatInt(value) : ""),
      },
      grid: {
        borderColor: chartColors.grid,
        strokeDashArray: 4,
      },
      xaxis: {
        categories,
        min: 0,
        max: maxTotal,
        tickAmount: Math.min(maxTotal, 6),
        labels: { show: false },
        axisBorder: { show: false },
        axisTicks: { show: false },
      },
      yaxis: {
        labels: {
          style: { colors: chartColors.label, fontSize: "12px" },
          maxWidth: 280,
        },
      },
      legend: {
        show: true,
        position: "top",
        horizontalAlign: "center",
        labels: { colors: chartColors.label },
      },
      tooltip: {
        theme: document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light",
      },
    });
  }

  function renderChartRosca() {
    const data = state.dashboard || {};
    const chartColors = getChartCssColors();
    const visibleTipos = buildTipoCatalog();
    const filteredTipoIds = getSelectedTipoTratativaIds();
    const totalsMap = data.kpis?.totais_por_tipo || {};
    const tiposBase = filteredTipoIds.length > 0 ? visibleTipos.filter((tipo) => filteredTipoIds.includes(tipo.id)) : visibleTipos;
    const tiposAtivos = filteredTipoIds.length > 0
      ? tiposBase
      : tiposBase.filter((tipo) => getTipoCountFromMap(totalsMap, tipo.id) > 0);
    const labels = tiposAtivos.map((tipo) => tipo.nome);
    const series = tiposAtivos.map((tipo) => getTipoCountFromMap(totalsMap, tipo.id));
    const colors = tiposAtivos.map((tipo) => tipo.color);

    if (labels.length === 0 || series.every((value) => value === 0)) {
      clearChart("rosca");
      dom.chartInteracoesTipo.innerHTML = '<div class="empty-state">Sem dados para o período selecionado.</div>';
      return;
    }

    const chartWidth = dom.chartInteracoesTipo?.clientWidth || 220;
    const chartHeight = dom.chartInteracoesTipo?.clientHeight || 170;
    const minSide = Math.max(120, Math.min(chartWidth, chartHeight));
    const donutScale = Math.max(0.48, Math.min(0.86, (minSide - 10) / 250));
    const centerValueSize = Math.max(14, Math.min(26, Math.round(minSide * 0.125)));
    const centerLabelSize = Math.max(8, Math.min(11, Math.round(minSide * 0.05)));

    mountChart("rosca", dom.chartInteracoesTipo, {
      chart: {
        type: "donut",
        height: "100%",
        width: "100%",
        parentHeightOffset: 0,
        redrawOnWindowResize: true,
        redrawOnParentResize: true,
        animations: { 
          enabled: true, 
          easing: "easeinout", 
          speed: 1300,
          animateGradually: {
            enabled: true,
            delay: 110
          },
          dynamicAnimation: {
            enabled: true,
            speed: 850
          }
        },
      },
      labels,
      series,
      colors,
      stroke: { width: 1.5, colors: [getComputedStyle(document.documentElement).getPropertyValue("--surface-strong").trim()] },
      legend: { show: false },
      dataLabels: {
        enabled: false,
      },
      plotOptions: {
        pie: {
          customScale: donutScale,
          expandOnClick: false,
          donut: {
            size: "62%",
            labels: {
              show: true,
              name: { show: true, color: chartColors.label, fontSize: `${centerLabelSize}px` },
              value: {
                show: true,
                color: chartColors.label,
                fontSize: `${centerValueSize}px`,
                fontWeight: 700,
                formatter: (value) => formatInt(value),
              },
              total: {
                show: true,
                label: "Total",
                color: chartColors.label,
                fontSize: `${centerLabelSize}px`,
                formatter: () => formatInt(series.reduce((acc, item) => acc + item, 0)),
              },
            },
          },
        },
      },
      tooltip: {
        custom: ({ series, seriesIndex, w }) => {
          const label = String(w?.globals?.labels?.[seriesIndex] ?? "");
          const color = String(w?.globals?.colors?.[seriesIndex] ?? "#1b2563");
          const total = toInt(series?.[seriesIndex] ?? 0);
          return `
            <div class="chart-tooltip chart-tooltip-donut" style="--tooltip-bg:${color}">
              <strong>${escapeHtml(label)}</strong>
              <span>${formatInt(total)} tratativa(s)</span>
            </div>
          `;
        },
      },
    });
  }

  function renderChartCargo() {
    const rows = normalizeArray(state.dashboard?.tratativas_por_cargo);
    const visibleTipos = buildTipoCatalog();
    const filteredTipoIds = getSelectedTipoTratativaIds();
    const tiposBase = filteredTipoIds.length > 0 ? visibleTipos.filter((tipo) => filteredTipoIds.includes(tipo.id)) : visibleTipos;
    const tiposAtivos = filteredTipoIds.length > 0
      ? tiposBase
      : tiposBase.filter((tipo) => rows.some((row) => getGroupedTipoCount(row, tipo.id) > 0));

    if (rows.length === 0 || tiposAtivos.length === 0) {
      clearChart("cargo");
      dom.chartDemandasStatus.innerHTML = '<div class="empty-state">Sem dados de cargos para o período selecionado.</div>';
      return;
    }

    const categories = rows.map((row) => String(row.cargo || "Não informado"));
    const categoryLines = categories.map((label) => toCategoryLines(label, 18, 2));
    const totalPorCargo = rows.map((row) => tiposAtivos.reduce((acc, tipo) => acc + getGroupedTipoCount(row, tipo.id), 0));
    const maxValue = Math.max(1, ...totalPorCargo);
    const yScale = buildIntegerScale(maxValue);
    const parentHeight = dom.chartDemandasStatusScroll?.clientHeight || dom.chartDemandasStatus?.parentElement?.clientHeight || 280;
    const dynamicHeight = Math.max(190, parentHeight - 8);
    const viewportWidth = dom.chartDemandasStatusScroll?.clientWidth || dom.chartDemandasStatus?.clientWidth || 520;
    const maxLabelSize = categories.reduce((acc, label) => Math.max(acc, String(label).length), 8);
    const perCategoryWidth = Math.max(105, Math.min(180, maxLabelSize * 4.8));
    const dynamicWidth =
      categories.length > 3
        ? Math.max(viewportWidth, categories.length * perCategoryWidth)
        : Math.max(viewportWidth, categories.length * perCategoryWidth);
    const chartColors = getChartCssColors();

    if (dom.chartDemandasStatus) {
      dom.chartDemandasStatus.style.minWidth = `${dynamicWidth}px`;
    }

      mountChart("cargo", dom.chartDemandasStatus, {
      chart: {
        type: "bar",
        height: dynamicHeight,
        width: dynamicWidth,
        stacked: true,
        toolbar: { show: false },
        animations: { 
          enabled: true, 
          easing: "easeinout", 
          speed: 1300,
          animateGradually: {
            enabled: true,
            delay: 110
          },
          dynamicAnimation: {
            enabled: true,
            speed: 850
          }
        },
      },
      series: tiposAtivos.map((tipo) => ({
        name: tipo.nome,
        data: rows.map((row) => getGroupedTipoCount(row, tipo.id)),
      })),
      colors: tiposAtivos.map((tipo) => tipo.color),
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "40%",
          borderRadius: 6,
          borderRadiusApplication: "end",
          borderRadiusWhenStacked: "last",
        },
      },
      dataLabels: {
        enabled: true,
        style: { fontSize: "11px", fontWeight: 700, colors: ["#ffffff"] },
        formatter: (value) => (value > 0 ? formatInt(value) : ""),
      },
      grid: {
        borderColor: chartColors.grid,
        strokeDashArray: 4,
        padding: {
          bottom: 18,
          left: 4,
          right: 8,
        },
      },
      xaxis: {
        categories: categoryLines,
        labels: {
          style: { colors: chartColors.label, fontSize: "11px" },
          rotate: 0,
          hideOverlappingLabels: false,
          trim: false,
          minHeight: 42,
          maxHeight: 58,
        },
      },
      yaxis: {
        min: yScale.min,
        max: yScale.max,
        tickAmount: yScale.tickAmount,
        labels: { show: false },
      },
      legend: {
        show: true,
        position: "top",
        horizontalAlign: "left",
        labels: { colors: chartColors.label },
      },
      tooltip: {
        theme: document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light",
        x: {
          formatter: (_value, opts) => categories[toInt(opts?.dataPointIndex)] || "",
        },
        y: { formatter: (value) => `${formatInt(value)} tratativa(s)` },
      },
    });
  }

  function renderWordCloud() {
    if (!dom.chartWordCloud) {
      return;
    }

    const rows = normalizeArray(state.analitico?.tratativas);
    if (rows.length === 0) {
      dom.chartWordCloud.innerHTML = '<div class="empty-state">Sem descrições para gerar a nuvem de palavras.</div>';
      return;
    }

    const stopWords = new Set([
      "a",
      "o",
      "os",
      "as",
      "um",
      "uma",
      "de",
      "da",
      "do",
      "das",
      "dos",
      "e",
      "em",
      "no",
      "na",
      "nos",
      "nas",
      "com",
      "sem",
      "para",
      "por",
      "que",
      "se",
      "ao",
      "aos",
      "à",
      "às",
      "ou",
      "mais",
      "menos",
      "sobre",
      "das",
      "dos",
      "delas",
      "deles",
      "ele",
      "ela",
      "eles",
      "elas",
      "isso",
      "esta",
      "este",
      "essa",
      "esse",
      "foi",
      "ser",
      "são",
      "não",
      "sim",
    ]);

    const counts = {};
    rows.forEach((row) => {
      const text = String(row.descricao || "");
      const tokens = text.match(/[A-Za-zÀ-ÖØ-öø-ÿ0-9]+/g) || [];
      tokens.forEach((token) => {
        const normalized = token.toLowerCase();
        if (normalized.length < 3 || stopWords.has(normalized) || /^\d+$/.test(normalized)) {
          return;
        }
        counts[normalized] = (counts[normalized] || 0) + 1;
      });
    });

    const words = Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 36);

    if (words.length === 0) {
      dom.chartWordCloud.innerHTML = '<div class="empty-state">Sem palavras relevantes nas descrições do período.</div>';
      return;
    }

    const maxCount = words[0][1];
    const minCount = words[words.length - 1][1];
    const spread = Math.max(1, maxCount - minCount);
    const palette = getChartCssColors();
    const baseColors = [palette.teams, palette.visitas, palette.ligacoes];

    const containerWidth = Math.max(240, dom.chartWordCloud.clientWidth || 780);
    const containerHeight = Math.max(120, dom.chartWordCloud.clientHeight || 150);
    const placed = [];
    const html = [];

    words.forEach(([word, count], index) => {
      const ratio = (count - minCount) / spread;
      const size = Math.round(12 + ratio * 26);
      const rotateOptions = [-24, -14, -7, 0, 7, 14, 24];
      const hash = hashString(`${word}-${count}-${index}`);
      const rotate = rotateOptions[hash % rotateOptions.length];
      const color = baseColors[index % baseColors.length];
      const boxW = Math.max(42, Math.round(size * (word.length * 0.48)));
      const boxH = Math.max(20, Math.round(size * 1.12));

      let chosen = null;
      for (let i = 0; i < 52; i += 1) {
        const x = Math.round((hash * (i + 3) * 37) % Math.max(1, containerWidth - boxW - 8));
        const y = Math.round((hash * (i + 5) * 23) % Math.max(1, containerHeight - boxH - 8));
        const collides = placed.some((item) => {
          return (
            x < item.x + item.w + 3 &&
            x + boxW + 3 > item.x &&
            y < item.y + item.h + 3 &&
            y + boxH + 3 > item.y
          );
        });
        if (!collides) {
          chosen = { x, y };
          break;
        }
      }

      if (!chosen) {
        chosen = {
          x: Math.max(0, (index * 47) % Math.max(1, containerWidth - boxW - 8)),
          y: Math.max(0, (index * 19) % Math.max(1, containerHeight - boxH - 8)),
        };
      }

      placed.push({ x: chosen.x, y: chosen.y, w: boxW, h: boxH });
      html.push(
        `<span class="wordcloud-item" style="--wc-size:${size}px;--wc-color:${color};left:${chosen.x}px;top:${chosen.y}px;transform:rotate(${rotate}deg)" title="${count} ocorrência(s)" data-count="${count} ocorrência(s)">
          ${escapeHtml(word)}
        </span>`
      );
    });

    dom.chartWordCloud.innerHTML = html.join("");
  }

  function openQuickAddModal() {
    dom.formQuickAdd.reset();
    dom.quickTratativaId.value = "";
    dom.quickModalTitle.textContent = "Nova tratativa";
    setModalSelection("cargo", []);
    setModalSelection("assunto", []);
    syncModalMultiOptions();
    toggleModalMultiDropdown("cargo", false);
    toggleModalMultiDropdown("assunto", false);
    setDefaultDateInput();
    if (dom.quickTratativaAlcance) {
      dom.quickTratativaAlcance.value = "0";
    }

    const usuarioPadrao = getPreferredGlobalSelectionId("usuario");
    if (usuarioPadrao && hasOption(dom.quickTratativaUsuario, String(usuarioPadrao))) {
      dom.quickTratativaUsuario.value = String(usuarioPadrao);
    }

    const tipoDefault = getPreferredGlobalSelectionId("tratativa");
    if (tipoDefault && hasOption(dom.quickTratativaTipo, String(tipoDefault))) {
      dom.quickTratativaTipo.value = String(tipoDefault);
    }

    dom.quickAddModal.classList.remove("is-hidden");
    dom.quickAddModal.setAttribute("aria-hidden", "false");
  }

  async function openEditModal(id) {
    beginLoading("Carregando tratativa...");
    try {
      const payload = await apiGet(`tratativas.php?id=${id}`, { skipLoading: true });
      const row = payload.tratativa;
      if (!row) {
        throw new Error("Tratativa não encontrada.");
      }

      dom.quickModalTitle.textContent = "Editar tratativa";
      dom.quickTratativaId.value = String(toInt(row.id));
      dom.quickTratativaTipo.value = String(toInt(row.id_tratativa));
      dom.quickTratativaUsuario.value = String(toInt(row.id_usuario));
      const idsCargos = normalizeIntArray(row.ids_cargos || (row.id_cargo ? [row.id_cargo] : []));
      const idsAssuntos = normalizeIntArray(row.ids_assuntos || (row.id_assunto ? [row.id_assunto] : []));
      setModalSelection("cargo", idsCargos);
      setModalSelection("assunto", idsAssuntos);
      syncModalMultiOptions();
      dom.quickTratativaAgencia.value = row.juncao || row.agencia || "";
      dom.quickTratativaDescricao.value = row.descricao || "";
      dom.quickTratativaContato.value = formatContato(row.contatos, "");
      dom.quickTratativaAlcance.value = String(toNonNegativeInt(row.alcance, 0));
      dom.quickTratativaData.value = toDateInputValue(row.data);

      dom.quickAddModal.classList.remove("is-hidden");
      dom.quickAddModal.setAttribute("aria-hidden", "false");
    } catch (error) {
      showFeedback(error.message || "Erro ao abrir tratativa.", "error");
    } finally {
      endLoading();
    }
  }

  function closeQuickAddModal() {
    toggleModalMultiDropdown("cargo", false);
    toggleModalMultiDropdown("assunto", false);
    dom.quickAddModal.classList.add("is-hidden");
    dom.quickAddModal.setAttribute("aria-hidden", "true");
  }

  function showConfirmModal(message, title = "Confirmar ação") {
    if (!dom.confirmModal || !dom.confirmTitle || !dom.confirmMessage) {
      return Promise.resolve(false);
    }

    if (confirmResolver) {
      confirmResolver(false);
      confirmResolver = null;
    }

    dom.confirmTitle.textContent = String(title || "Confirmar ação");
    dom.confirmMessage.textContent = String(message || "Tem certeza que deseja continuar?");
    dom.confirmModal.classList.remove("is-hidden");
    dom.confirmModal.setAttribute("aria-hidden", "false");

    return new Promise((resolve) => {
      confirmResolver = resolve;
    });
  }

  function closeConfirmModal(confirmed) {
    if (!dom.confirmModal) {
      return;
    }

    dom.confirmModal.classList.add("is-hidden");
    dom.confirmModal.setAttribute("aria-hidden", "true");
    if (confirmResolver) {
      confirmResolver(confirmed === true);
      confirmResolver = null;
    }
  }

  async function onDeleteTratativa(id) {
    const confirmed = await showConfirmModal("Tem certeza que deseja excluir esta tratativa?", "Excluir tratativa");
    if (!confirmed) {
      return;
    }

    try {
      await apiDelete("tratativas.php", { id });
      await refreshAllData();
      showFeedback("Tratativa excluída com sucesso.", "success");
    } catch (error) {
      showFeedback(error.message || "Erro ao excluir tratativa.", "error");
    }
  }

  async function onSubmitQuickAdd(event) {
    event.preventDefault();

    try {
      readModalMultiSelectionFromDom("cargo");
      readModalMultiSelectionFromDom("assunto");
      const idsCargos = getModalSelection("cargo");
      const idsAssuntos = getModalSelection("assunto");
      const payload = {
        data: normalizeDateInput(dom.quickTratativaData.value),
        id_tratativa: toIntOrNull(dom.quickTratativaTipo.value),
        id_usuario: toIntOrNull(dom.quickTratativaUsuario.value),
        id_cargos: idsCargos,
        id_assuntos: idsAssuntos,
        id_cargo: idsCargos[0] ?? null,
        id_assunto: idsAssuntos[0] ?? null,
        juncao: nullableString(dom.quickTratativaAgencia.value),
        descricao: nullableString(dom.quickTratativaDescricao.value),
        contatos: nullableString(dom.quickTratativaContato.value),
        alcance: toNonNegativeInt(dom.quickTratativaAlcance.value, 0),
      };

      validateModalPayload(payload);

      const editId = toIntOrNull(dom.quickTratativaId.value);
      if (editId) {
        await apiPut("tratativas.php", { id: editId, ...payload });
      } else {
        await apiPost("tratativas.php", payload);
      }

      closeQuickAddModal();
      await refreshAllData();
      showFeedback("Tratativa salva com sucesso.", "success");
    } catch (error) {
      showFeedback(error.message || "Erro ao salvar tratativa.", "error");
    }
  }

  function validateModalPayload(payload) {
    if (!payload.data) {
      throw new Error("Informe a data da tratativa.");
    }
    if (!payload.id_tratativa) {
      throw new Error("Selecione o tipo de tratativa.");
    }
    if (!payload.id_usuario) {
      throw new Error("Selecione o usuário.");
    }
    if (payload.alcance === null || payload.alcance < 0) {
      throw new Error("Informe um alcance válido.");
    }
    if (!Array.isArray(payload.id_assuntos) || payload.id_assuntos.length === 0) {
      throw new Error("Selecione ao menos um assunto.");
    }
  }

  function renderModalMultiOptions(type, rows) {
    const list = type === "cargo" ? dom.quickCargoOptions : dom.quickAssuntoOptions;
    if (!list) {
      return;
    }

    const options = normalizeArray(rows);
    list.innerHTML = options
      .map((row) => {
        const id = toInt(row.id);
        const nome = escapeHtml(String(row.nome || ""));
        return `<label class="multi-option">
          <input type="checkbox" value="${id}" />
          <span>${nome}</span>
        </label>`;
      })
      .join("");

    updateModalMultiLabel(type);
  }

  function getModalSelection(type) {
    if (type === "cargo") {
      return normalizeIntArray(state.modalSelection.cargos);
    }
    return normalizeIntArray(state.modalSelection.assuntos);
  }

  function setModalSelection(type, ids) {
    const normalized = normalizeIntArray(ids);
    if (type === "cargo") {
      state.modalSelection.cargos = normalized;
      return;
    }
    state.modalSelection.assuntos = normalized;
  }

  function syncModalMultiOptions() {
    const cargoIds = getModalSelection("cargo").map(String);
    const assuntoIds = getModalSelection("assunto").map(String);

    Array.from(dom.quickCargoOptions?.querySelectorAll('input[type="checkbox"]') || []).forEach((input) => {
      input.checked = cargoIds.includes(input.value);
    });
    Array.from(dom.quickAssuntoOptions?.querySelectorAll('input[type="checkbox"]') || []).forEach((input) => {
      input.checked = assuntoIds.includes(input.value);
    });

    updateModalMultiLabel("cargo");
    updateModalMultiLabel("assunto");
  }

  function updateModalMultiLabel(type) {
    const isCargo = type === "cargo";
    const button = isCargo ? dom.btnQuickCargoDropdown : dom.btnQuickAssuntoDropdown;
    const rows = isCargo ? state.dimensoes.cargos : state.dimensoes.assuntos;
    const ids = getModalSelection(type);
    if (!button) {
      return;
    }

    if (ids.length === 0) {
      button.textContent = isCargo ? "Selecione cargo(s)" : "Selecione assunto(s)";
      return;
    }

    const names = ids
      .map((id) => rows.find((item) => toInt(item.id) === id)?.nome)
      .filter(Boolean);
    if (names.length <= 2) {
      button.textContent = names.join(", ");
      return;
    }
    button.textContent = `${names.slice(0, 2).join(", ")} +${names.length - 2}`;
  }

  function readModalMultiSelectionFromDom(type) {
    const list = type === "cargo" ? dom.quickCargoOptions : dom.quickAssuntoOptions;
    const selected = Array.from(list?.querySelectorAll('input[type="checkbox"]:checked') || []).map((item) => toInt(item.value));
    setModalSelection(type, selected);
  }

  function toggleModalMultiDropdown(type, open) {
    const isCargo = type === "cargo";
    const panel = isCargo ? dom.quickCargoDropdownPanel : dom.quickAssuntoDropdownPanel;
    const button = isCargo ? dom.btnQuickCargoDropdown : dom.btnQuickAssuntoDropdown;
    if (!panel || !button) {
      return;
    }
    const show = open === true;
    panel.classList.toggle("is-hidden", !show);
    button.setAttribute("aria-expanded", show ? "true" : "false");
  }

  function populateMonthsSelect(mesesDisponiveis) {
    const options = normalizeArray(mesesDisponiveis)
      .map((item) => ({
        mesRef: String(item.mes_ref || "").trim(),
        label: String(item.label || "").trim(),
      }))
      .filter((item) => /^\d{4}-(0[1-9]|1[0-2])$/.test(item.mesRef));

    const currentRef = currentMonthRef();
    if (!options.some((item) => item.mesRef === currentRef)) {
      options.unshift({ mesRef: currentRef, label: monthLabel(currentRef) });
    }

    if (options.length === 0) {
      options.push({ mesRef: currentRef, label: monthLabel(currentRef) });
    }

    const available = new Set(options.map((item) => item.mesRef));
    const before = state.filtros.meses.slice().sort().join(",");
    const fallbackMes = available.has(currentRef) ? currentRef : options[0].mesRef;

    if (!periodoDefaultInicializado) {
      state.filtros.meses = [fallbackMes];
      periodoDefaultInicializado = true;
    } else {
      const previousMonths = state.filtros.meses.slice();
      state.filtros.meses = state.filtros.meses.filter((ref) => available.has(ref));
      if (previousMonths.length > 0 && state.filtros.meses.length === 0) {
        state.filtros.meses = [fallbackMes];
      }
    }

    dom.periodoMesesOptions.innerHTML = options
      .map((item) => {
        const checked = state.filtros.meses.includes(item.mesRef) ? "checked" : "";
        const label = escapeHtml(item.label || monthLabel(item.mesRef));
        return `
          <label class="multi-option">
            <input type="checkbox" value="${escapeHtml(item.mesRef)}" ${checked} />
            <span>${label}</span>
          </label>
        `;
      })
      .join("");

    updatePeriodoDropdownLabel();
    updateToggleAllLabel("periodo");
    return before !== state.filtros.meses.slice().sort().join(",");
  }

  function updatePeriodoDropdownLabel() {
    const labels = state.filtros.meses.map((ref) => monthLabel(ref));
    if (labels.length === 0) {
      dom.btnPeriodoDropdown.textContent = "Todos os meses";
      return;
    }
    if (labels.length === 1) {
      dom.btnPeriodoDropdown.textContent = labels[0];
      return;
    }
    if (labels.length <= 2) {
      dom.btnPeriodoDropdown.textContent = labels.join(", ");
      return;
    }
    dom.btnPeriodoDropdown.textContent = `${labels.slice(0, 2).join(", ")} +${labels.length - 2}`;
  }

  function togglePeriodoDropdown(open) {
    const show = open === true;
    dom.periodoDropdownPanel.classList.toggle("is-hidden", !show);
    dom.btnPeriodoDropdown.setAttribute("aria-expanded", show ? "true" : "false");
  }

  function getCheckedMonthsFromDropdown() {
    return Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]:checked'))
      .map((item) => String(item.value || "").trim())
      .filter(Boolean);
  }

  function getGlobalMultiDropdown(type) {
    if (type === "usuario") {
      return dom.filtroUsuarioDropdown;
    }
    if (type === "tratativa") {
      return dom.filtroTratativaDropdown;
    }
    if (type === "cargo") {
      return dom.filtroCargoDropdown;
    }
    return dom.filtroAssuntoDropdown;
  }

  function getGlobalMultiButton(type) {
    if (type === "usuario") {
      return dom.btnUsuarioDropdown;
    }
    if (type === "tratativa") {
      return dom.btnTratativaDropdown;
    }
    if (type === "cargo") {
      return dom.btnCargoDropdown;
    }
    return dom.btnAssuntoDropdown;
  }

  function getGlobalMultiPanel(type) {
    if (type === "usuario") {
      return dom.usuarioDropdownPanel;
    }
    if (type === "tratativa") {
      return dom.tratativaDropdownPanel;
    }
    if (type === "cargo") {
      return dom.cargoDropdownPanel;
    }
    return dom.assuntoDropdownPanel;
  }

  function getGlobalMultiList(type) {
    if (type === "usuario") {
      return dom.usuarioOptions;
    }
    if (type === "tratativa") {
      return dom.tratativaOptions;
    }
    if (type === "cargo") {
      return dom.cargoOptions;
    }
    return dom.assuntoOptions;
  }

  function getGlobalMultiToggleAllButton(type) {
    if (type === "usuario") {
      return dom.btnUsuarioToggleAll;
    }
    if (type === "tratativa") {
      return dom.btnTratativaToggleAll;
    }
    if (type === "cargo") {
      return dom.btnCargoToggleAll;
    }
    return dom.btnAssuntoToggleAll;
  }

  function getGlobalMultiRows(type) {
    if (type === "usuario") {
      return state.dimensoes.usuarios;
    }
    if (type === "tratativa") {
      return buildTipoFilterRows();
    }
    if (type === "cargo") {
      return state.dimensoes.cargos;
    }
    return state.dimensoes.assuntos;
  }

  function getGlobalMultiSelected(type) {
    if (type === "usuario") {
      return state.filtros.usuarioIds;
    }
    if (type === "tratativa") {
      return state.filtros.tipoTratativaIds;
    }
    if (type === "cargo") {
      return state.filtros.cargoIds;
    }
    return state.filtros.assuntoIds;
  }

  function setGlobalMultiSelected(type, values) {
    const normalized = normalizeIntArray(values);
    if (type === "usuario") {
      state.filtros.usuarioIds = normalized;
      return;
    }
    if (type === "tratativa") {
      state.filtros.tipoTratativaIds = normalized;
      return;
    }
    if (type === "cargo") {
      state.filtros.cargoIds = normalized;
      return;
    }
    state.filtros.assuntoIds = normalized;
  }

  function renderGlobalMultiOptions(type, rows = getGlobalMultiRows(type)) {
    const list = getGlobalMultiList(type);
    const selected = getGlobalMultiSelected(type);
    if (!list) {
      return;
    }

    const options = normalizeArray(rows);
    list.innerHTML = options
      .map((row) => {
        const id = toInt(row.id);
        const checked = selected.includes(id) ? "checked" : "";
        const nome = escapeHtml(String(row.nome || ""));
        return `<label class="multi-option">
          <input type="checkbox" value="${id}" ${checked} />
          <span>${nome}</span>
        </label>`;
      })
      .join("");

    updateGlobalMultiLabel(type);
    updateToggleAllLabel(type);
  }

  function syncGlobalMultiOptions(type) {
    const list = getGlobalMultiList(type);
    const selected = getGlobalMultiSelected(type);
    if (!list) {
      return;
    }
    const selectedStr = selected.map(String);
    Array.from(list.querySelectorAll('input[type="checkbox"]')).forEach((input) => {
      input.checked = selectedStr.includes(input.value);
    });
  }

  function getCheckedGlobalIds(type) {
    const list = getGlobalMultiList(type);
    return Array.from(list?.querySelectorAll('input[type="checkbox"]:checked') || [])
      .map((item) => toInt(item.value))
      .filter((id) => id > 0);
  }

  function updateGlobalMultiLabel(type) {
    const rows = getGlobalMultiRows(type);
    const ids = getGlobalMultiSelected(type);
    const button = getGlobalMultiButton(type);
    if (!button) {
      return;
    }
    button.textContent = buildMultiSelectionLabel(rows, ids, { emptyLabel: "Todos", maxNames: 2 });
  }

  function toggleGlobalDropdown(type, open) {
    if (type === "periodo") {
      togglePeriodoDropdown(open);
      return;
    }
    const panel = getGlobalMultiPanel(type);
    const button = getGlobalMultiButton(type);
    if (!panel || !button) {
      return;
    }
    const show = open === true;
    panel.classList.toggle("is-hidden", !show);
    button.setAttribute("aria-expanded", show ? "true" : "false");
  }

  function toggleAllGlobalSelection(type) {
    if (type === "periodo") {
      const checkboxes = Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]'));
      if (checkboxes.length === 0) {
        return;
      }
      const checkedCount = checkboxes.filter((input) => input.checked).length;
      const shouldSelectAll = checkedCount !== checkboxes.length;
      checkboxes.forEach((input) => {
        input.checked = shouldSelectAll;
      });
      state.filtros.meses = shouldSelectAll ? checkboxes.map((input) => String(input.value)) : [];
      updatePeriodoDropdownLabel();
      updateToggleAllLabel("periodo");
      if (state.filtros.meses.length > 0) {
        scheduleAutoRefresh();
      }
      return;
    }

    const list = getGlobalMultiList(type);
    const checkboxes = Array.from(list?.querySelectorAll('input[type="checkbox"]') || []);
    if (checkboxes.length === 0) {
      return;
    }

    const checkedCount = checkboxes.filter((input) => input.checked).length;
    const shouldSelectAll = checkedCount !== checkboxes.length;
    checkboxes.forEach((input) => {
      input.checked = shouldSelectAll;
    });

    const values = shouldSelectAll ? checkboxes.map((input) => toInt(input.value)).filter((id) => id > 0) : [];
    setGlobalMultiSelected(type, values);
    if (type === "usuario") {
      updateSidebarSelectedUser();
    }
    updateGlobalMultiLabel(type);
    updateToggleAllLabel(type);
    scheduleAutoRefresh();
  }

  function updateToggleAllLabel(type) {
    if (type === "periodo") {
      if (!dom.btnPeriodoToggleAll) {
        return;
      }
      const checkboxes = Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]'));
      if (checkboxes.length === 0) {
        dom.btnPeriodoToggleAll.textContent = "Selecionar tudo";
        return;
      }
      const checkedCount = checkboxes.filter((input) => input.checked).length;
      dom.btnPeriodoToggleAll.textContent = checkedCount === checkboxes.length ? "Desmarcar tudo" : "Selecionar tudo";
      return;
    }

    const button = getGlobalMultiToggleAllButton(type);
    const list = getGlobalMultiList(type);
    if (!button || !list) {
      return;
    }
    const checkboxes = Array.from(list.querySelectorAll('input[type="checkbox"]'));
    if (checkboxes.length === 0) {
      button.textContent = "Selecionar tudo";
      return;
    }
    const checkedCount = checkboxes.filter((input) => input.checked).length;
    button.textContent = checkedCount === checkboxes.length ? "Desmarcar tudo" : "Selecionar tudo";
  }

  function scheduleAutoRefresh() {
    if (autoRefreshTimer) {
      clearTimeout(autoRefreshTimer);
    }
    autoRefreshTimer = setTimeout(() => {
      autoRefreshTimer = null;
      refreshAllData().catch((error) => {
        showFeedback(error.message || "Erro ao atualizar filtros.", "error");
      });
    }, 160);
  }

  function scheduleChartSync(delay = 80) {
    if (chartSyncTimer) {
      clearTimeout(chartSyncTimer);
    }
    chartSyncTimer = setTimeout(() => {
      chartSyncTimer = null;
      if (state.view !== "dashboard") {
        return;
      }
      [
        state.charts.evolucao,
        state.charts.volume,
        state.charts.rosca,
        state.charts.cargo,
      ].forEach((chart) => {
        if (chart && typeof chart.updateOptions === "function") {
          chart.updateOptions({}, false, true);
        }
      });
    }, delay);
  }

  function buildFiltersQuery() {
    const params = new URLSearchParams();
    if (state.filtros.usuarioIds.length > 0) {
      params.set("usuario_ids", state.filtros.usuarioIds.join(","));
    }
    if (state.filtros.cargoIds.length > 0) {
      params.set("cargo_ids", state.filtros.cargoIds.join(","));
    }
    if (state.filtros.assuntoIds.length > 0) {
      params.set("assunto_ids", state.filtros.assuntoIds.join(","));
    }
    if (state.filtros.tipoTratativaIds.length === 0) {
      params.set("tipo_tratativa", "all");
    } else {
      params.set("tipo_tratativa_ids", state.filtros.tipoTratativaIds.join(","));
    }
    params.set("granularidade", state.filtros.granularidade === "dia" ? "dia" : "mes");
    if (state.filtros.meses.length > 0) {
      params.set("meses", state.filtros.meses.join(","));
    }
    return params;
  }

  function readFiltersFromInputs() {
    state.filtros.usuarioIds = getCheckedGlobalIds("usuario");
    state.filtros.tipoTratativaIds = getCheckedGlobalIds("tratativa");
    state.filtros.cargoIds = getCheckedGlobalIds("cargo");
    state.filtros.assuntoIds = getCheckedGlobalIds("assunto");
    const meses = getCheckedMonthsFromDropdown();
    state.filtros.meses = meses;
    updateSidebarSelectedUser();
    updatePeriodoDropdownLabel();
    updateGlobalMultiLabel("usuario");
    updateGlobalMultiLabel("tratativa");
    updateGlobalMultiLabel("cargo");
    updateGlobalMultiLabel("assunto");
    updateToggleAllLabel("periodo");
    updateToggleAllLabel("usuario");
    updateToggleAllLabel("tratativa");
    updateToggleAllLabel("cargo");
    updateToggleAllLabel("assunto");
  }

  function syncFilterInputs() {
    Array.from(dom.periodoMesesOptions.querySelectorAll('input[type="checkbox"]')).forEach((input) => {
      input.checked = state.filtros.meses.includes(input.value);
    });
    syncGlobalMultiOptions("usuario");
    syncGlobalMultiOptions("tratativa");
    syncGlobalMultiOptions("cargo");
    syncGlobalMultiOptions("assunto");
    updatePeriodoDropdownLabel();
    updateGlobalMultiLabel("usuario");
    updateGlobalMultiLabel("tratativa");
    updateGlobalMultiLabel("cargo");
    updateGlobalMultiLabel("assunto");
    updateToggleAllLabel("periodo");
    updateToggleAllLabel("usuario");
    updateToggleAllLabel("tratativa");
    updateToggleAllLabel("cargo");
    updateToggleAllLabel("assunto");
    syncGranularidadeButtons();
    syncEvolucaoModoButtons();
    updateSidebarSelectedUser();
  }

  function syncGranularidadeButtons() {
    dom.evolucaoGranularidadeButtons.forEach((button) => {
      const isDia = button.getAttribute("data-granularidade") === "dia";
      button.classList.toggle("is-active", isDia ? state.filtros.granularidade === "dia" : state.filtros.granularidade !== "dia");
    });
  }

  function syncEvolucaoModoButtons() {
    dom.evolucaoModoButtons.forEach((button) => {
      const isAlcance = button.getAttribute("data-evolucao-modo") === "alcance";
      button.classList.toggle("is-active", isAlcance ? state.filtros.evolucaoModo === "alcance" : state.filtros.evolucaoModo !== "alcance");
    });
  }

  function updateSidebarSelectedUser() {
    if (!dom.sidebarSelectedUser) {
      return;
    }
    dom.sidebarSelectedUser.textContent = buildMultiSelectionLabel(state.dimensoes.usuarios, state.filtros.usuarioIds, {
      emptyLabel: "TODOS",
      maxNames: 1,
      uppercase: true,
    });
  }

  function buildMultiSelectionLabel(rows, ids, options = {}) {
    const emptyLabel = options.emptyLabel || "Todos";
    const uppercase = options.uppercase === true;
    const maxNames = Math.max(1, toInt(options.maxNames || 2));
    const names = normalizeIntArray(ids)
      .map((id) => rows.find((item) => toInt(item.id) === id)?.nome)
      .filter(Boolean);

    if (names.length === 0) {
      return uppercase ? emptyLabel.toUpperCase() : emptyLabel;
    }

    let text = "";
    if (names.length <= maxNames) {
      text = names.join(", ");
    } else {
      text = `${names.slice(0, maxNames).join(", ")} +${names.length - maxNames}`;
    }

    return uppercase ? text.toUpperCase() : text;
  }

  function getPreferredGlobalSelectionId(type) {
    const selected = getGlobalMultiSelected(type);
    return selected.length > 0 ? selected[0] : null;
  }

  function syncResponsiveLayout() {
    if (!dom.mobileFiltersHost || !dom.sidebar || !dom.sidebarBrand || !dom.sidebarFilters || !dom.sidebarPages || !dom.sidebarIdentity) {
      return;
    }

    const useMobileHost = window.innerWidth <= MOBILE_FILTER_BREAKPOINT;
    if (useMobileHost) {
      dom.mobileFiltersHost.appendChild(dom.sidebarBrand);
      dom.mobileFiltersHost.appendChild(dom.sidebarPages);
      dom.mobileFiltersHost.appendChild(dom.sidebarFilters);
      dom.mobileFiltersHost.appendChild(dom.sidebarIdentity);
      dom.mobileFiltersHost.classList.add("is-active");
      dom.sidebar.hidden = true;
      return;
    }

    dom.sidebar.hidden = false;
    dom.sidebar.appendChild(dom.sidebarBrand);
    dom.sidebar.appendChild(dom.sidebarPages);
    dom.sidebar.appendChild(dom.sidebarFilters);
    dom.sidebar.appendChild(dom.sidebarIdentity);
    dom.mobileFiltersHost.classList.remove("is-active");
  }

  function setDefaultDateInput() {
    if (!dom.quickTratativaData) {
      return;
    }
    if (dom.quickTratativaData.value) {
      return;
    }
    dom.quickTratativaData.value = toDateInputValue(new Date());
  }

  function normalizeArray(value) {
    return Array.isArray(value) ? value : [];
  }

  function updatePeriodEmptyMessage(show) {
    if (!dom.periodEmptyMessage) {
      return;
    }
    dom.periodEmptyMessage.classList.toggle("is-hidden", !show);
  }

  function normalizeUserName(row) {
    const original = String(row?.nome || "").trim();
    const normalized = original.toLowerCase();
    if (normalized === "ademar") {
      return { ...row, nome: "Ademar Liberato" };
    }
    if (normalized === "aline") {
      return { ...row, nome: "Aline Rosa" };
    }
    return row;
  }

  function normalizeTipoTratativaRow(row) {
    const original = String(row?.nome || row?.tipo_tratativa || "").trim();
    const slug = slugifyTipoTratativa(original);
    const nome = formatTipoTratativaNome(original, slug);
    return {
      ...row,
      nome,
      tipo_tratativa: nome,
    };
  }

  function fillSelect(select, rows, options = {}) {
    if (!select) {
      return;
    }

    const includeAll = options.includeAll === true;
    const allLabel = options.allLabel || "Todos";
    const optional = options.optional === true;
    const optionalLabel = options.optionalLabel || "Não informado";
    const valueKey = options.valueKey || "id";
    const labelKey = options.labelKey || "nome";

    const currentValue = select.value;
    const fragment = document.createDocumentFragment();

    if (includeAll) {
      fragment.appendChild(new Option(allLabel, "all"));
    }
    if (optional) {
      fragment.appendChild(new Option(optionalLabel, ""));
    }

    rows.forEach((row) => {
      const label = String(row[labelKey] ?? "");
      const value = String(row[valueKey] ?? "");
      fragment.appendChild(new Option(label, value));
    });

    select.innerHTML = "";
    select.appendChild(fragment);

    if (currentValue && hasOption(select, currentValue)) {
      select.value = currentValue;
    } else if (select.options.length > 0 && includeAll) {
      select.value = "all";
    }
  }

  function hasOption(select, value) {
    return Array.from(select.options).some((item) => item.value === value);
  }

  function buildTipoFilterRows() {
    return buildTipoCatalog().map((tipo) => ({
      id: tipo.id,
      nome: tipo.nome,
    }));
  }

  function buildTipoCatalog() {
    const colors = getChartCssColors();
    const palette = [colors.teams, colors.visitas, colors.ligacoes, colors.live, colors.evento];

    return normalizeArray(state.dimensoes.tiposTratativa)
      .map((row, index) => {
        const id = toInt(row.id);
        if (!id) {
          return null;
        }

        const rawName = String(row.nome || row.tipo_tratativa || `Tipo ${id}`).trim();
        const slug = slugifyTipoTratativa(rawName);
        return {
          id,
          slug,
          nome: formatTipoTratativaNome(rawName, slug),
          color: resolveTipoTratativaColor(slug, colors, palette[index % palette.length]),
        };
      })
      .filter(Boolean);
  }

  function getSelectedTipoTratativaIds() {
    return normalizeIntArray(state.filtros.tipoTratativaIds);
  }

  function slugifyTipoTratativa(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "");
  }

  function formatTipoTratativaNome(rawName, slug) {
    if (slug === "teams") {
      return "Teams";
    }
    if (slug === "visitas") {
      return "Visitas";
    }
    if (slug === "ligacoes" || slug === "ligacao") {
      return "Ligações";
    }
    if (slug === "live") {
      return "Live";
    }
    if (slug === "evento") {
      return "Evento";
    }
    return rawName || "Tipo";
  }

  function resolveTipoTratativaColor(slug, colors, fallbackColor) {
    if (slug === "teams") {
      return colors.teams;
    }
    if (slug === "visitas") {
      return colors.visitas;
    }
    if (slug === "ligacoes" || slug === "ligacao") {
      return colors.ligacoes;
    }
    if (slug === "live") {
      return colors.live;
    }
    if (slug === "evento") {
      return colors.evento;
    }
    return fallbackColor;
  }

  function getTipoTimelineRows(data, tipoId, timelineKey = "timeline_por_tipo") {
    const grouped = data?.[timelineKey];
    return normalizeArray(grouped?.[tipoId] || grouped?.[String(tipoId)]);
  }

  function getTipoCountFromMap(map, tipoId) {
    if (!map || typeof map !== "object") {
      return 0;
    }
    return toInt(map[tipoId] ?? map[String(tipoId)]);
  }

  function getGroupedTipoCount(row, tipoId) {
    if (row?.totais_por_tipo && typeof row.totais_por_tipo === "object") {
      return getTipoCountFromMap(row.totais_por_tipo, tipoId);
    }

    if (tipoId === 1) {
      return toInt(row?.total_teams);
    }
    if (tipoId === 2) {
      return toInt(row?.total_visitas);
    }
    if (tipoId === 3) {
      return toInt(row?.total_ligacoes);
    }
    if (tipoId === 4) {
      return toInt(row?.total_live);
    }
    if (tipoId === 5) {
      return toInt(row?.total_evento);
    }
    return 0;
  }

  function resolveMonthAxisRefs(mesesDisponiveis) {
    const fromFilters = state.filtros.meses.slice();
    if (fromFilters.length > 0) {
      return fromFilters.slice().sort();
    }

    const refs = normalizeArray(mesesDisponiveis)
      .map((item) => String(item.mes_ref || "").trim())
      .filter((item) => /^\d{4}-(0[1-9]|1[0-2])$/.test(item))
      .sort();

    if (refs.length > 0) {
      return refs;
    }
    return [currentMonthRef()];
  }

  function resolveDayAxisRefs() {
    const fromFilters = state.filtros.meses.slice().sort();
    if (fromFilters.length === 0) {
      const today = new Date();
      return [formatDateRef(today)];
    }

    const refs = [];
    fromFilters.forEach((mesRef) => {
      const [yearText, monthText] = String(mesRef).split("-");
      const year = Number(yearText);
      const month = Number(monthText);
      if (!Number.isFinite(year) || !Number.isFinite(month)) {
        return;
      }
      const cursor = new Date(year, month - 1, 1, 0, 0, 0, 0);
      const targetMonth = month - 1;
      const now = new Date();
      const isCurrentMonth = year === now.getFullYear() && targetMonth === now.getMonth();
      const lastDay = isCurrentMonth ? now.getDate() : new Date(year, month, 0).getDate();
      while (cursor.getMonth() === targetMonth && cursor.getDate() <= lastDay) {
        refs.push(formatDateRef(cursor));
        cursor.setDate(cursor.getDate() + 1);
      }
    });

    return refs;
  }

  function toTimelineCountMap(rows, granularidade = "mes") {
    return rows.reduce((acc, row) => {
      const ref = granularidade === "dia" ? dayRefFromDate(row.data) : monthRefFromDate(row.data);
      if (!ref) {
        return acc;
      }
      acc[ref] = (acc[ref] || 0) + toInt(row.quantidade);
      return acc;
    }, {});
  }

  function dayRefFromDate(value) {
    if (!value) {
      return null;
    }

    const text = String(value);
    if (/^\d{4}-(0[1-9]|1[0-2])-\d{2}/.test(text)) {
      return text.slice(0, 10);
    }

    const date = new Date(text.replace(" ", "T"));
    if (Number.isNaN(date.getTime())) {
      return null;
    }
    return formatDateRef(date);
  }

  function monthRefFromDate(value) {
    if (!value) {
      return null;
    }

    const text = String(value);
    if (/^\d{4}-(0[1-9]|1[0-2])/.test(text)) {
      return text.slice(0, 7);
    }

    const date = new Date(text.replace(" ", "T"));
    if (Number.isNaN(date.getTime())) {
      return null;
    }

    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
  }

  function formatDateRef(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }

  function dayLabel(dayRef) {
    const date = new Date(`${dayRef}T00:00:00`);
    if (Number.isNaN(date.getTime())) {
      return dayRef;
    }
    const week = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
    return `${week[date.getDay()]} ${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}`;
  }

  function dayLabelLong(dayRef) {
    const date = new Date(`${dayRef}T00:00:00`);
    if (Number.isNaN(date.getTime())) {
      return dayRef;
    }
    const week = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
    return `${week[date.getDay()]} - ${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`;
  }

  function mountChart(key, element, options) {
    if (!window.ApexCharts || !element) {
      return;
    }

    clearChart(key);
    element.innerHTML = "";
    const chart = new ApexCharts(element, options);
    state.charts[key] = chart;
    chart.render();
  }

  function clearChart(key) {
    if (state.charts[key]) {
      state.charts[key].destroy();
      state.charts[key] = null;
    }
  }

  function getChartCssColors() {
    const styles = getComputedStyle(document.documentElement);
    return {
      visitas: styles.getPropertyValue("--chart-visitas").trim(),
      teams: styles.getPropertyValue("--chart-interacoes").trim(),
      ligacoes: styles.getPropertyValue("--chart-ligacao").trim(),
      live: styles.getPropertyValue("--chart-live").trim(),
      evento: styles.getPropertyValue("--chart-evento").trim(),
      grid: styles.getPropertyValue("--chart-grid").trim(),
      label: styles.getPropertyValue("--chart-label").trim(),
    };
  }

  function buildIntegerScale(maxValue) {
    const max = Math.max(1, Math.ceil(maxValue));
    if (max <= 12) {
      return { min: 0, max, tickAmount: max };
    }
    const rounded = Math.ceil(max / 5) * 5;
    return { min: 0, max: rounded, tickAmount: 5 };
  }

  function applyTheme(theme) {
    const finalTheme = theme === "dark" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", finalTheme);
    dom.themeSwitchInput.checked = finalTheme === "dark";
    localStorage.setItem("alidemar-theme", finalTheme);
    scheduleThemeRefresh();
  }

  function scheduleThemeRefresh() {
    if (themeRefreshTimer) {
      window.clearTimeout(themeRefreshTimer);
    }

    themeRefreshTimer = window.setTimeout(() => {
      themeRefreshTimer = null;

      if (state.dashboard && state.view === "dashboard") {
        renderDashboard();
        return;
      }

      scheduleChartSync(40);
    }, 60);
  }

  function showAuthScreen() {
    dom.appLayout?.classList.add("is-hidden");
    dom.authScreen?.classList.remove("is-hidden");
    renderAuthenticatedUser();
  }

  function showAppShell() {
    dom.authScreen?.classList.add("is-hidden");
    dom.appLayout?.classList.remove("is-hidden");
  }

  function setAuthMode(mode) {
    state.auth.mode = mode === "setup" ? "setup" : "login";

    dom.formLogin?.classList.toggle("is-hidden", state.auth.mode !== "login");
    dom.formSetup?.classList.toggle("is-hidden", state.auth.mode !== "setup");

    dom.btnAuthModeLogin?.classList.toggle("is-active", state.auth.mode === "login");
    dom.btnAuthModeSetup?.classList.toggle("is-active", state.auth.mode === "setup");
    dom.btnAuthModeLogin?.setAttribute("aria-selected", state.auth.mode === "login" ? "true" : "false");
    dom.btnAuthModeSetup?.setAttribute("aria-selected", state.auth.mode === "setup" ? "true" : "false");

    hideAuthFeedback();
  }

  function showAuthFeedback(message, type = "error") {
    if (!dom.authFeedback) {
      return;
    }

    dom.authFeedback.textContent = message;
    dom.authFeedback.classList.remove("is-hidden", "success", "error");
    dom.authFeedback.classList.add(type === "success" ? "success" : "error");
  }

  function hideAuthFeedback() {
    dom.authFeedback?.classList.add("is-hidden");
    dom.authFeedback?.classList.remove("success", "error");
    if (dom.authFeedback) {
      dom.authFeedback.textContent = "";
    }
  }

  function setAuthSubmitting(submitting) {
    authSubmitting = submitting;
    const disabled = submitting ? "true" : "false";

    [dom.loginFuncional, dom.loginSenha, dom.setupFuncional, dom.setupEmail, dom.setupSenha, dom.setupConfirmacaoSenha].forEach((field) => {
      if (field) {
        field.disabled = submitting;
      }
    });

    [dom.btnAuthLogin, dom.btnAuthSetup, dom.btnAuthModeLogin, dom.btnAuthModeSetup].forEach((button) => {
      if (button) {
        button.disabled = submitting;
        button.setAttribute("aria-disabled", disabled);
      }
    });
  }

  function renderAuthenticatedUser() {
    const user = state.auth.user;
    if (!user) {
      dom.authUserChip?.classList.add("is-hidden");
      dom.btnLogout?.classList.remove("is-hidden");
      if (dom.authUserName) {
        dom.authUserName.textContent = "-";
      }
      if (dom.authUserMeta) {
        dom.authUserMeta.textContent = "-";
      }
      return;
    }

    const authDisabled = user.modo_auth === "disabled";

    if (dom.authUserName) {
      dom.authUserName.textContent = user.nome || user.funcional || "-";
    }
    if (dom.authUserMeta) {
      const meta = authDisabled
        ? "Acesso direto • AD pendente"
        : [user.funcional, user.funcao || user.cargo || user.perfil_acesso || null].filter(Boolean).join(" • ");
      dom.authUserMeta.textContent = meta || "Usuário autenticado";
    }
    dom.btnLogout?.classList.toggle("is-hidden", authDisabled);
    dom.authUserChip?.classList.remove("is-hidden");
  }

  async function handleLoginSubmit(event) {
    event.preventDefault();
    if (authSubmitting) {
      return;
    }

    const funcional = String(dom.loginFuncional?.value || "").trim().toUpperCase();
    const senha = String(dom.loginSenha?.value || "");

    if (!funcional || !senha) {
      showAuthFeedback("Informe a funcional e a senha.", "error");
      return;
    }

    hideAuthFeedback();
    setAuthSubmitting(true);

    try {
      await apiPost(
        "auth.php?action=login",
        { funcional, senha },
        { skipLoading: true, allowUnauthorized: true }
      );
      window.location.reload();
    } catch (error) {
      showAuthFeedback(error.message || "Não foi possível entrar.", "error");
    } finally {
      setAuthSubmitting(false);
    }
  }

  async function handleFirstAccessSubmit(event) {
    event.preventDefault();
    if (authSubmitting) {
      return;
    }

    const funcional = String(dom.setupFuncional?.value || "").trim().toUpperCase();
    const email = String(dom.setupEmail?.value || "").trim().toLowerCase();
    const senha = String(dom.setupSenha?.value || "");
    const confirmacao_senha = String(dom.setupConfirmacaoSenha?.value || "");

    if (!funcional || !email || !senha || !confirmacao_senha) {
      showAuthFeedback("Preencha funcional, e-mail, senha e confirmação.", "error");
      return;
    }

    if (senha !== confirmacao_senha) {
      showAuthFeedback("A confirmação da senha não confere.", "error");
      return;
    }

    hideAuthFeedback();
    setAuthSubmitting(true);

    try {
      await apiPost(
        "auth.php?action=primeiro-acesso",
        { funcional, email, senha, confirmacao_senha },
        { skipLoading: true, allowUnauthorized: true }
      );
      window.location.reload();
    } catch (error) {
      showAuthFeedback(error.message || "Não foi possível concluir o primeiro acesso.", "error");
    } finally {
      setAuthSubmitting(false);
    }
  }

  async function handleLogout() {
    try {
      await apiDelete("auth.php", {}, { skipLoading: true, allowUnauthorized: true });
    } catch (_error) {
      // Ignora falha no logout remoto e força limpeza via reload.
    }

    window.location.reload();
  }

  function loadTheme() {
    return localStorage.getItem("alidemar-theme") || "light";
  }

  function saveView(view) {
    localStorage.setItem("alidemar-view", view === "analitico" ? "analitico" : "dashboard");
  }

  function loadView() {
    const stored = localStorage.getItem("alidemar-view");
    return stored === "analitico" ? "analitico" : "dashboard";
  }

  function showFeedback(message, type = "success") {
    if (!dom.feedback) {
      return;
    }

    dom.feedback.textContent = message;
    dom.feedback.classList.add("is-visible");
    dom.feedback.classList.remove("success", "error");
    dom.feedback.classList.add(type === "error" ? "error" : "success");

    if (feedbackTimer) {
      clearTimeout(feedbackTimer);
    }
    feedbackTimer = setTimeout(() => {
      dom.feedback.classList.remove("is-visible");
    }, 3200);
  }

  function hideFeedback() {
    if (!dom.feedback) {
      return;
    }
    if (feedbackTimer) {
      clearTimeout(feedbackTimer);
      feedbackTimer = null;
    }
    dom.feedback.classList.remove("is-visible");
  }

  function beginLoading(message = "Carregando...") {
    loadingCounter += 1;
    setLoadingState(true, message);
  }

  function endLoading() {
    loadingCounter = Math.max(0, loadingCounter - 1);
    if (loadingCounter === 0) {
      setLoadingState(false);
    }
  }

  function setLoadingState(show, message = "Carregando...") {
    if (!dom.globalLoading) {
      return;
    }

    if (loadingHideTimer) {
      clearTimeout(loadingHideTimer);
      loadingHideTimer = null;
    }

    if (show) {
      if (dom.globalLoadingText) {
        dom.globalLoadingText.textContent = message;
      }
      dom.globalLoading.classList.remove("is-hidden");
      dom.globalLoading.setAttribute("aria-hidden", "false");
      return;
    }

    loadingHideTimer = setTimeout(() => {
      dom.globalLoading.classList.add("is-hidden");
      dom.globalLoading.setAttribute("aria-hidden", "true");
    }, 120);
  }

  async function apiGet(path, requestOptions = {}) {
    return apiRequest(path, { method: "GET" }, requestOptions);
  }

  async function apiPost(path, payload, requestOptions = {}) {
    return apiRequest(
      path,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      },
      requestOptions
    );
  }

  async function apiPut(path, payload, requestOptions = {}) {
    return apiRequest(
      path,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      },
      requestOptions
    );
  }

  async function apiDelete(path, payload, requestOptions = {}) {
    return apiRequest(
      path,
      {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      },
      requestOptions
    );
  }

  async function apiRequest(path, options, requestOptions = {}) {
    const skipLoading = requestOptions.skipLoading === true;
    const allowUnauthorized = requestOptions.allowUnauthorized === true;
    if (!skipLoading) {
      beginLoading("Carregando dados...");
    }

    try {
      const response = await fetch(`${API_ROOT}/${path}`, {
        credentials: "same-origin",
        ...options,
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        if (response.status === 401 && !allowUnauthorized) {
          window.location.reload();
        }
        throw new Error(payload.erro || `Erro ${response.status}`);
      }
      return payload;
    } finally {
      if (!skipLoading) {
        endLoading();
      }
    }
  }

  function currentMonthRef() {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  }

  function monthLabel(mesRef) {
    const [year, month] = String(mesRef).split("-");
    const monthIndex = Number(month) - 1;
    const monthName = MONTHS_PT[monthIndex] || month;
    return `${monthName} - ${year}`;
  }

  function normalizeDateInput(value) {
    if (!value) {
      return null;
    }
    return value.length === 10 ? `${value} 00:00:00` : value.replace("T", " ");
  }

  function toDateInputValue(value) {
    if (value instanceof Date) {
      const year = value.getFullYear();
      const month = String(value.getMonth() + 1).padStart(2, "0");
      const day = String(value.getDate()).padStart(2, "0");
      return `${year}-${month}-${day}`;
    }

    if (!value) {
      return "";
    }

    const parsed = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(parsed.getTime())) {
      return "";
    }
    return toDateInputValue(parsed);
  }

  function formatDate(value) {
    if (!value) {
      return "-";
    }
    const date = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(date.getTime())) {
      return String(value);
    }
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  }

  function formatInt(value) {
    return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 }).format(toInt(value));
  }

  function toCategoryLines(text, maxChars = 16, maxLines = 3) {
    const clean = String(text || "").trim();
    if (!clean) {
      return [""];
    }
    if (clean.length <= maxChars) {
      return [clean];
    }

    const words = clean.split(/\s+/);
    const lines = [];
    let current = "";
    words.forEach((word) => {
      const next = current ? `${current} ${word}` : word;
      if (next.length > maxChars && current) {
        lines.push(current);
        current = word;
      } else {
        current = next;
      }
    });
    if (current) {
      lines.push(current);
    }

    return lines.slice(0, maxLines);
  }

  function toInt(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) {
      return 0;
    }
    return Math.trunc(number);
  }

  function hashString(input) {
    let hash = 0;
    const text = String(input || "");
    for (let i = 0; i < text.length; i += 1) {
      hash = (hash << 5) - hash + text.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash);
  }

  function toIntOrNull(value) {
    if (value === null || value === undefined) {
      return null;
    }
    const text = String(value).trim();
    if (text === "" || text.toLowerCase() === "all") {
      return null;
    }
    const number = Number(text);
    if (!Number.isFinite(number)) {
      return null;
    }
    return Math.trunc(number);
  }

  function toNonNegativeInt(value, defaultValue = 0) {
    if (value === null || value === undefined || String(value).trim() === "") {
      return defaultValue;
    }
    const number = Number(value);
    if (!Number.isFinite(number) || number < 0) {
      return null;
    }
    return Math.trunc(number);
  }

  function normalizeIntArray(values) {
    if (!Array.isArray(values)) {
      return [];
    }
    const out = [];
    values.forEach((value) => {
      const intValue = toIntOrNull(value);
      if (intValue !== null && intValue > 0 && !out.includes(intValue)) {
        out.push(intValue);
      }
    });
    return out;
  }

  function nullableString(value) {
    if (value === null || value === undefined) {
      return null;
    }
    const text = String(value).trim();
    return text === "" ? null : text;
  }

  function nonEmptyString(value) {
    const text = nullableString(value);
    if (!text) {
      throw new Error("Preencha os campos obrigatórios.");
    }
    return text;
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function exportAnaliticoCsv() {
    const rows = getFilteredAnaliticoRows();
    if (rows.length === 0) {
      showFeedback("Não há dados para exportar.", "error");
      return;
    }

    const headers = ["data", "tipo_tratativa", "usuario", "alcance", "cargo", "assunto", "juncao", "descricao", "contatos"];
    const lines = [headers.join(";")];

    rows.forEach((row) => {
      const cargoLabel = formatDimensionField(row.cargo, row.ids_cargos, state.dimensoes.cargos);
      const assuntoLabel = formatDimensionField(row.assunto, row.ids_assuntos, state.dimensoes.assuntos);
      const values = [
        row.data,
        row.tipo_tratativa,
        row.usuario,
        row.alcance_total,
        cargoLabel,
        assuntoLabel,
        row.juncao || row.agencia,
        row.descricao,
        formatContato(row.contatos),
      ].map((value) => `"${String(value ?? "").replaceAll('"', '""')}"`);
      lines.push(values.join(";"));
    });

    const csv = "\uFEFF" + lines.join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `tratativas_analitico_${currentMonthRef()}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function formatContato(value, emptyValue = "-") {
    const text = nullableString(value);
    if (!text) {
      return emptyValue;
    }

    try {
      const decoded = JSON.parse(text);
      if (Array.isArray(decoded)) {
        const parts = decoded
          .map((item) => {
            if (!item || typeof item !== "object") {
              return "";
            }
            const nome = nullableString(item.nome);
            const subsecao = nullableString(item.subsecao);
            if (nome && subsecao) {
              return `${nome} - ${subsecao}`;
            }
            return nome || subsecao || "";
          })
          .filter(Boolean);
        if (parts.length > 0) {
          return parts.join("; ");
        }
      }
    } catch (error) {
      return text;
    }

    return text;
  }

  function formatDimensionField(rawValue, rawIds, dimensionRows) {
    const text = nullableString(rawValue);
    if (text) {
      return text
        .split(/\s*[|,;]\s*/)
        .filter(Boolean)
        .join(" | ");
    }

    const ids = normalizeIntArray(rawIds);
    if (ids.length === 0) {
      return "-";
    }
    return ids
      .map((id) => dimensionRows.find((item) => toInt(item.id) === id)?.nome)
      .filter(Boolean)
      .join(" | ");
  }

  function getFilteredAnaliticoRows() {
    const rows = state.analitico.tratativas || [];
    const term = String(state.analitico.busca || "").trim().toLowerCase();
    if (!term) {
      return rows;
    }

    return rows.filter((row) => {
      const cargoLabel = formatDimensionField(row.cargo, row.ids_cargos, state.dimensoes.cargos);
      const assuntoLabel = formatDimensionField(row.assunto, row.ids_assuntos, state.dimensoes.assuntos);
      const all = [
        formatDate(row.data),
        row.tipo_tratativa,
        row.usuario,
        row.alcance_total,
        cargoLabel,
        assuntoLabel,
        row.juncao || row.agencia,
        row.descricao,
        formatContato(row.contatos),
      ]
        .map((value) => String(value || "").toLowerCase())
        .join(" | ");
      return all.includes(term);
    });
  }

})();
